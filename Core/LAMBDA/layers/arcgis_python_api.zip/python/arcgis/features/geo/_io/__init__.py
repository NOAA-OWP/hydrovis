"""
Contains the logic to go to/from various data types.
"""