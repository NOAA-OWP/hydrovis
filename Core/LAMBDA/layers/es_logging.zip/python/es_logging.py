import logging


def get_elasticsearch_logger():
    logger = logging.getLogger('elasticsearch')
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        # Prevent logging from propagating to the root logger
        logger.propagate = 0
        console = logging.StreamHandler()
        logger.addHandler(console)
        formatter = logging.Formatter('[ELASTICSEARCH %(levelname)s]:  %(asctime)s - %(message)s')
        console.setFormatter(formatter)
    return logger
