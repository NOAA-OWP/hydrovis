"""Affine tests package"""
