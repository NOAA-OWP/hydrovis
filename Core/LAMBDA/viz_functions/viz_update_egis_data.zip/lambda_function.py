from viz_classes import database
from datetime import datetime, timedelta

def lambda_handler(event, context):
    step = event['step']
    table = event['args']['map_item']
    reference_time = datetime.strptime(event['args']['reference_time'], '%Y-%m-%d %H:%M:%S')
    
    viz_db = database(db_type="viz")
    
    # Copy data to EGIS
    viz_db.move_data_to_another_db(dest_db_type="egis", origin_table=f"publish.{table}", dest_table=f"services.{table}", stage=True, add_oid=True, add_geom_index=True)
    
    # Cache data
    cache_data(viz_db, table, reference_time)
    
    return True

###################################
def cache_data(db, table, reference_time, retention_days=30):
    retention_cutoff = reference_time - timedelta(retention_days)
    ref_prefix = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}"
    retention_prefix = f"ref_{retention_cutoff.strftime('%Y%m%d_%H%M_')}"
    new_archive_table = f"archive.{ref_prefix}{table}"
    cutoff_archive_table = f"archive.{retention_prefix}{table}"
    with db.get_db_connection() as connection:
        with connection.cursor() as curs:
            curs.execute(f'DROP TABLE IF EXISTS {new_archive_table};')
            curs.execute(f'DROP TABLE IF EXISTS {cutoff_archive_table};')
            curs.execute(f'SELECT * INTO {new_archive_table} FROM publish.{table};')
            connection.commit()
    print(f"---> Wrote cache data into {new_archive_table} and dropped corresponding table from {retention_days} days ago, if it existed.")