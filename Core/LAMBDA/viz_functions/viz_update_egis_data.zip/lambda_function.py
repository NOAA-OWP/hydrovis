import boto3
import os
from viz_classes import database
from datetime import datetime, timedelta

###################################
def lambda_handler(event, context):
    step = event['step']
    table = event['args']['map_item']
    job_type = event['args']['job_type']
    reference_time = datetime.strptime(event['args']['reference_time'], '%Y-%m-%d %H:%M:%S')
    
    viz_db = database(db_type="viz")
    egis_db = database(db_type="egis")
    
    if job_type == 'auto':
        # Copy data to EGIS
        viz_db.move_data_to_another_db(dest_db_type="egis", origin_table=f"publish.{table}", dest_table=f"services.{table}", stage=True, add_oid=True, add_geom_index=True)
        egis_db.run_sql_in_db(f"SELECT UpdateGeometrySRID('services', '{table}', 'geom', 3857);")
        
        # Cache data in the database
        cache_data_in_db(viz_db, table, reference_time)
        # Save shapefile to s3 cache folder
        save_shapefile_to_s3(viz_db, "publish", table, reference_time)
    elif job_type == 'past_event':
        # Save shapefile to s3 cache folder
        save_shapefile_to_s3(viz_db, "archive", table, reference_time)
    
    return True

###################################
def cache_data_in_db(db, table, reference_time, retention_days=15):
    retention_cutoff = reference_time - timedelta(retention_days)
    ref_prefix = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}"
    retention_prefix = f"ref_{retention_cutoff.strftime('%Y%m%d_%H%M_')}"
    new_archive_table = f"archive.{ref_prefix}{table}"
    cutoff_archive_table = f"archive.{retention_prefix}{table}"
    with db.get_db_connection() as connection:
        with connection.cursor() as curs:
            curs.execute(f'DROP TABLE IF EXISTS {new_archive_table};')
            curs.execute(f'DROP TABLE IF EXISTS {cutoff_archive_table};')
            curs.execute(f'SELECT * INTO {new_archive_table} FROM publish.{table};')
            connection.commit()
    print(f"---> Wrote cache data into {new_archive_table} and dropped corresponding table from {retention_days} days ago, if it existed.")

###################################   
def save_shapefile_to_s3(db, schema, table, reference_time):
    s3_client = boto3.client('s3')
    upload_bucket = os.environ['CACHE_BUCKET']
    service = table
    
    if schema == 'archive':
        ref_prefix = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}"
        table = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}{table}"
        
    # Skipping ana_past_14day shapefiles as they are too big to process right now in this way.
    if 'ana_past_14day_max_inundation' in table:
        #sql = f"SELECT hydro_id, feature_id, reference_time, geom FROM {schema}.{table};"
        return
    else:
        sql = f"SELECT * FROM {schema}.{table};"
    
    gdf = db.run_sql_in_db(sql, return_geodataframe=True)
    gdf.to_file(f'/tmp/{service}.shp', index=False)

    ref_day = f"{reference_time.strftime('%Y%m%d')}"
    ref_hour = f"{reference_time.strftime('%H%M')}"
    for file in os.listdir('/tmp/'):
        file_basename = os.path.basename(file).split(".")[0]
        if file_basename == service:
            file_path = os.path.join('/tmp/', file)
            s3_key = f"viz_cache/{ref_day}/{ref_hour}/{file}"
            print(f"Uploading {file} to {upload_bucket}:/{s3_key}")
            s3_client.upload_file(file_path, upload_bucket, s3_key)
            os.remove(file_path)