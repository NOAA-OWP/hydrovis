SELECT
    max_forecast.feature_id,
    round((max_forecast.maxflow_10day / 35.315::double precision)::numeric, 2) as streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM cache.max_flows_mrf max_forecast
JOIN derived.recurrence_flows_conus rf ON rf.feature_id=max_forecast.feature_id
JOIN derived.featureid_huc_crosswalk AS crosswalk ON rf.feature_id = crosswalk.feature_id
WHERE rf.high_water_threshold <= max_forecast.maxflow_18hour AND crosswalk.huc8 IS NOT NULL;