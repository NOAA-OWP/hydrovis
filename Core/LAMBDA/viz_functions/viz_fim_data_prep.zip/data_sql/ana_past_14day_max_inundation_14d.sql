SELECT
    max_forecast.feature_id,
    max_forecast.MAX_FLOW_14DAY_cms AS streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM CACHE.MAX_FLOWS_ANA_14DAY max_forecast
JOIN derived.recurrence_flows_conus rf ON rf.feature_id=max_forecast.feature_id
JOIN derived.featureid_huc_crosswalk AS crosswalk ON rf.feature_id = crosswalk.feature_id
WHERE max_forecast.MAX_FLOW_14DAY_cfs >= rf.high_water_threshold AND crosswalk.huc8 IS NOT NULL AND high_water_threshold > 0;
