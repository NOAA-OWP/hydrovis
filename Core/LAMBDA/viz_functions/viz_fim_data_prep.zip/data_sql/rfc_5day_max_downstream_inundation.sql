SELECT
    max_forecast.feature_id,
    round(max_forecast.streamflow::numeric, 2) as streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM ingest.rnr_max_flows max_forecast
JOIN derived.featureid_huc_crosswalk AS crosswalk ON max_forecast.feature_id = crosswalk.feature_id
WHERE viz_max_status IN ('action', 'minor', 'moderate', 'major', 'record') AND crosswalk.huc8 IS NOT NULL AND waterbody_id IS NULL