SELECT
    rf.feature_id,
    ROUND(CAST(rf.rf_2_0 * 0.0283168 as numeric), 2) as streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM derived.recurrence_flows_conus rf
JOIN derived.featureid_huc_crosswalk AS crosswalk ON rf.feature_id = crosswalk.feature_id
WHERE crosswalk.huc8 IN (
    SELECT
        huc8
    FROM derived.featureid_huc_crosswalk AS crosswalk
    GROUP BY huc8
    ORDER BY huc8
    LIMIT 800
    OFFSET 0
)