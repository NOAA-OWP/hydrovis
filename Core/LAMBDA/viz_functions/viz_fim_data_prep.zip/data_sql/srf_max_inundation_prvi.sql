SELECT
    max_forecast.feature_id,
    max_forecast.maxflow_48hour_cms as streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM cache.max_flows_srf_prvi max_forecast
JOIN derived.recurrence_flows_prvi rf ON rf.feature_id=max_forecast.feature_id
JOIN derived.featureid_huc_crosswalk AS crosswalk ON rf.feature_id = crosswalk.feature_id
WHERE max_forecast.maxflow_48hour_cfs >= rf.high_water_threshold AND crosswalk.huc8 IS NOT NULL;