SELECT
    rf.feature_id,
    ROUND(CAST(rf.rf_10_0_17c * 0.0283168 as numeric), 2) as streamflow_cms,
    LPAD(crosswalk.huc8::text, 8, '0') as huc8
FROM derived.recurrence_flows_conus rf
JOIN derived.featureid_huc_crosswalk AS crosswalk ON rf.feature_id = crosswalk.feature_id
WHERE crosswalk.huc8 IS NOT NULL
ORDER BY crosswalk.huc8