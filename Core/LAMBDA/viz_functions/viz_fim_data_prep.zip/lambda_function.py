import boto3
import re
import os
import datetime
import time

from viz_classes import database
from es_logging import get_elasticsearch_logger
es_logger = get_elasticsearch_logger()

FIM_DATA_BUCKET = os.environ['FIM_DATA_BUCKET']

PROCESSED_OUTPUT_BUCKET = os.environ['PROCESSED_OUTPUT_BUCKET']
PROCESSED_OUTPUT_PREFIX = os.environ['PROCESSED_OUTPUT_PREFIX']


def lambda_handler(event, context):
    """
        The lambda handler is the function that is kicked off with the lambda. This function will take a forecast file,
        extract features with streamflows above 1.5 year threshold, and then kick off lambdas for each HUC with valid
        data.

        Args:
            event(event object): An event is a JSON-formatted document that contains data for a Lambda function to
                                 process
            context(object): Provides methods and properties that provide information about the invocation, function,
                             and runtime environment
    """
    fim_config = event['args']['fim_config']
    service_data = event['args']['service']
    reference_time = event['args']['reference_time']
    reference_date = datetime.datetime.strptime(reference_time, "%Y-%m-%d %H:%M:%S")
    service = service_data['service']
    configuration = service_data['configuration']
    sql_replace = event['args']['sql_rename_dict']
    target_table = 'ingest.' + fim_config
    es_logger.info(f"Running FIM for {configuration} for {reference_time}")
    one_off = event['args'].get("hucs")
    inundation_mode = event['args']['inundation_mode'] if event['args'].get('inundation_mode') else 'full_db'

    # Extract features that are above the 1.5 year recurrence threshold
    taskList = []
    viz_db = database(db_type="viz")

    # Find the sql file, and replace any items in the dictionary
    sql_path = f'data_sql/{fim_config}.sql'
    sql = open(sql_path, 'r').read().lower()
    for word, replacement in sql_replace.items():
        sql = sql.replace(word.lower(), replacement.lower())
    df_streamflows = viz_db.run_sql_in_db(sql)

    setup_db_table(target_table, reference_time, sql_replace)
    
    # Get the hucs that will need to be processed
    if one_off:
        hucs_to_process = one_off
    else:
        hucs_to_process = get_hucs_to_process(configuration, df_streamflows['huc8'].unique())
        
    es_logger.info(f"Kicking off {len(hucs_to_process)} hucs for {service} for {reference_time}")

    for huc in hucs_to_process:
        huc_data = df_streamflows.loc[df_streamflows['huc8'] == huc, ['feature_id', "streamflow_cms"]]  # get data for this huc only
        
        if not huc_data.empty:
            data_key = write_data_csv_file(service, huc, reference_date, huc_data)
            taskList.append({'data_key': data_key, 'db_fim_table': target_table, 'inundation_mode': inundation_mode})

    return_object = {
        'statusCode': 200,
        "huc_list": len(taskList),
        "features": len(df_streamflows),
        'body': {'taskList': taskList},
        'service_data': event
    }

    return return_object


def setup_db_table(db_fim_table, reference_time, sql_replace=None):
    """
        Sets up the necessary tables in a postgis data for later ingest from the huc processing functions

        Args:
            configuration(str): service configuration for the service being ran (i.e. srf, srf_hi, etc)
            reference_time(str): Reference time of the data being ran
            sql_replace(dict): An optional dictionary by which to use to create a new table if needed
    """
    index_name = f"idx_{db_fim_table.split('.')[-1:].pop()}_hydro_id"

    print(f"Setting up {db_fim_table}")
    # Connect to the postgis DB
    viz_db = database(db_type="viz")
    with viz_db.get_db_connection() as connection:
        cur = connection.cursor()

         # See if the target table exists #TODO: Ensure table exists would make a good helper function
        cur.execute(f"SELECT EXISTS (SELECT FROM pg_tables WHERE schemaname = '{db_fim_table.split('.')[0]}' AND tablename = '{db_fim_table.split('.')[1]}');")
        table_exists = cur.fetchone()[0]
        
        # If the target table doesn't exist, create one basd on the sql_replace dict.
        if not table_exists:
            print(f"--> {db_fim_table} does not exist. Creating now.")
            original_table = list(sql_replace.keys())[list(sql_replace.values()).index(db_fim_table)] #ToDo: error handling if not in list
            cur.execute(f"DROP TABLE IF EXISTS {db_fim_table}; CREATE TABLE {db_fim_table} (LIKE {original_table})")
            connection.commit()
        
        # Add a row to the ingest status table indicating that an import has started.
        SQL = f"INSERT INTO admin.ingest_status (target, reference_time, status, update_time) " \
              f"VALUES ('{db_fim_table}', '{reference_time}', 'Import Started', " \
              f"'{datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')}')"
        cur.execute(SQL)

        # Drop the existing index on the target table
        print("Dropping target table index (if exists).")
        SQL = f"DROP INDEX IF EXISTS ingest.{index_name};"
        cur.execute(SQL)

        # Truncate all records.
        print("Truncating target table.")
        SQL = f"TRUNCATE TABLE {db_fim_table};"
        cur.execute(SQL)
        connection.commit()
    
    return db_fim_table


def get_hucs_to_process(configuration, all_HUCs):
    '''
        Compare all the HUCs in the domain with the HUCs that have available datasets. Get a list where they overlap
        so we can know what HUCs will actually be processed

        Args:
            service_type(str): forecast configuration, i.e. nwm, rfc, owp, etc
            all_HUCs (list): list of all the HUCs (with or without data) from the forecast file

        Returns:
            hucs_to_process(list): list of HUCs that are both in the forecast domain and have HAND datasets
    '''
    s3_resource = boto3.resource('s3')

    # For RnR, we only care about the main stems
    if configuration == "replace_route":
        config = "ms"
    else:
        config = "fr"

    # Connect to the FIM bucket and get a list of all the available datasets for the FIM version
    FIM_Bucket = s3_resource.Bucket(FIM_DATA_BUCKET)
    huc_keys = FIM_Bucket.objects.filter(Prefix=f'fim_{os.environ["FIM_VERSION"].replace(".", "_")}_{config}_c/').all()

    # Loop through the datasets and keep track of what HUCs are available
    available_huc_datasets = []
    for huc_key in huc_keys:
        try:
            huc = re.findall(r"/(\d{8})/", huc_key.key)[0]
            if huc not in available_huc_datasets:
                available_huc_datasets.append(huc)
        except Exception:
            continue

    # Because of the way the mosaic dataset is set up, we need to process all the MS datasets.
    # TODO: Fix mosaic dataset logic so that not every HUC needs to be processed. Maybe creating a
    # "published_new" folder and then switch it out?
    if configuration == "replace_route":
        print("Running replace and route- only main stems will be processed")
        return available_huc_datasets

    # Select HUCs that are in the domain AND have HAND datasets
    hucs_to_process = [huc for huc in all_HUCs if huc in available_huc_datasets]

    if not hucs_to_process:
        raise Exception("No HUCs are expected. Check code and paths.")

    return hucs_to_process


def write_data_csv_file(service, huc, reference_date, huc_data):
    '''
        Write the subsetted streamflow data to a csv so that the huc processing lambdas can grab it

        Args:
            huc(str): HUC that will be processed
            filename(str): Forecast file that was used
            huc_data(pandas.datafrm): Dataframe subsetted for the specific huc

        Returns:
            data_json_key(str): key (path) to the json file in the workspace folder
    '''
    s3 = boto3.client('s3')

    # Parses the forecast key to get the necessary metadata for the output file
    date = reference_date.strftime("%Y%m%d")
    hour = reference_date.strftime("%H")

    # Key for the csv file that will be stored in S3
    csv_key = f"{PROCESSED_OUTPUT_PREFIX}/{service}/workspace/{date}/{hour}/data/{huc}_data.csv"

    # Save the dataframe as a local netcdf file
    tmp_csv = f'/tmp/{huc}.csv'
    huc_data.to_csv(tmp_csv, index=False)

    # Upload the csv file into S3
    print(f"Uploading {csv_key}")
    s3.upload_file(tmp_csv, PROCESSED_OUTPUT_BUCKET, csv_key)
    os.remove(tmp_csv)

    return csv_key
