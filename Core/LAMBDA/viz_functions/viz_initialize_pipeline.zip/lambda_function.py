################################################################################
########################### Viz Initialize Pipeline ############################ 
################################################################################
"""
This function initializes a viz pipeline class, organizes the pipeline metatdata and
input files. It returns a dictionary with all the pipeline info, which it uses to
invoke the aws step function state machine before returning.

Args:
    event (dictionary): The event passed from the state machine.
    context (object): Automatic metadata regarding the invocation.
    
Returns:
    dictionary: The details of the pipeline and files to ingest, to serve as input to the step function.
"""
################################################################################
import collections
import datetime
import time
import re
import boto3
import logging
import datetime
import time
import os
import json
from botocore.exceptions import ClientError
from viz_classes import s3_file, database

###################################################################################################################################################
class DuplicatePipelineException(Exception):
    """ my custom exception class """

def lambda_handler(event, context):
    ###### Initialize the pipeline class & configuration classes ######
    #Initialize the pipeline object - This will parse the lambda event, initialize a configuration, and pull service metadata for that configuration from the viz processing database.
    try:
        pipeline = viz_lambda_pipeline(event)
        ingest_files = pipeline.ingest_files
        invoke_step_function = pipeline.start_event.get('invoke_step_function') if 'invoke_step_function' in pipeline.start_event else True
        # pipeline.monitor(f"Pipeline Initialized") #ToDo: Figure out a better way to do monitoring across the step function now that we're not using the pipeline class at each step.
    except Exception as e:
        print("Error: Pipeline failed to initialize.")
        raise e

    # If an automated pipeline run, check to see when the last reference time and start time was, and throw an exceptions accordingly
    # TODO: Improve the logic here and in the pipeline init to be smarter about this. e.g. only unfinished pipelines, variable wait time, etc.
    if pipeline.invocation_type == 'sns' or pipeline.invocation_type == 'lambda':
        if pipeline.configuration.reference_time <= pipeline.most_recent_ref_time:
            raise Exception(f"{pipeline.most_recent_ref_time} already ran. Aborting {pipeline.configuration.reference_time}.")
        minutes_since_last_run = divmod((datetime.datetime.now() - pipeline.most_recent_start).total_seconds(), 60)[0]
        print(minutes_since_last_run)
        if minutes_since_last_run < 15:
            raise DuplicatePipelineException(f"Another {pipeline.configuration.name} pipeline started less than 15 minutes ago. Pausing for 15 minutes.")

    # Split input files into groups based on ingest_table, so we can do one at a time. #TODO: This ends up with a nested list. Can't figure out how to remove that. May be better to just combine in nested loop below.
    ingest_dicts = collections.defaultdict(list)
    for ingest_dict in ingest_files:
        ingest_dicts[ingest_dict['ingest_table']].append(ingest_dict)
    ingest_sets = list(ingest_dicts.values())

    ingest_groups = []
    ingest_tables = []
    
    # Loop through each ingest set to do a seperate insert per ingest table #### - Would be nice if I could combine the above collections thing and this loop to be the same thing.
    for ingest_set in ingest_sets:
        target_table = ingest_set[0]['ingest_table'] #Requires the 0 index because of the nested list mentioned a few lines above. Would be good to clean up.
        original_table = ingest_set[0]['original_table'] #Requires the 0 index because of the nested list mentioned a few lines above. Would be good to clean up.
        index_columns = ingest_set[0]['ingest_keys'] #Requires the 0 index because of the nested list mentioned a few lines above. Would be good to clean up.
        index_name = f"idx_{target_table.split('.')[-1:].pop()}_{index_columns.replace(', ', '_')[1:-1]}"
        
        ingest_datasets = []
        for file in ingest_set:
            ingest_datasets.append({
                "target_table": target_table,
                "file": file['s3_key'],
                "bucket": pipeline.configuration.input_bucket,
                "reference_time": pipeline.configuration.reference_time.strftime('%Y-%m-%d %H:%M:%S'),
                "keep_flows_at_or_above": 1 #TODO: Make this a pipeline class attribute, or env variable, or defined in the input args or something.
            })
        
        ingest_groups.append({
            "target_table": target_table,
            "original_table": original_table,
            "index_columns": index_columns,
            "index_name": index_name,
            "reference_time": pipeline.configuration.reference_time.strftime("%Y-%m-%d %H:%M:%S"),
            "ingest_datasets": ingest_datasets
        })
        
        if target_table not in ingest_tables:
            ingest_tables.append(target_table)
        
    return_object = {
        "pipeline_info": {
            "configuration": pipeline.configuration.name,
            "job_type": pipeline.job_type,
            "keep_raw": pipeline.keep_raw,
            "reference_time": pipeline.configuration.reference_time.strftime("%Y-%m-%d %H:%M:%S"),
            "pipeline_services": pipeline.pipeline_services,
            "max_flows":  pipeline.pipeline_max_flows,
            "summaries": pipeline.pipeline_summaries,
            "sql_rename_dict": pipeline.sql_rename_dict
        },  "ingest_groups": ingest_groups
    }
    
    step_function_arn = os.environ["STEP_FUNCTION_ARN"]
    if invoke_step_function is True:
        try:
            #Invoke the step function.
            client = boto3.client('stepfunctions')
            ref_time_short = pipeline.configuration.reference_time.strftime("%Y-%m-%d-%H-%M-%S")
            pipeline_name = f"{pipeline.invocation_type}_{pipeline.configuration.name}_{ref_time_short}"
            client.start_execution(
                stateMachineArn = step_function_arn,
                name = pipeline_name,
                input= json.dumps(return_object)
            )
            print(f"Invoked: {step_function_arn}")
        except Exception as e:
            print(f"Couldn't invoke - update later. ({e})")
    return return_object

###################################################################################################################################################
###################################################################################################################################################
class viz_lambda_pipeline:
    
    def __init__(self, start_event, print_init=True):
        self.start_event = start_event
        if "Records" in self.start_event:
            self.invocation_type = "sns" 
        elif "invocation_type" in self.start_event:
            self.invocation_type = "lambda" #ToDo: Clean this up to actually pull the value from the payload
        else: self.invocation_type = "manual"
        self.job_type = "auto" if not self.start_event.get('reference_time') else "past_event"
        self.keep_raw = True if self.job_type == "past_event" and self.start_event.get('keep_raw') else False
        self.monitor_code = 0
        self.monitor_txt = "Initializing"
        self.start_time = datetime.datetime.fromtimestamp(time.time())
        #self.es_logger = get_elasticsearch_logger()

        # Here is the logic that parses various invocation types / events to determine the configuration and reference time.
        if self.invocation_type == "sns" or self.start_event.get('data_key'):
            self.start_file = s3_file.from_lambda_event(self.start_event)
            self.configuration = configuration.from_s3_file(self.start_file)
        elif self.invocation_type == "manual":
            if self.start_event.get('reference_time'):
                self.reference_time = datetime.datetime.strptime(self.start_event.get('reference_time'), '%Y-%m-%d %H:%M:%S')
                self.configuration = configuration(start_event.get('configuration'), reference_time=self.reference_time, input_bucket=start_event.get('bucket'))
            else:
                most_recent_file = s3_file.get_most_recent_from_configuration(configuration_name=start_event.get('configuration'), bucket=start_event.get('bucket'))
                self.start_file = most_recent_file
                self.configuration = configuration.from_s3_file(self.start_file)
                self.reference_time = self.configuration.reference_time
        self.most_recent_ref_time, self.most_recent_start = self.get_last_run_info()
        self.pipeline_services = self.configuration.services_to_run
        self.pipeline_max_flows =  [{"max_flows" : name for name in self.configuration.max_flows}] if len(self.configuration.max_flows) > 0 else []
        self.pipeline_summaries = [{"summary" : name for name in self.configuration.summaries}] if len(self.configuration.summaries) > 0 else []
        self.sql_rename_dict = {} #Empty dictionary for use in past events, if table renames are required
        self.organize_db_import() #This method organizes input table metadata based on the admin.pipeline_data_flows db table, and adds a 'sql_args' key to relevant pipeline_info dictionary items.
        
        if print_init:
            #Print the info for the initialized pipeline.
            self.__print__() 
    
    ###################################
    def get_last_run_info(self):
        viz_db = database(db_type="viz")
        with viz_db.get_db_connection() as connection:
            cur = connection.cursor()
            cur.execute(f"""
                        SELECT max(reference_time) as reference_time, last_update
                        FROM (SELECT max(update_time) as last_update from admin.ingest_status a
                                JOIN admin.pipeline_data_flows b ON a.target = b.target_table
                                JOIN admin.services_new c on b.service = c.service
                                WHERE configuration = '{self.configuration.name}' and status = 'Import Started' AND step = 'ingest') as last_start
                        JOIN admin.ingest_status a ON last_start.last_update = a.update_time
                        JOIN admin.pipeline_data_flows b on a.target = b.target_table
                        JOIN admin.services_new c ON b.service = c.service
                        WHERE c.configuration = '{self.configuration.name}' AND b.step = 'ingest'
                        GROUP BY last_update
                        """)
            try:
                return cur.fetchone()[0], cur.fetchone()[1]
            except: #if nothing logged in db, return generic datetimes in the past
                return datetime.datetime(2000, 1, 1, 0, 0, 0), datetime.datetime(2000, 1, 1, 0, 0, 0)
    
    ###################################
    # This method organizes input table metadata based on the admin.pipeline_data_flows db table, and adds a 'sql_args' key to relevant pipeline_info dictionary items.
    # It produces one new pipeline class attribute: ingest_files, which is the list of S3 file paths and their respective db destination tables.
    # It updates pipeline_max_flows, and pipeline_services (all created in pipeline class init) to include a 'sql_args' dictionary to be used to fill params in the sql files.
    # TODO: Find someway to use an actual map to figure this all out - sooooo much looping and redundant assignments happening here. This is very messy
    def organize_db_import(self, run_only = True): 
        import psycopg2.extras
        self.ingest_files = []
        db_prefix = ""
        self.db_data_flow_metadata = self.configuration.db_data_flow_metadata # copy the configuration db import metadata to a pipeline attribute
        
        # Restructure the summary part of the services list to work with both regular and past events #ToDo: Find a way to get rid of this.
#         for summary_service in [service for service in self.pipeline_services if service['postprocess_summary'] is not None]:
#                 summary_service['postprocess_summary'] = {'summary': summary_service['postprocess_summary']}
#                 summary_service['postprocess_summary']['sql_args'] = []
        
        ##### If running a past event #####
        if self.job_type == "past_event":
            ref_prefix = f"ref_{self.configuration.reference_time.strftime('%Y%m%d_%H%M_')}" # replace invalid characters as underscores in ref time.
            if self.keep_raw:  # If storing raw data is desirable, add a ref_time prefix
                db_prefix = ref_prefix
            else:
                db_prefix = "temp_"
            
            # Update target tables to use the archive schema with dynamic table names, and start a rename dictionary to pass through to the postprocess_sql function to use the correct tables.
            for db_flow in self.db_data_flow_metadata:
                db_flow['original_table'] = db_flow['target_table']
                db_flow['target_table'] = 'archive' + '.' + db_prefix + 'raw_' + db_flow['target_table'].split('.')[1]
                self.sql_rename_dict.update({db_flow['original_table']: db_flow['target_table']})
            # Add new service tables as well
            for service in self.pipeline_services:
                self.sql_rename_dict.update({'publish.' + service['service']: 'archive' + '.' + db_prefix + service['service']})
            # Add new summary tables as well
            for service in [service for service in self.pipeline_services if service['postprocess_summary'] is not None]:
                self.sql_rename_dict.update({'publish.' + service['postprocess_summary']: 'archive' + '.' + db_prefix + service['postprocess_summary']})
        
        ########
        # Now, let's loop through all the input files in the configuration and assign db destination tables and keys now that we've completed the above logic.
        for s3_key in self.configuration.input_files:
            for db_flow in self.db_data_flow_metadata:
                if db_flow['step'] == 'ingest':
                    if db_flow['file_format']:
                        if re.match(db_flow['file_format'].replace("*d", r"\d"), os.path.basename(s3_key)):
                            original_table = db_flow['original_table'] if self.job_type == "past_event" else db_flow['target_table']
                            ingest_table = db_flow['target_table']
                            ingest_keys = db_flow['target_keys']
                    elif db_flow['flow_id'] == 1: #ToDo: This is sloppy, but I'm not sure how else to manage it right now.
                            original_table = db_flow['original_table'] if self.job_type == "past_event" else db_flow['target_table']
                            ingest_table = db_flow['target_table']
                            ingest_keys = db_flow['target_keys']
            self.ingest_files.append({'s3_key': s3_key, 'original_table': original_table, 'ingest_table': ingest_table, 'ingest_keys': ingest_keys}) # Add each file to the new pipeline ingest_files list.
        
    ###################################
    def monitor(self, monitor_txt, exception=None):
        self.monitor_code = 9999 if exception else self.monitor_code + 1
        self.monitor_txt = monitor_txt
        if exception: self.error = exception
        #self.es_logger.info(json.dumps([self.__dict__]))
        print(f"Monitor: {monitor_txt}")
    
    ###################################
    def __print__(self):
        print(f"""
        Viz Pipeline Run:
          Configuration: {self.configuration.name}
          Reference Times: {self.configuration.reference_time}
          Invocation Type: {self.invocation_type}
          Job Type: {self.job_type}
          Keep Raw Files: {self.keep_raw}
          Start Time: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}
        """)

###################################################################################################################################################
###################################################################################################################################################
class configuration:
    def __init__(self, name, reference_time=None, input_bucket=None, input_files=None): #TODO: Futher build out ref time range.
        self.name = name
        self.reference_time = reference_time
        self.input_bucket = input_bucket
        
        if input_files:
            self.input_files = input_files
        elif self.name == 'ahps':
            self.input_files = self.get_ahps_input_files(self.reference_time)
        elif (datetime.datetime.today() - datetime.timedelta(29)) > reference_time:
            self.input_files = self.get_nwm_input_files(self.reference_time, self.name, host='Google')
        else:
            self.input_files = self.get_nwm_input_files(self.reference_time, self.name)
        
        self.service_metadata = self.get_service_metadata()
        self.db_data_flow_metadata = self.get_db_data_flow_metadata()
        self.services_to_run = [service for service in self.service_metadata if service['run']] #Pull the relevant configuration services into a list.
        self.max_flows = list(set([service['postprocess_max_flows'] for service in self.services_to_run if service['postprocess_max_flows'] is not None])) #Unique list of max_flows
        self.summaries =  list(set([service['postprocess_summary'] for service in self.services_to_run if service['postprocess_summary'] is not None])) #Unique list of summaries

    ###################################
    @classmethod
    def from_s3_file(cls, s3_file, previous_forecasts=0, return_input_files=True, mrf_timestep=3): #TODO:Figure out impact on Corey's stuff to set this to default 3.
        filename = s3_file.key
        input_files = []
        if 'max_flows' in filename:
            matches = re.findall(r"max_flows/(.*)/(\d{8})/\D*_(\d+day_)?(\d{2})_max_flows.*", filename)[0]
            date = matches[1]
            hour = matches[3]
            configuration_name = matches[0]
            reference_time = datetime.datetime.strptime(f"{date[:4]}-{date[-4:][:2]}-{date[-2:]} {hour[-2:]}:00:00", '%Y-%m-%d %H:%M:%S')
            input_files.append(filename)
            days_match = re.findall(r"(\d+day)", filename)
            if days_match:
                configuration_name = f"{configuration_name}_{days_match[0]}"
        elif 'max_stage' in filename:
            matches = re.findall(r"max_stage/(.*)/(\d{8})/(\d{2})_(\d{2})_ahps_(.*).csv", filename)[0]
            date = matches[1]
            hour = matches[2]
            minute = matches[3]
            configuration_name = matches[0]
            reference_time = datetime.datetime.strptime(f"{date[:4]}-{date[-4:][:2]}-{date[-2:]} {hour[-2:]}:{minute[-2:]}:00", '%Y-%m-%d %H:%M:%S')
            input_files.append(filename)
            if 'forecasts' in filename:
                input_files.append(filename.replace("ahps_forecasts", "ahps_metadata"))
            elif 'metadata' in filename:
                input_files.append(filename.replace("ahps_metadata", "ahps_forecasts"))
        else:
            if 'analysis_assim' in filename:
                matches = re.findall(r"(.*)/nwm.(\d{8})/(.*)/nwm.t(\d{2})z\.(.*)\..*\.tm(.*)\.(.*)\.nc", filename)[0]
            elif 'short_range' in filename or 'medium_range_mem1' in filename:
                matches = re.findall(r"(.*)/nwm.(\d{8})/(.*)/nwm.t(\d{2})z\.(.*)\..*\.f(\d{3,5}).(.*)\.nc", filename)[0]
            else:
                raise Exception(f"Configuration not set for {filename}")
            date = matches[1]
            configuration_name = matches[2]
            hour = matches[3]
            model_type = matches[4]
            domain = matches[6]
            reference_time = datetime.datetime.strptime(f"{date[:4]}-{date[-4:][:2]}-{date[-2:]} {hour[-2:]}:00:00", '%Y-%m-%d %H:%M:%S')
            if return_input_files:
                # If replace and route or analysis assim 14 day, just return source file(s)
                if configuration_name == 'replace_route' or configuration_name == 'analysis_assim_14day':
                    input_files = [s3_file.key]
                    if configuration_name == 'analysis_assim_14day': # Add the second file for ana_14day
                        input_files.append(s3_file.key.replace('ana_14day', 'ana_7day'))
                else: #Use the get_input_files method for everything else.
                    input_files = cls.get_nwm_input_files(reference_time, configuration_name, model_type, domain, previous_forecasts=previous_forecasts, mrf_timestep=mrf_timestep) #TODO: This seems like a weird way to call this
        configuration = cls(configuration_name, reference_time=reference_time, input_bucket=s3_file.bucket, input_files=input_files)
        return configuration
    
    ################################### TODO: Should convert/re-write this to utilize the s3_file class? - See note below on check_input_files as well. I can't decide if this should be static or not.
    @staticmethod
    def get_nwm_input_files(reference_time, configuration_name, model_type=None, domain='conus', previous_forecasts=0, mrf_timestep=3, host='S3'): # TODO: Consider corey's functions that call this, need to specific mrf timestep to 1 for him.
        input_files = []
        if host == 'S3':
            key_prefix = 'common/data/model/com/nwm/prod'
        elif host == 'Google':
            key_prefix = 'gs://national-water-model'
        if not model_type:
            model_type = configuration_name.replace(domain, "").replace("_mem1", "")      
        if domain != 'conus' and configuration_name != "analysis_assim":
            forecast_length = 12  # hours
        elif model_type == 'medium_range':
            forecast_length = 6  # hours
        else:
            forecast_length = 1  # hours
        previous_hours = previous_forecasts * forecast_length  # compute hours between the desired forecasts
        # Loop through the desired forecasts
        for previous_hour in range(0, previous_hours+forecast_length, forecast_length):
            previous_date_time = reference_time - datetime.timedelta(hours=previous_hour)
            previous_date = previous_date_time.strftime("%Y%m%d")
            previous_hour = previous_date_time.strftime("%H")
            base_file = f"{key_prefix}/nwm.{previous_date}/{configuration_name}/nwm.t{previous_hour}z.{model_type}.channel_rt"
            if configuration_name in ['analysis_assim', 'analysis_assim_puertorico']:
                input_files.append(f"{base_file}.tm00.{domain}.nc")
            elif configuration_name == 'analysis_assim_hawaii':
                input_files.append(f"{base_file}.tm0000.{domain}.nc")
            else:
                if configuration_name == 'short_range_hawaii':
                    leads = []
                    for lead1 in range(0, 4800, 100):
                        for lead2 in [0, 15, 30, 45]:
                            lead = lead1+lead2
                            leads.append(f"{lead:05}")
                    leads.pop(0)
                    leads.append(f"{4800:05}")
                elif configuration_name == 'short_range':
                    leads = [f"{lead:03}" for lead in range(1, 19)]
                elif configuration_name == 'short_range_puertorico':
                    leads = [f"{lead:03}" for lead in range(1, 49)]
                elif configuration_name == 'medium_range_mem1':
                    if mrf_timestep == 3:
                        base_file = f"{base_file}_1"
                        leads = [f"{lead:03}" for lead in range(3, 241, 3)]
                    else:
                        base_file = f"{base_file}_1"
                        leads = [f"{lead:03}" for lead in range(1, 241)]
                else:
                    raise Exception(f"function not configured for {configuration_name}")
                for lead in leads:
                    input_files.append(f"{base_file}.f{lead}.{domain}.nc")        
        return sorted(input_files)
    
    ###################################
    @staticmethod
    def get_ahps_input_files(reference_time):
        input_files = []
        key_prefix = 'max_stage/ahps'
        date = reference_time.strftime("%Y%m%d")
        hour_min = reference_time.strftime("%H_%M")
        input_files.append(f"{key_prefix}/{date}/{hour_min}_ahps_forecasts.csv")
        input_files.append(f"{key_prefix}/{date}/{hour_min}_ahps_metadata.csv")
        return sorted(input_files)
    
    ################################### TODO: As noted above, we should consider how best to rewrite the s3 file checking since 1)it's not working all the time anyways, and 2) would be good to utilze the s3_file class.
    def check_input_files(self, file_threshold=100, retry=True, retry_limit=10):
        total_files = len(self.input_files)
        non_existent_files = []
        for key in self.input_files: #TODO: Set this back up as a list comprehension... not sure how to do that with the class initialization
            file = s3_file(self.input_bucket, key)
            if not file.check_existence():
                non_existent_files.append(file)
        if retry:
            files_ready = False
            retries = 0
            while not files_ready and retries < retry_limit:
                non_existent_files = [file for file in non_existent_files if not file.check_existence()]
                if not non_existent_files:
                    files_ready = True
                else:
                    print(f"Waiting 1 minute until checking for files again. Missing files {non_existent_files}")
                    time.sleep(60)
                    retries += 1
        available_files = []
        for key in self.input_files: #TODO: Set this back up as a list comprehension... not sure how to do that with the class initialization
            file = s3_file(self.input_bucket, key) 
            if file not in non_existent_files:
                available_files.append(file)
        if non_existent_files:
            if (len(available_files) * 100 / total_files) < file_threshold:
                raise Exception(f"Error - Failed to get the following files: {non_existent_files}")
        return True
    
    ###################################
    def get_service_metadata(self, specific_service=None, run_only=True):
        import psycopg2.extras
        service_filter = run_filter = ""
        if specific_service:
            service_filter = f"AND service = {specific_service}"
        if run_only:
            run_filter = " AND run is True"
        connection = database("viz").get_db_connection()
        with connection.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(f"SELECT * FROM admin.services_new WHERE configuration = '{self.name}' {service_filter} {run_filter};")
            column_names = [desc[0] for desc in cur.description]
            response = cur.fetchall()
            cur.close()
        connection.close()
        return list(map(lambda x: dict(zip(column_names, x)), response))
        
    ###################################
    def get_db_data_flow_metadata(self, specific_service=None, run_only=True):
        import psycopg2.extras
        # Get ingest source data from the database (the ingest_sources table is the authoritative dataset)
        extra_sql = service_filter = run_filter = ""
        if specific_service:
                service_filter = f"AND service = {specific_service}"
        if run_only:
            run_filter = " AND run is True"
        connection = database("viz").get_db_connection()
        with connection.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(f"""
                SELECT admin.services_new.service, flow_id, step, file_format, source_table, target_table, target_keys FROM admin.services_new
                JOIN admin.pipeline_data_flows ON admin.services_new.service = admin.pipeline_data_flows.service
                WHERE configuration = '{self.name}'{run_filter};
                """)
            column_names = [desc[0] for desc in cur.description]
            response = cur.fetchall()
            cur.close()
        connection.close()
        return list(map(lambda x: dict(zip(column_names, x)), response))

###################################################################################################################################################
###################################################################################################################################################
import logging
def get_elasticsearch_logger():
    logger = logging.getLogger('elasticsearch')
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        # Prevent logging from propagating to the root logger
        logger.propagate = 0
        console = logging.StreamHandler()
        logger.addHandler(console)
        formatter = logging.Formatter('[ELASTICSEARCH %(levelname)s]:  %(asctime)s - %(message)s')
        console.setFormatter(formatter)
    return logger