====================
Viz Optimize Rasters
====================

Event/Context
=============

- input_raster_bucket (required): S3 bucket where the input raster resides
- input_raster_key (required): S3 key for the input tif raster
- output_raster_bucket(required): S3 bucket where the output raster will reside
- output_raster_key (optional): S3 key for the output mrf raster

Process
=======

The Viz_Optimize_Rasters lambda performs the following main tasks:

Convert TIF to MRF
------------------

The specified TIF file will be converted to an MRF file using ESRI's OptimizeRasters code (https://github.com/Esri/OptimizeRasters)

Upload MRF Files
----------------

Converted MRF files will be uploaded to the mrf workspace location on S3.


Triggers
========

- Invoked by HUC Inundation lambda function

Layers
======

- mrf_rasterio


Additonal Environment Files
===========================

- Imagery_to_MRF_LERC.xml (Included in this repo)
- logger.py (Get from https://github.com/Esri/OptimizeRasters/blob/master/SolutionsLog/logger.py)
- OptimizeRasters.py (Get from https://github.com/Esri/OptimizeRasters/blob/master/OptimizeRasters.py)
