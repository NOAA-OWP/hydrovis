import boto3
import os
from viz_classes import database
from datetime import datetime, timedelta

###################################
def lambda_handler(event, context):
    step = event['step']

    if step == "update_summary_data":
        table = event['args']['service']['postprocess_summary']
    else:
        table = event['args']['service']['postprocess_service']

    job_type = event['args']['job_type']
    reference_time = datetime.strptime(event['args']['reference_time'], '%Y-%m-%d %H:%M:%S')
    service_server = event['args']['service']['egis_server']
    
    if service_server == "server":
        viz_db = database(db_type="viz")
        egis_db = database(db_type="egis")
        
        if job_type == 'auto':
            # Copy data to EGIS
            viz_db.move_data_to_another_db(dest_db_type="egis", origin_table=f"publish.{table}", dest_table=f"services.{table}", stage=True, add_oid=True, add_geom_index=True)
            egis_db.run_sql_in_db(f"SELECT UpdateGeometrySRID('services', '{table}', 'geom', 3857);")
            
            if os.environ['HYDROVIS_ENV'] == 'dev' or os.environ['HYDROVIS_ENV'] == 'ti':
                # Cache data in the database only in ti TODO: Revisit this with larger WPOD archive strategy.
                cache_data_in_db(viz_db, table, reference_time)
            
            # Save shapefile to s3 cache folder
            save_shapefile_to_s3(viz_db, "publish", table, reference_time)
        elif job_type == 'past_event':
            # Save shapefile to s3 cache folder
            save_shapefile_to_s3(viz_db, "archive", table, reference_time)
    else:
        if job_type == 'auto':
            viz_db = database(db_type="viz")
            egis_db = database(db_type="egis")
            service_name = event['args']['service']['service']
            # Copy data to EGIS
            viz_db.move_data_to_another_db(dest_db_type="egis", origin_table=f"publish.{service_name}", dest_table=f"services.{service_name}", stage=True, add_oid=True, add_geom_index=False)
            
        s3 = boto3.resource('s3')
        workspace_rasters = event['args']['output_rasters']
        service_name = event['args']['service']['service']
        
        mrf_extensions = ["idx", "til", "mrf", "mrf.aux.xml"]
        s3_bucket = event['args']['output_bucket']
        
        for s3_key in workspace_rasters:
            s3_object = {"Bucket": s3_bucket, "Key": s3_key}
            
            processing_prefix = s3_key.split(service_name,1)[0]
            cache_path = s3_key.split(service_name, 1)[1].replace('/workspace/tif', '')
            cache_key = f"{processing_prefix}{service_name}/cache{cache_path}"

            print(f"Caching {s3_key} at {cache_key}")
            s3.meta.client.copy(s3_object, s3_bucket, cache_key)
            
            print("Deleting tif workspace raster")
            s3.Object(s3_bucket, s3_key).delete()

            raster_name = os.path.basename(s3_key).replace(".tif", "")
            mrf_workspace_prefix = s3_key.replace("/tif/", "/mrf/").replace(".tif", "")
            published_prefix = f"{processing_prefix}{service_name}/published/{raster_name}"
            
            for extension in mrf_extensions:
                mrf_workspace_raster = {"Bucket": s3_bucket, "Key": f"{mrf_workspace_prefix}.{extension}"}
                mrf_published_raster = f"{published_prefix}.{extension}"
                
                if job_type == 'auto':
                    print(f"Moving {mrf_workspace_prefix}.{extension} to published location at {mrf_published_raster}")
                    s3.meta.client.copy(mrf_workspace_raster, s3_bucket, mrf_published_raster)
            
                print("Deleting a mrf workspace raster")
                s3.Object(s3_bucket, f"{mrf_workspace_prefix}.{extension}").delete()
    
    return True

###################################
def cache_data_in_db(db, table, reference_time, retention_days=7):
    retention_cutoff = reference_time - timedelta(retention_days)
    ref_prefix = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}"
    retention_prefix = f"ref_{retention_cutoff.strftime('%Y%m%d_%H%M_')}"
    new_archive_table = f"archive.{ref_prefix}{table}"
    cutoff_archive_table = f"archive.{retention_prefix}{table}"
    with db.get_db_connection() as connection:
        with connection.cursor() as curs:
            curs.execute(f'DROP TABLE IF EXISTS {new_archive_table};')
            curs.execute(f'DROP TABLE IF EXISTS {cutoff_archive_table};')
            curs.execute(f'SELECT * INTO {new_archive_table} FROM publish.{table};')
            connection.commit()
    print(f"---> Wrote cache data into {new_archive_table} and dropped corresponding table from {retention_days} days ago, if it existed.")

###################################   
def save_shapefile_to_s3(db, schema, table, reference_time):
    s3_client = boto3.client('s3')
    upload_bucket = os.environ['CACHE_BUCKET']
    service = table
    
    if schema == 'archive':
        table = f"ref_{reference_time.strftime('%Y%m%d_%H%M_')}{table}"
    
    gdf = db.run_sql_in_db(f"SELECT * FROM {schema}.{table};", return_geodataframe=True)
    #gdf.to_file(f'/tmp/{service}.shp', index=False)
    feather_file = f'/tmp/{service}.feather'
    gdf.to_feather(feather_file, index=False, compression="uncompressed")

    ref_day = f"{reference_time.strftime('%Y%m%d')}"
    ref_hour = f"{reference_time.strftime('%H%M')}"
    s3_key = f"viz_cache/{ref_day}/{ref_hour}/{service}.feather"
    print(f"Uploading {feather_file} to {upload_bucket}:/{s3_key}")
    s3_client.upload_file(feather_file, upload_bucket, s3_key)
    os.remove(feather_file)