import json
import boto3
import rasterio
import numpy as np
import pandas as pd
import geopandas as gpd
import concurrent.futures
import threading
import os
import time
import datetime

from viz_classes import s3_file, database

FR_FIM_BUCKET = os.environ['FR_FIM_BUCKET']
FR_FIM_PREFIX = os.environ['FR_FIM_PREFIX']

MS_FIM_BUCKET = os.environ['MS_FIM_BUCKET']
MS_FIM_PREFIX = os.environ['MS_FIM_PREFIX']


def lambda_handler(event, context):
    """
        The lambda handler is the function that is kicked off with the lambda. This function will coordinate
        the overall workflow from retrieving data, parsing it, kicking off the inundation workflow, saving the outputs,
        and then kicking off the next lambda which optimizes the raster for the cloud

        Args:
            event(event object): An event is a JSON-formatted document that contains data for a Lambda function to
                                 process
            context(object): Provides methods and properties that provide information about the invocation, function,
                             and runtime environment
    """
    # Parse the event argument to get the necessary arguments for the function
    huc = event['huc']
    s3_payload_json = event['s3_payload_json']
    data_bucket = event['data_bucket']
    data_prefix = event['data_prefix']
    local_payload_json = "/tmp/payload.json"
    
    print("Downloading payload file")
    s3 = boto3.client("s3")
    s3.download_file(data_bucket, s3_payload_json, local_payload_json)
    
    with open(local_payload_json) as f:
        payload_data = json.load(f)
    
    print("Parsing payload file")
    db_fim_table = payload_data['db_fim_table']
    reference_time = payload_data['reference_time']
    service = payload_data['service']
    inundation_mode = payload_data['inundation_mode']
    inundation_mode = "full_db"
    
    composite_mode = event['composite_mode'] if event.get('composite_mode') else 'composite'
    
    reference_date = datetime.datetime.strptime(reference_time, "%Y-%m-%d %H:%M:%S")
    date = reference_date.strftime("%Y%m%d")
    hour = reference_date.strftime("%H")
    huc8 = huc[:8]
    
    print(f"Processing FIM for huc {huc}")
    
    subsetted_streams = f"{data_prefix}/{service}/workspace/{date}/{hour}/data/{huc8}_data.csv"
    output_raster_key_prefix = f'{data_prefix}/{service}/workspace/{date}/{hour}/tif'

    print(f"Processing HUC {huc} for {service} for {date}T{hour}:00:00Z")

    # Use this list to keep track if main stem/full resolution can/will be used
    config_passes = []

    # Validate main stem datasets by checking cathment, hand, and rating curves existence for the HUC
    ms_stage_lookup = pd.DataFrame()
    if composite_mode in ['composite', 'ms']:
        ms_catchment_key = f'{MS_FIM_PREFIX}/{huc8}/gw_catchments_reaches_filtered_addedAttributes.tif'
        ms_catch_exists = s3_file(MS_FIM_BUCKET, ms_catchment_key).check_existence()

        ms_hand_key = f'{MS_FIM_PREFIX}/{huc8}/rem_zeroed_masked.tif'
        ms_hand_exists = s3_file(MS_FIM_BUCKET, ms_hand_key).check_existence()

        ms_rating_curve_key = f'{MS_FIM_PREFIX}/{huc8}/hydroTable.csv'
        ms_rating_curve_exists = s3_file(MS_FIM_BUCKET, ms_rating_curve_key).check_existence()

        if ms_catch_exists and ms_hand_exists and ms_rating_curve_exists:
            config_passes.append('ms')
            print("->Calculating flood depth for valid streams in the main stem dataset")
            ms_stage_lookup = get_reach_stage_lookup(data_bucket, subsetted_streams, 'ms', huc)  # get stages
        else:
            print(f"Main stem dataset (catchment, hand, or rating curve) are missing for huc {huc8}")

    # Validate full resolution datasets by checking cathment, hand, and rating curves existence for the HUC
    fr_stage_lookup = pd.DataFrame()
    if "rfc" not in service and composite_mode in ['composite', 'fr']:
        fr_catchment_key = f'{FR_FIM_PREFIX}/{huc8}/gw_catchments_reaches_filtered_addedAttributes.tif'
        fr_catch_exists = s3_file(FR_FIM_BUCKET, fr_catchment_key).check_existence()

        fr_hand_key = f'{FR_FIM_PREFIX}/{huc8}/rem_zeroed_masked.tif'
        fr_hand_exists = s3_file(FR_FIM_BUCKET, fr_hand_key).check_existence()

        fr_rating_curve_key = f'{FR_FIM_PREFIX}/{huc8}/hydroTable.csv'
        fr_rating_curve_exists = s3_file(FR_FIM_BUCKET, fr_rating_curve_key).check_existence()

        if fr_catch_exists and fr_hand_exists and fr_rating_curve_exists:
            config_passes.append('fr')
            print("->Calculating flood depth for valid streams in the full resolution dataset")
            fr_stage_lookup = get_reach_stage_lookup(data_bucket, subsetted_streams, 'fr', huc)  # get stages
        else:
            print(f"Full resolution dataset (catchment, hand, or rating curve) are missing for huc {huc8}")

    # If no valid datasets exist for the desired run configuration, then raise an exception
    if not config_passes:
        raise Exception(f"No HAND datasets available for huc {huc8}")
        
    # If no features with above zero stages are present, then just copy an unflood raster instead of processing nothing
    if fr_stage_lookup.empty and ms_stage_lookup.empty:
        print("No reaches with valid stages")
        return

    # Run the desired configuration
    create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_mode, reference_time, db_fim_table, output_raster_key_prefix)
    
    print(f"Successfully processed tif for HUC {huc} for {service} for {reference_time}")

    return


def create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_mode, reference_time, db_fim_table, output_raster_key_prefix):
    """
        Creates the actual inundation output from the stages, catchments, and hand grids

        Args:
            huc(str): HUC that is being processed
            fr_stage_lookup(str): list of lists that have a feature id with its corresponding stage for full resolution
            ms_stage_lookup(str): list of lists that have a feature id with its corresponding stage for main stem
            inundation_raster(str): local tif output for inundation
            inundation_mode(str): mode for how the inundation will be processed. mask will mask the depths to create
                                  a flood extent. depth will create depth grids
    """
    # Only process inundation configuration if available data
    s3 = boto3.client('s3')
    db_schema = db_fim_table.split(".")[0]
    db_table = db_fim_table.split(".")[-1]
    huc8 = huc[:8]
    
    config_passes = []
    if not fr_stage_lookup.empty:
        config_passes.append("fr")

    if not ms_stage_lookup.empty:
        config_passes.append("ms")
        
    processed_rasters = []

    # join metadata to get path to FIM datasets
    fim_bucket = MS_FIM_BUCKET
    fr_catchment_key = f'{FR_FIM_PREFIX}/{huc8}/gw_catchments_reaches_filtered_addedAttributes.tif'
    fr_hand_key = f'{FR_FIM_PREFIX}/{huc8}/rem_zeroed_masked.tif'
    ms_catchment_key = f'{MS_FIM_PREFIX}/{huc8}/gw_catchments_reaches_filtered_addedAttributes.tif'
    ms_hand_key = f'{MS_FIM_PREFIX}/{huc8}/rem_zeroed_masked.tif'

    ms_hand_dataset = None
    ms_catchment_dataset = None
    fr_hand_dataset = None
    fr_catchment_dataset = None
    
    for config_pass in config_passes:
        try:
            print(f"Creating inundation for {config_pass}")
            
            # Create a folder for the local tif outputs
            raw_inundation_raster = f'/tmp/raw_rasters/{config_pass}_{huc}_raw.tif'
            final_inundation_raster = f'/tmp/raw_rasters/{config_pass}_{huc}_final.tif'
            if not os.path.exists('/tmp/raw_rasters/'):
                os.mkdir('/tmp/raw_rasters/')
            
            if config_pass == "ms":
                fim_bucket = MS_FIM_BUCKET
                fim_prefix = MS_FIM_PREFIX
                hand_key = ms_hand_key
                catchment_key = ms_catchment_key
                stage_lookup = ms_stage_lookup
            else:
                fim_bucket = FR_FIM_BUCKET
                fim_prefix = FR_FIM_PREFIX
                hand_key = fr_hand_key
                catchment_key = fr_catchment_key
                stage_lookup = fr_stage_lookup
            
            print("--> Setting up mapping array")
            tries = 0
            raster_open_success = False
            while tries < 3:
                try:
                    hand_dataset = rasterio.open(f's3://{fim_bucket}/{hand_key}')  # open HAND grid from S3
                    catchment_dataset = rasterio.open(f's3://{fim_bucket}/{catchment_key}')  # open catchment grid from S3  # noqa
                    tries = 3
                    raster_open_success = True
                except Exception as e:
                    tries += 1
                    time.sleep(30)
                    print(f"Failed to open datasets. Trying again in 30 seconds - ({e})")
    
            if not raster_open_success:
                raise Exception("Failed to open HAND and Catchment datasets")
                
            catchment_nodata = int(catchment_dataset.nodata)  # get no_data value for catchment raster
            valid_catchments = stage_lookup.index.tolist() # parse lookup to get features with >0 stages  # noqa
            hydroids = stage_lookup.index.tolist()  # parse lookup to get all features
            stages = stage_lookup['interpolated_stage_m'].tolist()  # parse lookup to get all stages
    
            k = np.array(hydroids)  # Create a feature numpy array from the list
            v = np.array(stages)  # Create a stage numpy array from the list
    
            hydro_id_max = k.max()  # Get the max feature id in the array
    
            hand_nodata = hand_dataset.nodata  # get the no_data value for the HAND raster
            hand_dtype = hand_dataset.dtypes[0]  # get the dtype for the HAND raster
            profile = hand_dataset.profile  # get the rasterio profile so the output can use the profile and match the input  # noqa
    
            # set the output nodata to 0
            profile['nodata'] = 0
            profile['dtype'] = "int32"
    
            # create a read and write lock to handle multiple processes accessing data
            read_lock = threading.Lock()
            write_lock = threading.Lock()
    
            # Open the output raster using rasterio. This will allow the inner function to be parallel and write to it
            with rasterio.open(raw_inundation_raster, "w", **profile) as dst:
                print("--> Setting up windows")
    
                # Get the list of windows according to the raster metadata so they can be looped through
                windows = [window for ij, window in dst.block_windows()]
    
                # This function will be run for each raster window.
                def process(window):
                    """
                        This function is run for each raster window in parallel. The function will read in the appropriate
                        window of the HAND and catchment datasets for main stem and/or full resolution. The stages will
                        then be mapped from a numpy array to the catchment window. This will create a windowed stage array.
                        The stage array is then compared to the HAND window array to create an inundation array where the
                        HAND values are gte to the stage values.
    
                        Each windowed inundation array is then saved to the output array for that specific window that was
                        ran.
    
                        For more information on rasterio window processing, see
                        https://rasterio.readthedocs.io/en/latest/topics/windowed-rw.html
    
                        If main stem AND full resolution are ran, then the inundation arrays for each configuration will be
                        compared and the highest value for each element in the array will be used. This is how we 'merge'
                        the two configurations. Because the extents of fr and ms are not the same, we do have to reshape
                        the arrays a bit to allow for the comparison
                    """
                    with read_lock:
                        catchment_window = catchment_dataset.read(window=window)  # Read the dataset for the specified window  # noqa
    
                        unique_window_catchments = np.unique(catchment_window).tolist()  # Get a list of unique hydroids within the window  # noqa
                        window_valid_catchments = [catchment for catchment in unique_window_catchments if catchment in valid_catchments]  # Check to see if any hydroids with stages >0 are inside this window  # noqa
                        # Only process if there are hydroids with stage >0 in this window
                        if not window_valid_catchments:
                            return 
    
                        hand_window = hand_dataset.read(window=window)
                        
                    # Create an empty numpy array with the nodata value that will be overwritten
                    inundation_window = np.full(catchment_window.shape, hand_nodata, hand_dtype)
    
                    # If catchment window values exist, then find the max between the stage mapper and the window
                    mapping_ar_max = max(hydro_id_max, catchment_window.max())
    
                    # Create a stage mapper that will convert hydroids to their corresponding stage. -9999 is null or
                    # no value. we cant use 0 because it will mess up the mapping and use the 0 index
                    mapping_ar = np.full(mapping_ar_max+1, -9999, dtype="float32")
                    mapping_ar[k] = v
    
                    catchment_window[np.where(catchment_window == catchment_nodata)] = 0  # Convert catchment values to 0 where the catchment = catchment_nodata  # noqa
                    catchment_window[np.where(hand_window == hand_nodata)] = 0  # Convert catchment values to 0 where the HAND = HAND_nodata. THis will ensure we are only processing where we have HAND values!  # noqa
    
                    reclass_window = mapping_ar[catchment_window]  # Convert the catchment to stage
    
                    condition1 = reclass_window > hand_window  # Select where stage is gte to HAND
                    condition2 = reclass_window != -9999  # Select where stage is valid
                    conditions = (condition1) & (condition2)
    
                    inundation_window = np.where(conditions, catchment_window, 0).astype('int32')
    
                    # Checking to see if there is any inundated areas in the window
                    if not inundation_window[np.where(inundation_window != 0)].any():
                        return 
    
                    # Write the final windowed inundation to the destination raster for the specified window
                    with write_lock:
                        dst.write(inundation_window, window=window)
    
                    if np.max(inundation_window) != 0:
                        from rasterio.features import shapes
                        mask = None
                        results = (
                        {'hydro_id': int(v), 'geom': s}
                        for i, (s, v) 
                        in enumerate(
                            shapes(inundation_window, mask=mask, transform=rasterio.windows.transform(window, dst.transform))) if int(v))
                            
                        return list(results)
    
                # Use threading to parallelize the processing of the inundation windows
                geoms = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                    result_futures = list(map(lambda window: executor.submit(process, window), windows))
                    for future in concurrent.futures.as_completed(result_futures):
                        try:
                            if future.result() is not None:
                                results = future.result()
                                geoms.extend(results)
                            
                        except Exception as e:
                            print(e)
                            
        except Exception as e:
            raise e
        finally:
            if hand_dataset is not None:
                hand_dataset.close()
    
            if catchment_dataset is not None:
                catchment_dataset.close()

        print("Generating polygons")
        from shapely.geometry import shape
        geom = [shape(i['geom']) for i in geoms]
        hydro_ids = [i['hydro_id'] for i in geoms]
        df_final = gpd.GeoDataFrame({'geom':geom, 'hydro_id': hydro_ids}, crs="ESRI:102039", geometry="geom")
        df_final = df_final.dissolve(by="hydro_id")
        df_final = df_final.to_crs(3857)
        df_final = df_final.set_crs('epsg:3857')
            
        df_final = df_final.join(stage_lookup).dropna()
        
        df_final = df_final.drop_duplicates()
        
        print("Adding additional metadata columns")
        df_final = df_final.reset_index()
        df_final['fim_version'] = fim_prefix.split("fim_")[-1].split(f"_{config_pass}")[0]
        df_final['reference_time'] = reference_time
        df_final['huc8'] = huc8
        df_final['fim_configuration'] = config_pass
        df_final['interpolated_stage_ft'] = round(df_final['interpolated_stage_m'] * 3.28084, 2)
        df_final['max_rc_stage_ft'] = df_final['max_rc_stage_m'] * 3.28084
        df_final['max_rc_stage_ft'] = df_final['max_rc_stage_ft'].astype(int)
        df_final['streamflow_cfs'] = round(df_final['streamflow_cms'] * 35.315, 2)
        df_final['max_rc_discharge_cfs'] = round(df_final['max_rc_discharge_cms'] * 35.315, 2)
        df_final['hydro_id_str'] = df_final['hydro_id'].astype(str)
        df_final['feature_id_str'] = df_final['feature_id'].astype(str)

        df_final = df_final.drop(columns=["interpolated_stage_m", "max_rc_stage_m", "streamflow_cms", "max_rc_discharge_cms", "reference_time"])
    
        print(f"Adding data to {db_fim_table}")
        db_type = "viz"
        if db_table.startswith("rf_"):
            db_type = "egis"
            
        process_db = database(db_type=db_type)
        db_engine = process_db.get_db_engine()
        df_final.to_postgis(db_table, con=db_engine, schema=db_schema, if_exists='append')
                
    return df_final


def get_reach_stage_lookup(data_csv_bucket, data_csv_key, config, huc):
    """
        Main function for converting streamflows to stages. Downloads the hydrotable and json file with the streamflow
        data. The streamflow data is then compared to the rating curve to determine interpolated stages.

        Args:
            data_csv_key(str): key (path) to the S3 json file that contains the streamflow data for the huc
            config(str): ms (main stem) or fr (full resolution) configuration
            huc(str): HUC that is being processed
            forecast_file(str): key (path) to the S3 max flows/nwm file used for overall service

        Returns:
            stage_lookup(list): list of list showing hydroids with interpolated stages. -9999 is no stage. [[100, 1],
                                [101, -9999], [102, 3], ...]
    """
    print("-->Getting rating curve data")
    s3 = boto3.client('s3')

    # These are local files that will be created from downloading S3 data
    local_hydrotable = f"/tmp/{config}_hydroTable.csv"
    local_data = "/tmp/data.csv"
    huc8 = huc[:8]

    # Get the appropriate bucket and key prefix for the FIM datasets
    if config == 'fr':
        config_bucket = FR_FIM_BUCKET
        config_prefix = FR_FIM_PREFIX
    elif config == 'ms':
        config_bucket = MS_FIM_BUCKET
        config_prefix = MS_FIM_PREFIX
    else:
        raise Exception(f"{config} is invalid. Config must be fr or ms")

    # Download the rating curve from S3 and put it into a pandas dataframe
    hydro_table_key = f'{config_prefix}/{huc8}/hydroTable.csv'

    s3.download_file(config_bucket, hydro_table_key, local_hydrotable)
    df_hydro = pd.read_csv(local_hydrotable)
    os.remove(local_hydrotable)
    
    # Download the csv data from S3
    s3.download_file(data_csv_bucket, data_csv_key, local_data)
    df_forecast = pd.read_csv(local_data)
    os.remove(local_data)

    # Just grab the streamflow field for rating curve comparison
    df_hydro = df_hydro.merge(df_forecast, on="feature_id")

    if df_hydro.empty:
        print(f"No Valid Reaches to Process")
        return pd.DataFrame()
        
    # Ignore reaches that are lakes
    df_hydro = df_hydro[df_hydro['LakeID'] == -999]

    df_hydro = df_hydro.rename(columns={"HydroID":"hydro_id"})
    df_hydro = df_hydro.set_index('hydro_id')

    # Grab the largest stage value for each processed reach for later db
    # dump and metadata configuration
    df_hydro_max = df_hydro.sort_values('stage').groupby('hydro_id').tail(1)
    df_hydro_max = df_hydro_max[['stage', 'discharge_cms']].rename(columns={'stage': 'max_rc_stage_m', 'discharge_cms': 'max_rc_discharge_cms'})

    # Shift the stage/flow values for next rating curve step so each row has a
    # range of flows/stages for the specific rating curve step
    df_hydro['next_discharge_cms'] = df_hydro.groupby('hydro_id')['discharge_cms'].shift(-1)
    df_hydro['next_stage'] = df_hydro.groupby('hydro_id')['stage'].shift(-1)

    # Select reaches where the flow is between the discharge column and the next discharge column
    condition1 = (df_hydro['streamflow_cms'] >= df_hydro['discharge_cms'])
    condition2 = (df_hydro['streamflow_cms'] <= df_hydro['next_discharge_cms'])
    condition3 = df_hydro['next_discharge_cms'].isna()

    df_hydro = df_hydro[condition1 & (condition2 | condition3)]

    # Remove any duplicated hydroids. This happens with some weird rating curve behavior
    # where larger stages and lower flow thresholds. Grab the lowest passed stage
    df_hydro = df_hydro[~df_hydro.index.duplicated()]

    # Calculate the interpolated (linearly) stages using the stage rate of change and the discharge change
    stage_rate_of_change = ((df_hydro['next_stage'] - df_hydro['stage']) / (df_hydro['next_discharge_cms'] - df_hydro['discharge_cms']))  # noqa
    discharge_change = df_hydro['streamflow_cms'] - df_hydro['discharge_cms']
    df_hydro['interpolated_stage_m'] = df_hydro['stage'] + discharge_change * stage_rate_of_change

    # Make the interpolated stage equal to the max stage for reaches whose streamflow exceeds the max streamflow in the rating curve
    df_hydro.loc[df_hydro['interpolated_stage_m'].isna(), 'interpolated_stage_m'] = df_hydro['stage']
    df_hydro['interpolated_stage_m'] = df_hydro['interpolated_stage_m'].round(2)
    df_hydro = df_hydro[(df_hydro['interpolated_stage_m'] != 0)]
    df_hydro = df_hydro[['feature_id', 'streamflow_cms', 'interpolated_stage_m']]
    
    df_hydro = df_hydro.join(df_hydro_max)

    print(f"Expecting to process {len(df_hydro)} rows")
    
    return df_hydro
