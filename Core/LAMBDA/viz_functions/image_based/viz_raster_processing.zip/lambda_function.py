import boto3
import os
import rioxarray as rxr
from rasterio.crs import CRS
from datetime import datetime

OUTPUT_BUCKET = os.environ['OUTPUT_BUCKET']
OUTPUT_PREFIX = os.environ['OUTPUT_PREFIX']

def lambda_handler(event, context):
    service_name = event['service']['service']
    try:
        func = getattr(__import__(f"services.{service_name}", fromlist=["main"]), "main")
    except AttributeError:
        raise Exception(f'function not found {service_name}')

    uploaded_rasters = func(event['service'], event['reference_time'])

    event['output_rasters'] = uploaded_rasters
    
    del event['service']['input_files']
    del event['service']['bucket']
        
    return event

def open_raster(bucket, file, variable):
    print(f"Opening {variable} in raster for {file}")
    s3 = boto3.client('s3')

    download_path = f'/tmp/{os.path.basename(file)}'
    s3.download_file(bucket, file, download_path)

    ds = rxr.open_rasterio(download_path)
    
    os.remove(download_path)
    
    return ds[variable]

def create_raster(data, crs):
    print(f"Creating raster for {data.name}")
    data.rio.write_crs(crs, inplace=True)
    data.rio.write_nodata(0, inplace=True)
    if "grid_mapping" in data.attrs:
        data.attrs.pop("grid_mapping")
        
    if "_FillValue" in data.attrs:
        data.attrs.pop("_FillValue")

    local_raster = f'/tmp/{data.name}.tif'

    print(f"Saving raster to {local_raster}")
    data.rio.to_raster(local_raster)
    
    return local_raster

def upload_raster(reference_time, local_raster, service_name, raster_name):
    reference_date = datetime.strptime(reference_time, "%Y-%m-%d %H:%M:%S")
    date = reference_date.strftime("%Y%m%d")
    hour = reference_date.strftime("%H")
    
    s3_raster_key = f"{OUTPUT_PREFIX}/{service_name}/{date}/{hour}/workspace/tif/{raster_name}.tif"
    
    print(f"--> Uploading raster to s3://{OUTPUT_BUCKET}/{s3_raster_key}")
    s3 = boto3.client('s3')
    
    s3.upload_file(local_raster, OUTPUT_BUCKET, s3_raster_key)
    os.remove(local_raster)

    return {"Bucket": OUTPUT_BUCKET, "Key": s3_raster_key}

def sum_rasters(bucket, input_files, variable):
    print(f"Adding {variable} rasters")
    sum_initiated = False
    for input_file in input_files:
        data = open_raster(bucket, input_file, variable)
        
        if not sum_initiated:
            data_sum = data.squeeze('time')
            crs = CRS.from_proj4(data.proj4)
            sum_initiated = True
        else:
            data_sum += data.squeeze('time')
            
    return data_sum, crs
