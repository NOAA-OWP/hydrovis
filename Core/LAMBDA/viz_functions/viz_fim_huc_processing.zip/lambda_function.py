import boto3
import rasterio
import numpy as np
import pandas as pd
import concurrent.futures
import threading
import os
import re

from viz_classes import s3_file, database
from es_logging import get_elasticsearch_logger
es_logger = get_elasticsearch_logger()

FR_FIM_BUCKET = os.environ['FR_FIM_BUCKET']
FR_FIM_PREFIX = os.environ['FR_FIM_PREFIX']

MS_FIM_BUCKET = os.environ['MS_FIM_BUCKET']
MS_FIM_PREFIX = os.environ['MS_FIM_PREFIX']

PROCESSED_OUTPUT_BUCKET = os.environ['PROCESSED_OUTPUT_BUCKET']
PROCESSED_OUTPUT_PREFIX = os.environ['PROCESSED_OUTPUT_PREFIX']


def lambda_handler(event, context):
    """
        The lambda handler is the function that is kicked off with the lambda. This function will coordinate
        the overall workflow from retrieving data, parsing it, kicking off the inundation workflow, saving the outputs,
        and then kicking off the next lambda which optimizes the raster for the cloud

        Args:
            event(event object): An event is a JSON-formatted document that contains data for a Lambda function to
                                 process
            context(object): Provides methods and properties that provide information about the invocation, function,
                             and runtime environment
    """
    # Parse the event argument to get the necessary arguments for the function
    print(event)
    subsetted_streams = event['args']['data_key']
    db_fim_table = event['args']['db_fim_table']
    configuration, date, hour, huc = get_file_metadata(subsetted_streams)
    composite_mode = event['args']['composite_mode'] if 'composite_mode' in event else 'composite'
    inundation_mode = event['args']['inundation_mode'] if 'inundation_mode' in event else 'mask'

    print(f"Processing {huc} with the following data: {subsetted_streams}")

    es_logger.info(f"Processing HUC {huc} for {configuration} for {date}T{hour}:00:00Z")

    # Use this list to keep track if main stem/full resolution can/will be used
    config_passes = []

    # Validate main stem datasets by checking cathment, hand, and rating curves existence for the HUC
    if composite_mode in ['composite', 'ms']:
        ms_catchment_key = f'{MS_FIM_PREFIX}/{huc}/gw_catchments_reaches_filtered_addedAttributes.tif'
        ms_catch_exists = s3_file(MS_FIM_BUCKET, ms_catchment_key).check_existence()

        ms_hand_key = f'{MS_FIM_PREFIX}/{huc}/rem_zeroed_masked.tif'
        ms_hand_exists = s3_file(MS_FIM_BUCKET, ms_hand_key).check_existence()

        ms_rating_curve_key = f'{MS_FIM_PREFIX}/{huc}/hydroTable.csv'
        ms_rating_curve_exists = s3_file(MS_FIM_BUCKET, ms_rating_curve_key).check_existence()

        if ms_catch_exists and ms_hand_exists and ms_rating_curve_exists:
            config_passes.append('ms')
        else:
            print(f"Main stem dataset (catchment, hand, or rating curve) are missing for huc {huc}")

    # Validate full resolution datasets by checking cathment, hand, and rating curves existence for the HUC
    if configuration != 'replace_route' and composite_mode in ['composite', 'fr']:
        fr_catchment_key = f'{FR_FIM_PREFIX}/{huc}/gw_catchments_reaches_filtered_addedAttributes.tif'
        fr_catch_exists = s3_file(FR_FIM_BUCKET, fr_catchment_key).check_existence()

        fr_hand_key = f'{FR_FIM_PREFIX}/{huc}/rem_zeroed_masked.tif'
        fr_hand_exists = s3_file(FR_FIM_BUCKET, fr_hand_key).check_existence()

        fr_rating_curve_key = f'{FR_FIM_PREFIX}/{huc}/hydroTable.csv'
        fr_rating_curve_exists = s3_file(FR_FIM_BUCKET, fr_rating_curve_key).check_existence()

        if fr_catch_exists and fr_hand_exists and fr_rating_curve_exists:
            config_passes.append('fr')
        else:
            print(f"Full resolution dataset (catchment, hand, or rating curve) are missing for huc {huc}")

    # If no valid datasets exist for the desired run configuration, then raise an exception
    if not config_passes:
        raise Exception(f"No HAND datasets available for huc {huc}")

    # Run the desired configuration
    print(f"Processing {' and '.join(config_passes)} FIM for {huc}. Outputs will be put in {db_fim_table}")  # noqa
    calc_inundation(subsetted_streams, config_passes, inundation_mode, db_fim_table)  # noqa

    return

def get_file_metadata(file):
    matches = re.findall("/(.*)/workspace/(\d{8})/(\d{2})/data/(\d{8})_data.csv", file)[0]

    configuration = matches[0]
    date = matches[1]
    hour = matches[2]
    huc = matches[3]
    
    return configuration, date, hour, huc

def calc_inundation(subsetted_streams, config_passes, inundation_mode, db_fim_table):
    """
        Main inundation function that handles the inundation workflow from convering streamflows to stage, creating
        local inundation output, and then saving the output to an S3 bucket.

        Args:
            subsetted_streams(dictionary): dictionary containing feaure ids as keys with streamflows as the value
            config_passes(list): list that determines if full resolution (fr) and/or main stem (ms) will be run
            huc(str): HUC that is being processed
            output_bucket(str): S3 bucket where the inundation tif will be copied
            output_key(str): key (path) where the S3 tif raster will be saved
            max_flows_key(str): key (path) of the max flows file that was used to get the streamflow data
            inundation_mode(str): mode for how the inundation will be processed. mask will mask the depths to create
                                  a flood extent. depth will create depth grids

        Returns:
            Boolean: True if the raster was created successfully, else False
    """
    configuration, date, hour, huc = get_file_metadata(subsetted_streams)
    reference_time = f"{date[:4]}-{date[4:6]}-{date[6:]}T{hour}:00:00Z"
    
    # Get stage data for full resolution configuration
    fr_stage_lookup = pd.DataFrame()
    if 'fr' in config_passes:
        print("->Calculating flood depth for valid streams in the full resolution dataset")
        fr_stage_lookup = get_reach_stage_lookup(subsetted_streams, 'fr', huc)  # get stages

    # Get stage data for main stem configuration
    ms_stage_lookup = pd.DataFrame()
    if 'ms' in config_passes:
        print("->Calculating flood depth for valid streams in the main stem dataset")
        ms_stage_lookup = get_reach_stage_lookup(subsetted_streams, 'ms', huc)  # get stages

    # If no features with above zero stages are present, then just copy an unflood raster instead of processing nothing
    if fr_stage_lookup.empty and ms_stage_lookup.empty:
        print("No reaches with valid stages")
        return False

    create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_mode, reference_time, db_fim_table)

    es_logger.info(f"Successfully processed tif for HUC {huc} for {configuration} for {date}T{hour}:00:00Z")

    return


def create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_mode, reference_time, db_fim_table):
    """
        Creates the actual inundation output from the stages, catchments, and hand grids

        Args:
            huc(str): HUC that is being processed
            fr_stage_lookup(str): list of lists that have a feature id with its corresponding stage for full resolution
            ms_stage_lookup(str): list of lists that have a feature id with its corresponding stage for main stem
            inundation_raster(str): local tif output for inundation
            inundation_mode(str): mode for how the inundation will be processed. mask will mask the depths to create
                                  a flood extent. depth will create depth grids
    """
    # Only process inundation configuration if available data
    s3 = boto3.client('s3')
    viz_db = database(db_type="viz")
    db_engine = viz_db.get_db_engine()
    db_schema = db_fim_table.split(".")[0]
    db_table = db_fim_table.split(".")[-1]
    
    config_passes = []
    if not fr_stage_lookup.empty:
        config_passes.append("fr")

    if not ms_stage_lookup.empty:
        config_passes.append("ms")
        
    processed_rasters = []

    # join metadata to get path to FIM datasets
    fim_bucket = MS_FIM_BUCKET
    fr_catchment_key = f'{FR_FIM_PREFIX}/{huc}/gw_catchments_reaches_filtered_addedAttributes.tif'
    fr_hand_key = f'{FR_FIM_PREFIX}/{huc}/rem_zeroed_masked.tif'
    ms_catchment_key = f'{MS_FIM_PREFIX}/{huc}/gw_catchments_reaches_filtered_addedAttributes.tif'
    ms_hand_key = f'{MS_FIM_PREFIX}/{huc}/rem_zeroed_masked.tif'

    ms_hand_dataset = None
    ms_catchment_dataset = None
    fr_hand_dataset = None
    fr_catchment_dataset = None
    
    for config_pass in config_passes:
        min_col = None
        min_row = None
        max_col = None
        max_row = None
        max_height = None
        max_width = None
        try:
            print(f"Creating inundation for {config_pass}")
            
            # Create a folder for the local tif outputs
            raw_inundation_raster = f'/tmp/raw_rasters/{config_pass}_{huc}_raw.tif'
            final_inundation_raster = f'/tmp/raw_rasters/{config_pass}_{huc}_final.tif'
            if not os.path.exists('/tmp/raw_rasters/'):
                os.mkdir('/tmp/raw_rasters/')
            
            if config_pass == "ms":
                fim_bucket = MS_FIM_BUCKET
                fim_prefix = MS_FIM_PREFIX
                hand_key = ms_hand_key
                catchment_key = ms_catchment_key
                stage_lookup = ms_stage_lookup
            else:
                fim_bucket = FR_FIM_BUCKET
                fim_prefix = FR_FIM_PREFIX
                hand_key = fr_hand_key
                catchment_key = fr_catchment_key
                stage_lookup = fr_stage_lookup
            
            print("--> Setting up mapping array")
            tries = 0
            while tries < 3:
                try:
                    hand_dataset = rasterio.open(f's3://{fim_bucket}/{hand_key}')  # open HAND grid from S3
                    catchment_dataset = rasterio.open(f's3://{fim_bucket}/{catchment_key}')  # open catchment grid from S3  # noqa
                    tries = 3
                except Exception as e:
                    tries += 1
                    print(f"Failed to open datasets. Trying again - ({e})")
    
            catchment_nodata = int(catchment_dataset.nodata)  # get no_data value for catchment raster
            valid_catchments = stage_lookup.index.tolist() # parse lookup to get features with >0 stages  # noqa
            hydroids = stage_lookup.index.tolist()  # parse lookup to get all features
            stages = stage_lookup['interpolated_stage_m'].tolist()  # parse lookup to get all stages
    
            k = np.array(hydroids)  # Create a feature numpy array from the list
            v = np.array(stages)  # Create a stage numpy array from the list
    
            hydro_id_max = k.max()  # Get the max feature id in the array
    
            hand_nodata = hand_dataset.nodata  # get the no_data value for the HAND raster
            hand_dtype = hand_dataset.dtypes[0]  # get the dtype for the HAND raster
            profile = hand_dataset.profile  # get the rasterio profile so the output can use the profile and match the input  # noqa
    
            # set the output nodata to 0
            profile['nodata'] = 0
            nbits = 0
            
            if inundation_mode == 'mask':
                profile['nodata'] = 0
                profile['dtype'] = "int32"
                nbits = 32
    
            # create a read and write lock to handle multiple processes accessing data
            read_lock = threading.Lock()
            write_lock = threading.Lock()
    
            # Open the output raster using rasterio. This will allow the inner function to be parallel and write to it
            with rasterio.open(raw_inundation_raster, "w", **profile) as dst:
                print("--> Setting up windows")
    
                # Get the list of windows according to the raster metadata so they can be looped through
                windows = [window for ij, window in dst.block_windows()]
    
                # This function will be run for each raster window.
                def process(window):
                    """
                        This function is run for each raster window in parallel. The function will read in the appropriate
                        window of the HAND and catchment datasets for main stem and/or full resolution. The stages will
                        then be mapped from a numpy array to the catchment window. This will create a windowed stage array.
                        The stage array is then compared to the HAND window array to create an inundation array where the
                        HAND values are gte to the stage values.
    
                        Each windowed inundation array is then saved to the output array for that specific window that was
                        ran.
    
                        For more information on rasterio window processing, see
                        https://rasterio.readthedocs.io/en/latest/topics/windowed-rw.html
    
                        If main stem AND full resolution are ran, then the inundation arrays for each configuration will be
                        compared and the highest value for each element in the array will be used. This is how we 'merge'
                        the two configurations. Because the extents of fr and ms are not the same, we do have to reshape
                        the arrays a bit to allow for the comparison
                    """
                    with read_lock:
                        catchment_window = catchment_dataset.read(window=window)  # Read the dataset for the specified window  # noqa
    
                        unique_window_catchments = np.unique(catchment_window).tolist()  # Get a list of unique hydroids within the window  # noqa
                        window_valid_catchments = [catchment for catchment in unique_window_catchments if catchment in valid_catchments]  # Check to see if any hydroids with stages >0 are inside this window  # noqa
                        # Only process if there are hydroids with stage >0 in this window
                        if not window_valid_catchments:
                            return 
    
                        hand_window = hand_dataset.read(window=window)
                        
                    # Create an empty numpy array with the nodata value that will be overwritten
                    inundation_window = np.full(catchment_window.shape, hand_nodata, hand_dtype)
    
                    # If catchment window values exist, then find the max between the stage mapper and the window
                    mapping_ar_max = max(hydro_id_max, catchment_window.max())
    
                    # Create a stage mapper that will convert hydroids to their corresponding stage. -9999 is null or
                    # no value. we cant use 0 because it will mess up the mapping and use the 0 index
                    mapping_ar = np.full(mapping_ar_max+1, -9999, dtype="float32")
                    mapping_ar[k] = v
    
                    catchment_window[np.where(catchment_window == catchment_nodata)] = 0  # Convert catchment values to 0 where the catchment = catchment_nodata  # noqa
                    catchment_window[np.where(hand_window == hand_nodata)] = 0  # Convert catchment values to 0 where the HAND = HAND_nodata. THis will ensure we are only processing where we have HAND values!  # noqa
    
                    reclass_window = mapping_ar[catchment_window]  # Convert the catchment to stage
    
                    condition1 = reclass_window > hand_window  # Select where stage is gte to HAND
                    condition2 = reclass_window != -9999  # Select where stage is valid
                    conditions = (condition1) & (condition2)
    
                    # Use where statements to select the inundated areas in the window
                    if inundation_mode == 'mask':
                        inundation_window = np.where(conditions, catchment_window, 0).astype('int32')
                    else:
                        inundation_window = np.where(conditions, reclass_window-hand_window, 0).astype('float32')  # noqa
    
                    # Checking to see if there is any inundated areas in the window
                    if not inundation_window[np.where(inundation_window != 0)].any():
                        return 
    
                    # Write the final windowed inundation to the destination raster for the specified window
                    with write_lock:
                        dst.write(inundation_window, window=window)
    
                    if np.max(inundation_window) != 0:
                        return {"max_value": np.max(inundation_window), "col_off": window.col_off, "row_off": window.row_off, "height": window.height, "width": window.width}
    
                # Use threading to parallelize the processing of the inundation windows
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                    result_futures = list(map(lambda window: executor.submit(process, window), windows))
                    for future in concurrent.futures.as_completed(result_futures):
                        try:
                            if future.result() is not None:
                                results = future.result()
                                
                                if min_col is None:
                                    min_col = results['col_off']
                                else:
                                    min_col = min(min_col, results['col_off'])
                                    
                                if max_col is None:
                                    max_col = results['col_off']
                                else:
                                    max_col = max(max_col, results['col_off'])
                                    
                                if min_row is None:
                                    min_row = results['row_off']
                                else:
                                    min_row = min(min_row, results['row_off'])
                                    
                                if max_row is None:
                                    max_row = results['row_off']
                                else:
                                    max_row = max(max_row, results['row_off'])
                                    
                                if max_height is None:
                                    max_height = results['height']
                                else:
                                    max_height = max(max_height, results['height'])
                                    
                                if max_width is None:
                                    max_width = results['width']
                                else:
                                    max_width = max(max_width, results['width'])
                            
                        except Exception as e:
                            es_logger.warning(e)
                            
        except Exception as e:
            raise e
        finally:
            if hand_dataset is not None:
                hand_dataset.close()
    
            if catchment_dataset is not None:
                catchment_dataset.close()
        
        try:
            print("Clipping raster to remove outer nodata")
            with rasterio.open(raw_inundation_raster) as src:
                #window = rasterio.windows.get_data_window(src.read(1, masked=True))
                from rasterio.windows import Window
    
                window = Window(min_col, min_row, max_col-min_col+max_width, max_row-min_row+max_height)
                kwargs = src.meta.copy()
                kwargs.update({
                    'height': window.height,
                    'width': window.width,
                    'transform': rasterio.windows.transform(window, src.transform)
                })
                
                with rasterio.open(final_inundation_raster, 'w', **kwargs) as dst:
                    dst.write(src.read(window=window))
            os.remove(raw_inundation_raster)
            
            from rasterio.features import shapes
            mask = None
            with rasterio.Env():
                with rasterio.open(final_inundation_raster) as src:
                    image = src.read(1) # first band
                    results = (
                    {'hydro_id': int(v), 'geom': s, "fim_configuration": config_pass}
                    for i, (s, v) 
                    in enumerate(
                        shapes(image, mask=mask, transform=src.transform)))
            
            os.remove(final_inundation_raster)
            geoms = list(results)
            df_geoms = pd.DataFrame(geoms)
            df_geoms = df_geoms.set_index("hydro_id")
            df_geoms = df_geoms[df_geoms.index != 0]
            
            df_geoms['geom'] = df_geoms['geom'].apply(lambda x: f"(({', '.join([' '.join(str(coord) for coord in geom_cord) for geom_cord in x['coordinates'][0]])}))")
            
            for hydroid, subset in df_geoms.groupby("hydro_id"):
                multi_geom = f"MULTIPOLYGON ({', '.join(subset.geom.values)})"
                df_geoms.loc[hydroid, "geom"] = multi_geom
                
            df_geoms = df_geoms.join(stage_lookup).dropna()
            
            df_geoms = df_geoms.drop_duplicates()
            df_geoms['fim_version'] = fim_prefix.split("fim_")[-1].split(f"_{config_pass}")[0]
            df_geoms['reference_time'] = reference_time
            df_geoms['huc8'] = huc
        
            print(f"Adding data to {db_fim_table}")
            df_geoms.to_sql(con=db_engine, schema=db_schema, name=db_table, if_exists='append')
        except Exception as e:
            print("rasterio window piece failed.")
            raise e
    return 


def get_reach_stage_lookup(data_csv_key, config, huc):
    """
        Main function for converting streamflows to stages. Downloads the hydrotable and json file with the streamflow
        data. The streamflow data is then compared to the rating curve to determine interpolated stages.

        Args:
            data_csv_key(str): key (path) to the S3 json file that contains the streamflow data for the huc
            config(str): ms (main stem) or fr (full resolution) configuration
            huc(str): HUC that is being processed
            forecast_file(str): key (path) to the S3 max flows/nwm file used for overall service

        Returns:
            stage_lookup(list): list of list showing hydroids with interpolated stages. -9999 is no stage. [[100, 1],
                                [101, -9999], [102, 3], ...]
    """
    print("-->Getting rating curve data")
    s3 = boto3.client('s3')

    # These are local files that will be created from downloading S3 data
    local_hydrotable = f"/tmp/{config}_hydroTable.csv"
    local_data = "/tmp/data.csv"

    # Get the appropriate bucket and key prefix for the FIM datasets
    if config == 'fr':
        config_bucket = FR_FIM_BUCKET
        config_prefix = FR_FIM_PREFIX
    elif config == 'ms':
        config_bucket = MS_FIM_BUCKET
        config_prefix = MS_FIM_PREFIX
    else:
        raise Exception(f"{config} is invalid. Config must be fr or ms")

    # Download the rating curve from S3 and put it into a pandas dataframe
    hydro_table_key = f'{config_prefix}/{huc}/hydroTable.csv'

    s3.download_file(config_bucket, hydro_table_key, local_hydrotable)
    df_hydro = pd.read_csv(local_hydrotable)
    os.remove(local_hydrotable)

    # Download the csv data from S3
    s3.download_file(PROCESSED_OUTPUT_BUCKET, data_csv_key, local_data)
    df_forecast = pd.read_csv(local_data)
    os.remove(local_data)

    # Just grab the streamflow field for rating curve comparison
    df_hydro = df_hydro.merge(df_forecast, on="feature_id")

    if df_hydro.empty:
        print(f"No Valid Reaches to Process")
        return pd.DataFrame()
        
    # Ignore reaches that are lakes
    df_hydro = df_hydro[df_hydro['LakeID'] == -999]

    df_hydro = df_hydro.rename(columns={"HydroID":"hydro_id"})
    df_hydro = df_hydro.set_index('hydro_id')

    # Grab the largest stage value for each processed reach for later db
    # dump and metadata configuration
    df_hydro_max = df_hydro.sort_values('stage').groupby('hydro_id').tail(1)
    df_hydro_max = df_hydro_max[['stage', 'discharge_cms']].rename(columns={'stage': 'max_rc_stage_m', 'discharge_cms': 'max_rc_discharge_cms'})

    # Shift the stage/flow values for next rating curve step so each row has a
    # range of flows/stages for the specific rating curve step
    df_hydro['next_discharge_cms'] = df_hydro.groupby('hydro_id')['discharge_cms'].shift(-1)
    df_hydro['next_stage'] = df_hydro.groupby('hydro_id')['stage'].shift(-1)

    # Select reaches where the flow is between the discharge column and the next discharge column
    condition1 = (df_hydro['streamflow_cms'] >= df_hydro['discharge_cms'])
    condition2 = (df_hydro['streamflow_cms'] <= df_hydro['next_discharge_cms'])
    condition3 = df_hydro['next_discharge_cms'].isna()

    df_hydro = df_hydro[condition1 & (condition2 | condition3)]

    # Remove any duplicated hydroids. This happens with some weird rating curve behavior
    # where larger stages and lower flow thresholds. Grab the lowest passed stage
    df_hydro = df_hydro[~df_hydro.index.duplicated()]

    # Calculate the interpolated (linearly) stages using the stage rate of change and the discharge change
    stage_rate_of_change = ((df_hydro['next_stage'] - df_hydro['stage']) / (df_hydro['next_discharge_cms'] - df_hydro['discharge_cms']))  # noqa
    discharge_change = df_hydro['streamflow_cms'] - df_hydro['discharge_cms']
    df_hydro['interpolated_stage_m'] = df_hydro['stage'] + discharge_change * stage_rate_of_change

    # Make the interpolated stage equal to the max stage for reaches whose streamflow exceeds the max streamflow in the rating curve
    df_hydro.loc[df_hydro['interpolated_stage_m'].isna(), 'interpolated_stage_m'] = df_hydro['stage']
    df_hydro['interpolated_stage_m'] = df_hydro['interpolated_stage_m'].round(2)
    df_hydro = df_hydro[(df_hydro['interpolated_stage_m'] != 0)]
    df_hydro = df_hydro[['feature_id', 'streamflow_cms', 'interpolated_stage_m']]
    
    df_hydro = df_hydro.join(df_hydro_max)

    print(f"Expecting to process {len(df_hydro)} rows")
    
    return df_hydro
