import time
import json
import boto3
import botocore
import os
import datetime
import re
import collections
from concurrent.futures import ThreadPoolExecutor
from viz_lambda_shared_funcs import (get_most_recent_s3_file, check_s3_fileset, get_configuration,
                                     parse_s3_sns_message, get_service_metadata, get_db_connection)
from es_logging import get_elasticsearch_logger
es_logger = get_elasticsearch_logger()

worker_lambda = os.getenv('WORKER_LAMBDA_NAME')
max_workers = int(os.getenv('MAX_WORKERS'))  # The total number of child worker lambdas that may be spun-up.
mrf_timestep = int(os.getenv('MRF_TIMESTEP'))  # The hour interval to use for MRF import (using 3 to match on-prem)

lambda_config = botocore.client.Config(max_pool_connections=max_workers, connect_timeout=600, read_timeout=600)
lambda_client = boto3.client('lambda', config=lambda_config)


def lambda_handler(event, context):
    start_time_total = time.time()
    step_time = time.time()
    start_time_formatted = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    configuration = None  # default
    reference_time = None  # default
    insert_mode = 'replace'  # default

    # Get the data key(path) and bucket of the S3 notification SNS topic that triggered this function
    # it maybe makes sense to build all this logic into the parse_message function once it's better built out?
    try:
        run_type = "S3 SNS"
        data_key, data_bucket = parse_s3_sns_message(event)
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 1, "process_db_step": "1 - Starting",
            "run_type": run_type
        }
        es_logger.info(json.dumps([dump_dict]))
        step_time = time.time()
    except Exception:  # Or try to get the configuration and s3 bucket to use from a manual invocation or test event.
        try:
            run_type = "Manual"
            configuration = event.get('configuration')
            data_bucket = event.get('bucket')
            data_key = event.get('key') if event.get('key') else get_most_recent_s3_file(data_bucket, configuration)
            reference_time = datetime.datetime.strptime(event.get('reference_time'), '%Y-%m-%d %H:%M:%S') if event.get('reference_time') else None  # noqa: E501
            insert_mode = event.get('insert_mode') if event.get('insert_mode') else 'replace'
            step_time = time.time()
        except Exception as e:
            print(f"Invalid Trigger: No valid sns message or manual event data found. Event: {event}. Error: {e}")
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 999,
                "process_db_step": "Failure (can't parse event or manual invocation.)", "Error": str(e)
            }
            es_logger.info(json.dumps([dump_dict]))
            raise e

    print(f"Starting up ingest with {run_type} run type, from data key: {data_key}.")

    # Get configuration and input file metadata for the triggering dataset.
    print("Getting configuration, reference time, and input files from data key.")
    try:
        metadata = get_configuration(data_key, mrf_timestep=mrf_timestep)
    except Exception as e:
        print("Configuration Error: Can't get valid metadata from get_configuration function.")
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 999,
            "process_db_step": "Failure (can't get metadata from get_configuration.)", "error": str(e)
        }
        es_logger.info(json.dumps([dump_dict]))
        raise e

    # Define ingest paramaters based on S3 metadata.
    configuration = metadata.get('configuration') if not configuration else configuration
    reference_time = metadata.get('reference_time')
    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 1, "process_db_step": "1 - Starting",
        "configuration_db": configuration, "reference_time": reference_time
    }
    es_logger.info(json.dumps([dump_dict]))
    
    # If replace and route or analysis assim, just setup input_files manually TODO- Clean this up.
    if configuration == 'replace_route' or configuration == 'analysis_assim_14day':
        input_files = [data_key]
        if configuration == 'analysis_assim_14day':
            input_files.append(data_key.replace('ana_14day', 'ana_7day'))
    else:
        input_files = metadata.get('input_files')
        print(input_files)

    # Get service metadata from the admin.services table in the postgresql database.
    try:
        print("Fetching service metadata and run status from RDS.")
        services_data = get_service_metadata()
        services = [service for service in services_data if service.get('configuration') == configuration and service.get('run') is True]  # noqa: E501
    except Exception as e:
        print(f"Invalid or innactive configuration. Error: {e}")
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 999,
            "process_db_step": "Failure (invalid or innactive configuration)", "configuration_db": configuration,
            "reference_time": reference_time, "error": str(e)
        }
        es_logger.info(json.dumps([dump_dict]))
        raise e

    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 2, "process_db_step": "2 - Checking S3 Files",
        "configuration_db": configuration, "reference_time": reference_time, "last_step": "1 - Starting",
        "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
    }
    es_logger.info(json.dumps([dump_dict]))
    step_time = time.time()

    # Check to ensure the full fileset is available on S3.
    ready_files = check_s3_fileset(data_bucket, input_files)
    print("All files reported ready. Starting Import.")

    # Call the appropriate db import function to execute the import of files into postgresql.
    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 3, "process_db_step": "3 - Importing Data to RDS",
        "configuration_db": configuration, "reference_time": reference_time, "last_step": "2 - Checking S3 Files",
        "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
    }
    es_logger.info(json.dumps([dump_dict]))
    step_time = time.time()

    # Add ingest table and primary key info to the ready files list
    ingest_files = []
    for s3_key in ready_files:
        for service in services:
            if service['filename']:
                if re.match(service['filename'].replace("*d", r"\d"), os.path.basename(s3_key)):
                    ingest_table = service['ingest_table']
                    ingest_keys = service['ingest_keys']
            else:
                ingest_table = service['ingest_table']
                ingest_keys = service['ingest_keys']
        ingest_files.append({'s3_key': s3_key, 'ingest_table': ingest_table, 'ingest_keys': ingest_keys})

    try:
        db_import_s3_files(configuration, reference_time, data_bucket, ingest_files, insert_mode=insert_mode)
    except Exception as e:
        print(f"Import function failed with error: {e}")
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 999, "process_db_step": "Failure (import failed)",
            "configuration_db": configuration, "reference_time": reference_time, "error": str(e)
        }
        es_logger.info(json.dumps([dump_dict]))
        raise e

    # Report completion time.
    completion_time = str(round(((time.time() - start_time_total) / 60.0), 1))
    print(f"Full import job completed in {completion_time} minutes.")
    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 4, "process_db_step": "4 - Import Complete",
        "configuration_db": configuration, "reference_time": reference_time, "last_step": "3 - Importing Data to RDS",
        "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
    }
    es_logger.info(json.dumps([dump_dict]))

    # Pass the reference time, start and finish time of this function to the destination post-process function.
    dump_dict = {
        "configuration": configuration, "reference_time": reference_time,
        "ingest_start_formatted": start_time_formatted,
        "ingest_start_time": start_time_total, "ingest_finish_time": time.time()
    }
    return json.dumps([dump_dict])


def db_import_s3_files(configuration, reference_time, bucket, input_files, insert_mode="replace"):
    """
    This function iterates through a list of AWS S3-based NWM NetCDF files, splits them into chunks, and loads them
    into a PostgreSQL table using multiprocessing. Import status, metrics, and performance is also updated in the
    ingest status table in the database.

    Args:
        reference_time (str): The reference time of the dataset.
        bucket (str): The S3 bucket that hosts the files.
        input_files (dict): The dictionary of netcdf or CSV files to ingest, including their
            ingest_table and ingest_key.
        insert_mode (str): Notes whether the records should replace the existing table or be appended.
            Valid options are "replace" and "append".
    """
    start_time = time.time()

    # Split input files into groups based on ingest_table, so we can do one at a time.
    ingest_dicts = collections.defaultdict(list)
    for ingest_dict in input_files:
        ingest_dicts[ingest_dict['ingest_table']].append(ingest_dict)
    ingest_sets = list(ingest_dicts.values())

    # Loop through each ingest set to do a seperate insert per ingest table ####
    for ingest_set in ingest_sets:
        target_table = ingest_set[0]['ingest_table']
        index_columns = ingest_set[0]['ingest_keys']
        index_name = f"idx_{target_table.split('.')[-1:].pop()}_feature_id_streamflow"

        connection = get_db_connection("viz")
        cur = connection.cursor()

        try:
            # Add a row to the ingest status table indicating that an import has started.
            cur.execute(f"INSERT INTO admin.ingest_status (target, reference_time, status, update_time)"
                        f"VALUES ('{target_table}', '{reference_time}', 'Import Started', "
                        f"'{datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')}')")

            # Drop the existing index on the target table, and truncate all records.
            print("Dropping target table index (if exists).")
            cur.execute(f"DROP INDEX IF EXISTS ingest.{index_name};")

            if insert_mode == "replace":
                print("Truncating target table.")
                cur.execute(f"TRUNCATE TABLE {target_table};")
            connection.commit()

            print('Starting import.')

            # Loop through each input file and spin up a seperate worker lambda to ingest tht file into the database.
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futs = []
                # Only take the first [max_workers] elements in list.
                # If there are more... we'll add them in a subsequent load.
                for file in ingest_set:
                    dump_dict = {
                        "target_table": target_table,
                        "file": file['s3_key'],
                        "bucket": bucket,
                        "reference_time": reference_time,
                        "include_ref_time": False,
                        "keep_zero_streamflow": False
                    }
                    payload = json.dumps(dump_dict)
                    try:
                        futs.append(
                        executor.submit(
                            lambda_client.invoke,
                            FunctionName=worker_lambda,
                            InvocationType='RequestResponse',
                            Payload=payload
                            )
                        )
                        print(f"Invoking ingest worker for: {file['s3_key']} ({round((len(futs)/len(ingest_set))*100, 0)}% of ingest set.)")
                    except Exception as e:
                        print(f"Could not invoke worker for file: {file}.")
                        raise e

                # Collect results from our workers
                results = []
                rows_imported = []
                for fut in futs:
                    try:
                        result = json.loads(json.loads(fut.result()['Payload'].read().decode("utf-8")))
                        results.append(result)
                        rows_imported.append(int(result.get('rows_imported'))) # Add the rows that have been imported
                        print(f"Successfuly received response from worker: {ingest_set[futs.index(fut)]['s3_key']}.")
                    except Exception as e:
                        print(f"Could not retrieve result from worker: {ingest_set[futs.index(fut)]['s3_key']}.")
                        # Retry the problematic child worker synchronously
                        try:
                            dump_dict = {
                                "target_table": target_table,
                                "file": ingest_set[futs.index(fut)]['s3_key'],
                                "bucket": bucket,
                                "reference_time": reference_time,
                                "include_ref_time": False,
                                "keep_zero_streamflow": False
                                }
                            payload = json.dumps(dump_dict)
                            print(f"Retrying synchronous invocation of {ingest_set[futs.index(fut)]['s3_key']}.")
                            response = lambda_client.invoke(FunctionName=worker_lambda, InvocationType='RequestResponse', Payload=payload)
                            result = json.loads(json.loads(response['Payload'].read().decode("utf-8")))
                            results.append(result)
                            rows_imported.append(int(result.get('rows_imported'))) # Add the rows that have been imported
                            print(f"Success.")
                        except Exception as e:
                            print("Failed to retry invocation.")
                            raise e
            
            # Print finished and missing files for debuging.
            finished_files = [result['file'] for result in results]
            print(f"Finished Files: {finished_files}")
            failed_files = [file['s3_key'] for file in ingest_set if file['s3_key'] not in finished_files]
            if len(failed_files) > 0:
                print(f"Failed Files: {failed_files}")
            
            # Re-create the index that was deleted before import, but only for normal runs is False:
            print("Re-creating table index.")
            cur.execute(f'CREATE INDEX {index_name} ON {target_table} {index_columns};')
            connection.commit()
            
            # Confirm that the files imported matches the number of forecast timesteps - currently only enabled for srf and mrf imports.
            if "short_range" in configuration or "medium_range_mem1" in configuration:
                cur.execute(f"SELECT count(distinct forecast_hour) from {target_table};")
                db_hours = cur.fetchone()[0]
                file_hours = len(ingest_set)
                if "short_range_hawaii" in configuration:
                    file_hours = (file_hours / 4) + 1
                if db_hours != file_hours:
                    raise Exception(f"Forecast hours in new db table don't match ingest_set length. Aborting. db_hours: {db_hours}, file_hours: {file_hours}")

            # Update the ingest status table with the current import information.
            cur.execute(f"UPDATE admin.ingest_status "
                        "SET status = 'Import Complete',"
                        f"update_time = '{datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')}',"  # noqa: E501
                        f"files_processed = {len(ingest_set)},"
                        f"records_imported = {sum(rows_imported)},"
                        f"insert_time_minutes = {round(((time.time() - start_time) / 60.0), 2)} "
                        f"WHERE target = '{target_table}' AND reference_time = '{reference_time}';")
            print(f"Ingest set complete. Imported {len(ingest_set)} files to {target_table}.")

        except Exception as e:
            raise e

        finally:
            # Commit and close the database cursor and connection
            connection.commit()
            cur.close()
            connection.close()
