################################################################################
################################ Viz DB Ingest ################################# 
################################################################################
"""
This function downloads a file from S3 and ingets it into the vizprocessing RDS
database.

Args:
    event (dictionary): The event passed from the state machine.
    context (object): Automatic metadata regarding the invocation.
    
Returns:
    dictionary: The details of the file that was ingested, to be returned to the state machine.
"""
################################################################################
import os
import boto3
import json
import numpy as np
import xarray as xr
import pandas as pd
from io import StringIO
# from google.cloud import storage
from viz_classes import database, s3_file

s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')

class MissingS3FileException(Exception):
    """ my custom exception class """
    
def lambda_handler(event, context):

    target_table = event['target_table']
    file = event['file']
    bucket = event['bucket']
    reference_time = event['reference_time']
    keep_flows_at_or_above = event['keep_flows_at_or_above']
    
    print(f"Attempting to ingest {file} into {target_table}")
    if 'gs://national-water-model' not in file:
        file_ready = s3_file(bucket, file).check_existence()
    else:
        file_ready = True
    if file_ready:
        print("File exists")
    else:
        raise MissingS3FileException(f"{file} does not exist on S3.")
    
    viz_db = database(db_type="viz")
    with viz_db.get_db_connection() as connection:
        cursor = connection.cursor()

        try:
            download_path = f'/tmp/{os.path.basename(file)}'
            print(f"--> Downloading {file} to {download_path}")
            if 'gs://national-water-model' in file:
                # download_blob(file, download_path)
                raise Exception("Fetching NWM Data from Google Cloud Not Currently Supported")
            else:
                s3.download_file(bucket, file, download_path)
    
            if file[-12:] == 'max_flows.nc':
                # Load the NetCDF file into a dataframe
                ds = xr.open_dataset(download_path)
                df = ds.to_dataframe().reset_index()
                ds.close()
                df_toLoad = df.round({'streamflow': 2}).copy()
    
            elif file[-3:] == '.nc':
                # Load the NetCDF file into a dataframe
                drop_vars = ['crs', 'nudge', 'velocity', 'qSfcLatRunoff', 'qBucket', 'qBtmVertRunoff']
                ds = xr.open_dataset(download_path, drop_variables=drop_vars)
                ds['time_step'] = (((ds['time'] - ds['reference_time'])) / np.timedelta64(1, 'h')).astype(int)
                df = ds.to_dataframe().reset_index()
                ds.close()
    
                # Only include reference time in the insert if specified
                df_toLoad = df[['feature_id', 'time_step', 'streamflow']]
                cursor.execute(f"CREATE TABLE IF NOT EXISTS {target_table} (feature_id integer, forecast_hour integer, "
                                "streamflow double precision)")
    
                # Filter out any streamflow data below the specificed threshold
                df_toLoad = df_toLoad.loc[df_toLoad['streamflow'] >= keep_flows_at_or_above].round({'streamflow': 2}).copy()  # noqa
    
            elif file[-4:] == '.csv':
                df = pd.read_csv(download_path)
                for column in df:  # Replace any 'None' strings with nulls
                    df[column].replace('None', np.nan, inplace=True)
                df_toLoad = df.copy()
            else:
                print("File format not supported.")
                exit()
    
            print(f"--> Preparing and Importing {file}")
            f = StringIO()  # Use StringIO to store the temporary text file in memory (faster than on disk)
            df_toLoad.to_csv(f, sep='\t', index=False, header=False)
            f.seek(0)
            #cursor.copy_from(f, target_table, sep='\t', null='')  # This is the command that actual copies the data to db
            cursor.copy_expert(f"COPY {target_table} FROM STDIN WITH DELIMITER E'\t' null as ''", f)
            connection.commit()
    
            print(f"--> Import of {len(df_toLoad)} rows Complete. Removing {download_path} and closing db connection.")
            os.remove(download_path)
    
        except Exception as e:
            print(f"Error: {e}")
            raise e
    
    # Return some info on the import
    dump_dict = {
                        "file": file,
                        "target_table": target_table,
                        "reference_time": reference_time,
                        "rows_imported": len(df_toLoad)
                    }
    return json.dumps(dump_dict)

# def decode_gcs_url(url):
#     p = urlparse(url)
#     path = p.path[1:].split('/', 1)
#     bucket, file_path = path[0], path[1] 
#     return bucket, file_path

# def download_blob(url, download_path):
#     if url:
#         storage_client = storage.Client()
#         bucket, file_path = decode_gcs_url(url)
#         bucket = storage_client.bucket(bucket)
#         blob = bucket.blob(file_path)
#         blob.download_to_filename(download_path)