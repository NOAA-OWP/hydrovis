import os
import boto3
import json
import numpy as np
import xarray as xr
import pandas as pd
from io import StringIO
from viz_lambda_shared_funcs import get_db_connection

s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')


def lambda_handler(event, context):

    target_table = event['target_table']
    file = event['file']
    bucket = event['bucket']
    reference_time = event['reference_time']
    include_ref_time = event['include_ref_time']
    keep_zero_streamflow = event['keep_zero_streamflow']

    connection = get_db_connection("viz")
    cursor = connection.cursor()

    try:
        download_path = f'/tmp/{os.path.basename(file)}'
        print(f"--> Downloading {file} to {download_path}")
        s3.download_file(bucket, file, download_path)

        if file[-12:] == 'max_flows.nc':
            # Load the NetCDF file into a dataframe
            ds = xr.open_dataset(download_path)
            df = ds.to_dataframe().reset_index()
            ds.close()
            df_toLoad = df.round({'streamflow': 2}).copy()

        elif file[-3:] == '.nc':
            # Load the NetCDF file into a dataframe
            drop_vars = ['crs', 'nudge', 'velocity', 'qSfcLatRunoff', 'qBucket', 'qBtmVertRunoff']
            ds = xr.open_dataset(download_path, drop_variables=drop_vars)
            ds['time_step'] = (((ds['time'] - ds['reference_time'])) / np.timedelta64(1, 'h')).astype(int)
            df = ds.to_dataframe().reset_index()
            ds.close()

            # Only include reference time in the insert if specified
            if include_ref_time is True:
                df_toLoad = df[['feature_id', 'reference_time', 'time_step', 'streamflow']]
                cursor.execute(f"CREATE TABLE IF NOT EXISTS {target_table} (feature_id integer, "
                               "reference_time timestamp without time zone, forecast_hour integer, "
                               "streamflow double precision)")
            else:
                df_toLoad = df[['feature_id', 'time_step', 'streamflow']]
                cursor.execute(f"CREATE TABLE IF NOT EXISTS {target_table} (feature_id integer, forecast_hour integer, "
                               "streamflow double precision)")

            # Clear out zero streamflow records or not based on arg
            if keep_zero_streamflow is False:
                df_toLoad = df_toLoad.loc[df_toLoad['streamflow'] > 0].round({'streamflow': 2}).copy()  # noqa
            else:
                df_toLoad = df_toLoad.round({'streamflow': 2}).copy()

        elif file[-4:] == '.csv':
            df = pd.read_csv(download_path)
            for column in df:  # Replace any 'None' strings with nulls
                df[column].replace('None', np.nan, inplace=True)
            df_toLoad = df.copy()
        else:
            print("File format not supported.")
            exit()

        print(f"--> Preparing and Importing {file}")
        f = StringIO()  # Use StringIO to store the temporary text file in memory (faster than on disk)
        df_toLoad.to_csv(f, sep='\t', index=False, header=False)
        f.seek(0)
        cursor.copy_from(f, target_table, sep='\t', null='')  # This is the command that actual copies the data to db
        connection.commit()

        print(f"--> Import of {len(df_toLoad)} rows Complete. Removing {download_path} and closing db connection.")
        os.remove(download_path)

    except Exception as e:
        print(f"Error: {e}")
        raise e

    finally:
        cursor.close()
        connection.close()
    
    # Return some info on the import
    dump_dict = {
                        "file": file,
                        "target_table": target_table,
                        "reference_time": reference_time,
                        "rows_imported": len(df_toLoad)
                    }
    return json.dumps(dump_dict)
