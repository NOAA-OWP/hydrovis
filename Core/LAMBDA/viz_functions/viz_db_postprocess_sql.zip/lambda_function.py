from viz_classes import database

def lambda_handler(event, context):
    print(event)
    step = event['step']
    folder = event['folder']
    reference_time = event['args']['reference_time']
    sql_replace = {'1900-01-01 00:00:00': reference_time} #setup a replace dictionary, starting with the reference time of the current pipeline.
    
    if folder == 'admin':
         run_admin_tasks(event, folder, step, sql_replace)
    else:
        sql_file = event['args']['map_item']
    
        extra_renames = False
        # Search for sql_args if present
        for key in event['args']:
            if 'sql_args' in event['args'][key]:
                extra_renames = True
                sql_args = event['args'][key]['sql_args']
        ### Update replace dictionary based on sql_args, if present
        if extra_renames:
            for sql_arg_group in sql_args: #ToDo - Need to update this to a proper key value pair for each replace entry in the initialize function to avoid all these silly loops
                for sql_arg in sql_arg_group:
                    if sql_arg == "source_table":
                        sql_replace.update({sql_arg_group['source_table']: sql_arg_group['pipeline_source']})
                    if sql_arg == "target_table":
                        sql_replace.update({sql_arg_group['target_table']: sql_arg_group['pipeline_target']})
    
        sql_path = f"{folder}/{sql_file}.sql"
        run_sql_file(sql_path, sql_replace)
    return True

# Special function to handle admin-only sql tasks
def run_admin_tasks(event, folder, step, sql_replace):
    target_table = event['args']['target_table']
    original_table = event['args']['original_table']
    index_columns = event['args']['index_columns']
    index_name = event['args']['index_name']
    schema = target_table.split('.')[0]
    
    sql_replace.update({"{target_table}": target_table})
    sql_replace.update({"{target_schema}": schema})
    sql_replace.update({"{index_name}": index_name})
    sql_replace.update({"{index_columns}": index_columns})
    
    if step == 'ingest_prep':
        # if target table is not the original table, run the create command to create the table
        if target_table != original_table:
            sql_replace.update({"{original_table}": original_table})
            run_sql_file('admin/create_table_from_original.sql', sql_replace)
        run_sql_file('admin/ingest_prep.sql', sql_replace)

    if step == 'ingest_finish':
        sql_replace.update({"{files_imported}": 'NULL'}) #TODO Figure out how to get this from the last map of the state machine to here
        sql_replace.update({"{rows_imported}": 'NULL'}) #TODO Figure out how to get this from the last map of the state machine to here
        run_sql_file('admin/ingest_finish.sql', sql_replace)

# Run a sql file, and replace any items basd on the sql_replace dictionary.
def run_sql_file(sql_path, sql_replace):  
    # Find the sql file, and replace any items in the dictionary (at least has reference_time)
    sql = open(sql_path, 'r').read().lower()
    for word, replacement in sql_replace.items():
        sql = sql.replace(word.lower(), replacement.lower()).replace('utc', 'UTC')
    viz_db = database(db_type="viz")
    with viz_db.get_db_connection() as connection:
        cur = connection.cursor()
        cur.execute(sql)
        connection.commit()
    print(f"Finished running {sql_path}.")