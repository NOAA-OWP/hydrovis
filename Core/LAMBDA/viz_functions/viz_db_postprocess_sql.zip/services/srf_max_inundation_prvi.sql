DROP TABLE IF EXISTS publish.srf_max_inundation_prvi;

SELECT  
	inun.*,
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time, 
	derived.channels_prvi.strm_order, 
    derived.channels_prvi.name
INTO publish.srf_max_inundation_prvi
FROM ingest.srf_max_inundation_prvi as inun 
left join derived.channels_prvi ON derived.channels_prvi.feature_id = inun.feature_id;