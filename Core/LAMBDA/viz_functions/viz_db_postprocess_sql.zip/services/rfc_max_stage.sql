DROP TABLE IF EXISTS publish.rfc_max_stage;

WITH
	-------- Max Stage Sub Query -------
	MAX_STAGE AS
		(SELECT 
			af.nws_lid, 
			af.stage, 
			CASE WHEN af.stage >= c.record_threshold THEN 'record' ELSE af.status END AS status,
		 	MIN(af.timestep) AS timestep,
		 	CASE			
				WHEN af.status = 'action' THEN 1::integer
				WHEN af.status = 'minor' THEN 2::integer
				WHEN af.status = 'moderate' THEN 3::integer
				WHEN af.status = 'major' THEN 4::integer
				WHEN af.stage >= c.record_threshold THEN 5::integer --Have to calculate record seperately since we learned that scale is outside action - major & not included in WRDS API statuses.
				ELSE 0::integer
			END AS status_value
		FROM ingest.ahps_forecasts AS af
		INNER JOIN (
			SELECT
				nws_lid,
				MAX(stage) AS max_stage
			FROM ingest.ahps_forecasts
			GROUP BY nws_lid
		) AS b ON af.nws_lid = b.nws_lid AND af.stage = b.max_stage
		 LEFT OUTER JOIN ingest.ahps_metadata AS c on af.nws_lid = c.nws_lid
		 GROUP BY af.nws_lid, af.stage, af.status, c.record_threshold),
	-------- Min Stage Sub Query -------
	MIN_STAGE AS
		(SELECT 
			af.nws_lid,  
			af.stage, 
			CASE WHEN af.stage >= c.record_threshold THEN 'record' ELSE af.status END AS status,
		 	MIN(af.timestep) AS timestep,
		 	CASE			
				WHEN af.status = 'action' THEN 1::integer
				WHEN af.status = 'minor' THEN 2::integer
				WHEN af.status = 'moderate' THEN 3::integer
				WHEN af.status = 'major' THEN 4::integer
				WHEN af.stage >= c.record_threshold THEN 5::integer --Have to calculate record seperately since we learned that scale is outside action - major & not included in WRDS API statuses.
				ELSE 0::integer
			END AS status_value
		FROM ingest.ahps_forecasts AS af
		INNER JOIN (
			SELECT
				nws_lid,
				MIN(stage) AS min_stage
			FROM ingest.ahps_forecasts
			GROUP BY nws_lid
		) AS b ON af.nws_lid = b.nws_lid AND af.stage = b.min_stage
		LEFT OUTER JOIN ingest.ahps_metadata AS c on af.nws_lid = c.nws_lid
		GROUP BY af.nws_lid, af.stage, af.status, c.record_threshold),
	-------- Initial Stage Sub Query -------
	INITIAL_STAGE AS
		(SELECT 
			af.nws_lid,
			af.stage,
			CASE WHEN af.stage >= c.record_threshold THEN 'record' ELSE af.status END AS status,
		 	af.timestep,
		 	CASE			
				WHEN af.status = 'action' THEN 1::integer
				WHEN af.status = 'minor' THEN 2::integer
				WHEN af.status = 'moderate' THEN 3::integer
				WHEN af.status = 'major' THEN 4::integer
				WHEN af.stage >= c.record_threshold THEN 5::integer --Have to calculate record seperately since we learned that scale is outside action - major & not included in WRDS API statuses.
				ELSE 0::integer
			END AS status_value
		FROM ingest.ahps_forecasts AS af
		INNER JOIN (
			SELECT
				nws_lid,
				MIN(timestep) AS min_timestep
			FROM ingest.ahps_forecasts
			GROUP BY nws_lid
		) AS b ON af.nws_lid = b.nws_lid AND af.timestep = b.min_timestep
		LEFT OUTER JOIN ingest.ahps_metadata AS c on af.nws_lid = c.nws_lid)

-------- Main Query (Put it all together) -------
SELECT 
	MAX_STAGE.nws_lid,
	INITIAL_STAGE.stage AS initial_stage,
	INITIAL_STAGE.status AS initial_status,
	to_char(INITIAL_STAGE.timestep::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS initial_stage_timestep,
	MIN_STAGE.stage AS min_stage,
	MIN_STAGE.status AS min_status,
	to_char(MIN_STAGE.timestep::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS min_stage_timestep,
	MAX_STAGE.stage AS max_stage,
	MAX_STAGE.status AS max_status,
	to_char(MAX_STAGE.timestep::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS max_stage_timestep,
	CASE
		WHEN INITIAL_STAGE.stage = 0 THEN 'increasing'::text
		WHEN ((MAX_STAGE.stage-INITIAL_STAGE.stage)/INITIAL_STAGE.stage) > .05 THEN 'increasing'::text									
		WHEN ((MIN_STAGE.stage-INITIAL_STAGE.stage)/INITIAL_STAGE.stage) < -.05 THEN 'decreasing'::text									
		WHEN MAX_STAGE.status_value > INITIAL_STAGE.status_value THEN 'increasing'::text								
		WHEN MAX_STAGE.status_value < INITIAL_STAGE.status_value THEN 'increasing'::text
		ELSE 'constant'::text
	END AS forecast_trend,
	metadata.producer, 
	metadata.issuer,
	to_char(metadata.issued_time::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS issued_time,
	to_char(metadata.generation_time::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS generation_time,
	metadata.usgs_sitecode, 
	metadata.nwm_feature_id, 
	metadata.nws_name, 
	metadata.usgs_name, 
	ST_SetSRID(ST_MakePoint(metadata.longitude, metadata.latitude),4326) as geom, 
	metadata.action_threshold, 
	metadata.minor_threshold, 
	metadata.moderate_threshold, 
	metadata.major_threshold, 
	metadata.record_threshold, 
	metadata.unit,
	CONCAT('https://water.weather.gov/resources/hydrographs/', LOWER(metadata.nws_lid), '_hg.png') AS hydrograph_link,
	CONCAT('https://water.weather.gov/ahps2/rfc/', metadata.nws_lid, '.shortrange.hefs.png') AS hefs_link,
	to_char(NOW()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS UPDATE_TIME
INTO publish.rfc_max_stage
FROM ingest.ahps_metadata as metadata
JOIN MAX_STAGE ON MAX_STAGE.nws_lid = metadata.nws_lid
JOIN MIN_STAGE ON MIN_STAGE.nws_lid = metadata.nws_lid
JOIN INITIAL_STAGE ON INITIAL_STAGE.nws_lid = metadata.nws_lid
WHERE metadata.issued_time > NOW() - INTERVAL '26 hours' AND metadata.nws_lid NOT IN (SELECT nws_lid FROM derived.ahps_restricted_sites);