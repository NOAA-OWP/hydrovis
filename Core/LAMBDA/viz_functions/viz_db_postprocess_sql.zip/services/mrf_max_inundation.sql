DROP TABLE IF EXISTS publish.mrf_max_inundation;

SELECT 
	inun.hydro_id,
    inun.hydro_id::TEXT AS hydro_id_str,
	round((inun.streamflow_cms * 35.315::double precision)::numeric, 2) as streamflow_cfs,
    round((inun.interpolated_stage_m * 3.28084::double precision)::numeric, 2) as interpolated_stage_ft, 
    inun.feature_id, 
	inun.feature_id::TEXT AS feature_id_str, 
    inun.fim_version, 
	to_char('1900-01-01 00:00:00'::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS reference_time, 
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time, 
	inun.fim_configuration, 
    round((inun.max_rc_stage_m * 3.28084::double precision)::numeric, 2) as max_rc_stage_ft, 
	round((inun.max_rc_discharge_cms * 35.315::double precision)::numeric, 2) as max_rc_discharge_cfs,
	ST_Transform(inun.geom, 3857) as geom, -- FIM data is in epsg:102039 by default, need to reproject.
	inun.huc8,
	derived.channels_conus.strm_order, 
    derived.channels_conus.name,
    'mrf_3day' AS config
INTO publish.mrf_max_inundation
FROM ingest.mrf_max_inundation_3day as inun 
left join derived.channels_conus ON derived.channels_conus.feature_id = inun.feature_id;

INSERT INTO publish.mrf_max_inundation
SELECT 
	inun.hydro_id,
    inun.hydro_id::TEXT AS hydro_id_str,
	round((inun.streamflow_cms * 35.315::double precision)::numeric, 2) as streamflow_cfs,
    round((inun.interpolated_stage_m * 3.28084::double precision)::numeric, 2) as interpolated_stage_ft, 
    inun.feature_id, 
	inun.feature_id::TEXT AS feature_id_str, 
    inun.fim_version, 
	to_char('1900-01-01 00:00:00'::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS reference_time, 
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time, 
	inun.fim_configuration, 
    round((inun.max_rc_stage_m * 3.28084::double precision)::numeric, 2) as max_rc_stage_ft, 
	round((inun.max_rc_discharge_cms * 35.315::double precision)::numeric, 2) as max_rc_discharge_cfs,
	ST_Transform(inun.geom, 3857) as geom, -- FIM data is in epsg:102039 by default, need to reproject.
	inun.huc8,
	derived.channels_conus.strm_order, 
    derived.channels_conus.name,
    'mrf_5day' AS config
FROM ingest.mrf_max_inundation_5day as inun 
left join derived.channels_conus ON derived.channels_conus.feature_id = inun.feature_id;

INSERT INTO publish.mrf_max_inundation
SELECT 
	inun.hydro_id,
    inun.hydro_id::TEXT AS hydro_id_str,
	round((inun.streamflow_cms * 35.315::double precision)::numeric, 2) as streamflow_cfs,
    round((inun.interpolated_stage_m * 3.28084::double precision)::numeric, 2) as interpolated_stage_ft, 
    inun.feature_id, 
	inun.feature_id::TEXT AS feature_id_str, 
    inun.fim_version, 
	to_char('1900-01-01 00:00:00'::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS reference_time, 
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time, 
	inun.fim_configuration, 
    round((inun.max_rc_stage_m * 3.28084::double precision)::numeric, 2) as max_rc_stage_ft, 
	round((inun.max_rc_discharge_cms * 35.315::double precision)::numeric, 2) as max_rc_discharge_cfs,
	ST_Transform(inun.geom, 3857) as geom, -- FIM data is in epsg:102039 by default, need to reproject.
	inun.huc8,
	derived.channels_conus.strm_order, 
    derived.channels_conus.name,
    'mrf_10day' AS config
FROM ingest.mrf_max_inundation_10day as inun 
left join derived.channels_conus ON derived.channels_conus.feature_id = inun.feature_id;

-- Update the SRID metadata
SELECT UpdateGeometrySRID('publish', 'mrf_max_inundation', 'geom', 3857);