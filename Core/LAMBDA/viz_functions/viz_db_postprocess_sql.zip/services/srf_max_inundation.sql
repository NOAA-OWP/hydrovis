DROP TABLE IF EXISTS publish.srf_max_inundation;

SELECT 
	inun.*,
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time, 
	derived.channels_conus.strm_order, 
    derived.channels_conus.name
INTO publish.srf_max_inundation
FROM ingest.srf_max_inundation as inun 
left join derived.channels_conus ON derived.channels_conus.feature_id = inun.feature_id;

-- Update the SRID metadata
SELECT UpdateGeometrySRID('publish', 'srf_max_inundation', 'geom', 3857);