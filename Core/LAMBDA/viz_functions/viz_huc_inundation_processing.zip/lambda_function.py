import json
import boto3
import rasterio
import numpy as np
import pandas as pd
import concurrent.futures
import threading
import os
from io import StringIO

from viz_lambda_shared_funcs import get_configuration, check_s3_file_existence, get_db_connection, get_service_metadata
from es_logging import get_elasticsearch_logger
es_logger = get_elasticsearch_logger()

EMPTY_RASTER_BUCKET = os.environ['EMPTY_RASTER_BUCKET']
EMPTY_RASTER_MRF_PREFIX = os.environ['EMPTY_RASTER_MRF_PREFIX']

FR_FIM_BUCKET = os.environ['FR_FIM_BUCKET']
FR_FIM_PREFIX = os.environ['FR_FIM_PREFIX']

MS_FIM_BUCKET = os.environ['MS_FIM_BUCKET']
MS_FIM_PREFIX = os.environ['MS_FIM_PREFIX']

PROCESSED_OUTPUT_BUCKET = os.environ['PROCESSED_OUTPUT_BUCKET']
PROCESSED_OUTPUT_PREFIX = os.environ['PROCESSED_OUTPUT_PREFIX']

viz_optimize_raster_function = os.environ['viz_optimize_raster_function']


def asynch_lambda_call(input_raster_bucket, input_raster_key, output_raster_bucket, output_raster_key, data_file,
                       processed_huc):
    """
        A helper function to kick off an asynchronous call for the optimize rasters lamba which converts a tif to a mrf

        Args:
            input_raster_bucket (str): Name of the bucket where the tif resides
            input_raster_key (str): key (path) of the input tif file
            output_raster_bucket (str): Name of the bucket where the mrf will reside
            output_raster_key (str): key (path) of the output mrf file
            data_file (str): key (path) of the file that was used for processing
            processed_huc (str): HUC ID that was processed
    """
    print(f"Kicking off the optimize rasters lambda for {input_raster_key}")
    client = boto3.client('lambda')

    input_params = {    # all the inputs to the inundation function
        "input_raster_bucket": input_raster_bucket,
        "input_raster_key": input_raster_key,
        "output_raster_bucket": output_raster_bucket,
        "output_raster_key": output_raster_key,
        "data_file": data_file,
        "processed_huc": processed_huc
    }

    client.invoke(
        FunctionName=viz_optimize_raster_function,
        InvocationType='Event',  # asynchronous call (don't wait for function to finish)
        Payload=json.dumps(input_params)
    )

    return


def lambda_handler(event, context):
    """
        The lambda handler is the function that is kicked off with the lambda. This function will coordinate
        the overall workflow from retrieving data, parsing it, kicking off the inundation workflow, saving the outputs,
        and then kicking off the next lambda which optimizes the raster for the cloud

        Args:
            event(event object): An event is a JSON-formatted document that contains data for a Lambda function to
                                 process
            context(object): Provides methods and properties that provide information about the invocation, function,
                             and runtime environment
    """
    # Parse the event argument to get the necessary arguments for the function
    max_flows_key = event['filename']
    HUC = event['huc']
    subsetted_streams = event['data']
    composite_mode = event['composite_mode'] if 'composite_mode' in event else 'composite'
    inundation_mode = event['inundation_mode'] if 'inundation_mode' in event else 'mask'
    output_raster_bucket = event['output_raster_bucket'] if 'output_raster_bucket' in event else PROCESSED_OUTPUT_BUCKET
    output_raster_key = event['output_raster_key'] if 'output_raster_key' in event else None

    print(f"Processing {HUC} with the following data: {subsetted_streams}")

    # Parses the max flows key to get the necessary metadata for the output file
    metadata = get_configuration(max_flows_key, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')

    es_logger.info(f"Processing HUC {HUC} for {configuration} for {date}T{hour}:00:00Z")

    # Use this list to keep track if main stem/full resolution can/will be used
    config_passes = []

    # Validate main stem datasets by checking cathment, hand, and rating curves existence for the HUC
    if composite_mode in ['composite', 'ms']:
        ms_catchment_key = f'{MS_FIM_PREFIX}/{HUC}/catchments_{HUC}.tif'
        ms_catch_exists = check_s3_file_existence(MS_FIM_BUCKET, ms_catchment_key)

        ms_hand_key = f'{MS_FIM_PREFIX}/{HUC}/hand_grid_{HUC}.tif'
        ms_hand_exists = check_s3_file_existence(MS_FIM_BUCKET, ms_hand_key)

        ms_rating_curve_key = f'{MS_FIM_PREFIX}/{HUC}/hydroTable.csv'
        ms_rating_curve_exists = check_s3_file_existence(MS_FIM_BUCKET, ms_rating_curve_key)

        if ms_catch_exists and ms_hand_exists and ms_rating_curve_exists:
            config_passes.append('ms')
        else:
            print(f"Main stem dataset (catchment, hand, or rating curve) are missing for huc {HUC}")

    # Validate full resolution datasets by checking cathment, hand, and rating curves existence for the HUC
    if configuration != 'replace_route' and composite_mode in ['composite', 'fr']:
        fr_catchment_key = f'{FR_FIM_PREFIX}/{HUC}/catchments_{HUC}.tif'
        fr_catch_exists = check_s3_file_existence(FR_FIM_BUCKET, fr_catchment_key)

        fr_hand_key = f'{FR_FIM_PREFIX}/{HUC}/hand_grid_{HUC}.tif'
        fr_hand_exists = check_s3_file_existence(FR_FIM_BUCKET, fr_hand_key)

        fr_rating_curve_key = f'{FR_FIM_PREFIX}/{HUC}/hydroTable.csv'
        fr_rating_curve_exists = check_s3_file_existence(FR_FIM_BUCKET, fr_rating_curve_key)

        if fr_catch_exists and fr_hand_exists and fr_rating_curve_exists:
            config_passes.append('fr')
        else:
            print(f"Full resolution dataset (catchment, hand, or rating curve) are missing for huc {HUC}")

    # If no valid datasets exist for the desired run configuration, then raise an exception
    if not config_passes:
        raise Exception(f"No HAND datasets available for huc {HUC}")

    # If not output raster is specified that default to the workspace and set optimize to True
    optimize = False
    if not output_raster_key:
        output_raster_key = f'{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/tif/{HUC}.tif'
        mrf_raster_key = f'{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/mrf/{HUC}.mrf'
        optimize = True

    # Run the desired configuration
    print(f"Processing {' and '.join(config_passes)} FIM for {HUC}. Outputs will be put in {output_raster_bucket}:{output_raster_key}")  # noqa
    raster_created = calc_inundation(subsetted_streams, config_passes, HUC, output_raster_bucket, output_raster_key, max_flows_key, inundation_mode)  # noqa

    # If optimize is True and the datasets were created successfully, then kick off optimization lambda
    if optimize and raster_created:
        asynch_lambda_call(output_raster_bucket, output_raster_key, PROCESSED_OUTPUT_BUCKET, mrf_raster_key, max_flows_key, HUC)  # noqa

    return


def calc_inundation(subsetted_streams, config_passes, huc, output_bucket, output_key, max_flows_key, inundation_mode):
    """
        Main inundation function that handles the inundation workflow from convering streamflows to stage, creating
        local inundation output, and then saving the output to an S3 bucket.

        Args:
            subsetted_streams(dictionary): dictionary containing feaure ids as keys with streamflows as the value
            config_passes(list): list that determines if full resolution (fr) and/or main stem (ms) will be run
            huc(str): HUC that is being processed
            output_bucket(str): S3 bucket where the inundation tif will be copied
            output_key(str): key (path) where the S3 tif raster will be saved
            max_flows_key(str): key (path) of the max flows file that was used to get the streamflow data
            inundation_mode(str): mode for how the inundation will be processed. mask will mask the depths to create
                                  a flood extent. depth will create depth grids

        Returns:
            Boolean: True if the raster was created successfully, else False
    """
    s3 = boto3.client('s3')

    # Get stage data for full resolution configuration
    fr_stage_lookup = None
    if 'fr' in config_passes:
        print("->Calculating flood depth for valid streams in the full resolution dataset")
        fr_stage_lookup = get_reach_stage_lookup(subsetted_streams, 'fr', huc, max_flows_key)  # get stages
        fr_valid_stages = {x[0]:x[1] for x in fr_stage_lookup if x[1] != -9999}  # get a dictionary of features with valid stages  # noqa
        print(f"Full resolution valid stages - {fr_valid_stages}")
        if not fr_valid_stages:
            print("-->No valid full resolution streams")
            fr_stage_lookup = None

    # Get stage data for main stem configuration
    ms_stage_lookup = None
    if 'ms' in config_passes:
        print("->Calculating flood depth for valid streams in the main stem dataset")
        ms_stage_lookup = get_reach_stage_lookup(subsetted_streams, 'ms', huc, max_flows_key)  # get stages
        ms_valid_stages = {x[0]:x[1] for x in ms_stage_lookup if x[1] != -9999}  # get a dictionary of features with valid stages  # noqa
        print(f"Main stem valid stages - {ms_valid_stages}")
        if not ms_valid_stages:
            print("-->No valid main stem streams")
            ms_stage_lookup = None

    # If no features with above zero stages are present, then just copy an unflood raster instead of processing nothing
    if not fr_stage_lookup and not ms_stage_lookup:
        print("No reaches with valid stages")
        copy_empty_raster(huc, max_flows_key)
        return False

    print("->Creating inundation raster")
    # Create a folder for the local tif outputs
    inundation_raster = f'/tmp/raw_rasters/{huc}.tif'
    if not os.path.exists('/tmp/raw_rasters/'):
        os.mkdir('/tmp/raw_rasters/')

    create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_raster, inundation_mode)

    # Write output depth to S3
    print(f"->Writing {inundation_raster} to {output_bucket}")
    s3.upload_file(inundation_raster, output_bucket, output_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})

    metadata = get_configuration(max_flows_key, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')

    es_logger.info(f"Successfully processed tif for HUC {huc} for {configuration} for {date}T{hour}:00:00Z")

    return True


def create_inundation_output(huc, fr_stage_lookup, ms_stage_lookup, inundation_raster, inundation_mode):
    """
        Creates the actual inundation output from the stages, catchments, and hand grids

        Args:
            huc(str): HUC that is being processed
            fr_stage_lookup(str): list of lists that have a feature id with its corresponding stage for full resolution
            ms_stage_lookup(str): list of lists that have a feature id with its corresponding stage for main stem
            inundation_raster(str): local tif output for inundation
            inundation_mode(str): mode for how the inundation will be processed. mask will mask the depths to create
                                  a flood extent. depth will create depth grids
    """
    # Only process inundation configuration if available data
    process_fr = False
    if fr_stage_lookup:
        process_fr = True

    process_ms = False
    if ms_stage_lookup:
        process_ms = True

    # join metadata to get path to FIM datasets
    fr_catchment_key = f'{FR_FIM_PREFIX}/{huc}/catchments_{huc}.tif'
    fr_hand_key = f'{FR_FIM_PREFIX}/{huc}/hand_grid_{huc}.tif'
    ms_catchment_key = f'{MS_FIM_PREFIX}/{huc}/catchments_{huc}.tif'
    ms_hand_key = f'{MS_FIM_PREFIX}/{huc}/hand_grid_{huc}.tif'

    try:
        ms_hand_dataset = None
        ms_catchment_dataset = None
        fr_hand_dataset = None
        fr_catchment_dataset = None

        if process_ms:
            print("--> Setting up main stem mapping array")
            tries = 0
            while tries < 3:
                try:
                    ms_hand_dataset = rasterio.open(f's3://{MS_FIM_BUCKET}/{ms_hand_key}')  # open HAND grid from S3
                    ms_catchment_dataset = rasterio.open(f's3://{MS_FIM_BUCKET}/{ms_catchment_key}')  # open catchment grid from S3  # noqa
                    tries = 3
                except Exception as e:
                    tries += 1
                    print(f"Failed to open MS datasets. Trying again - ({e})")

            ms_catchment_nodata = int(ms_catchment_dataset.nodata)  # get no_data value for catchment raster
            ms_valid_catchments = [int(catchment[0]) for catchment in ms_stage_lookup if catchment[1]!=-9999]  # parse lookup to get features with >0 stages  # noqa
            ms_hydroids = [int(stage[0]) for stage in ms_stage_lookup]  # parse lookup to get all features
            ms_stages = [stage[1] for stage in ms_stage_lookup]  # parse lookup to get all stages

            ms_k = np.array(ms_hydroids)  # Create a feature numpy array from the list
            ms_v = np.array(ms_stages)  # Create a stage numpy array from the list

            ms_hydro_id_max = ms_k.max()  # Get the max feature id in the array

            ms_hand_nodata = ms_hand_dataset.nodata  # get the no_data value for the HAND raster
            ms_hand_dtype = ms_hand_dataset.dtypes[0]  # get the dtype for the HAND raster
            profile = ms_hand_dataset.profile  # get the rasterio profile so the output can use the profile and match the input  # noqa

        if process_fr:
            print("--> Setting up full resolution mapping array")
            tries = 0
            while tries < 3:
                try:
                    fr_hand_dataset = rasterio.open(f's3://{FR_FIM_BUCKET}/{fr_hand_key}')  # open HAND grid from S3
                    fr_catchment_dataset = rasterio.open(f's3://{FR_FIM_BUCKET}/{fr_catchment_key}')  # open catchment grid from S3  # noqa
                    tries = 3
                except Exception as e:
                    tries += 1
                    print(f"Failed to open FR datasets. Trying again - ({e})")

            fr_catchment_nodata = int(fr_catchment_dataset.nodata)  # get no_data value for catchment raster
            fr_valid_catchments = [int(catchment[0]) for catchment in fr_stage_lookup if catchment[1]!=-9999]  # parse lookup to get features with >0 stages  # noqa
            fr_hydroids = [int(stage[0]) for stage in fr_stage_lookup]  # parse lookup to get all features
            fr_stages = [stage[1] for stage in fr_stage_lookup]  # parse lookup to get all stages

            fr_k = np.array(fr_hydroids)  # Create a feature numpy array from the list
            fr_v = np.array(fr_stages)  # Create a stage numpy array from the list

            fr_hydro_id_max = fr_k.max()  # Get the max feature id in the array

            fr_hand_nodata = fr_hand_dataset.nodata  # get the no_data value for the HAND raster
            fr_hand_dtype = fr_hand_dataset.dtypes[0]  # get the dtype for the HAND raster
            profile = fr_hand_dataset.profile  # get the rasterio profile so the output can use the profile and match the input  # noqa

        # set the output nodata to 0
        profile['nodata'] = 0
        nbits = 0
        
        if inundation_mode == 'mask':
            profile['nodata'] = 0
            profile['dtype'] = "uint8"
            nbits = 1

        # create a read and write lock to handle multiple processes accessing data
        read_lock = threading.Lock()
        write_lock = threading.Lock()

        # Open the output raster using rasterio. This will allow the inner function to be parallel and write to it
        with rasterio.open(inundation_raster, "w", nbits=nbits, **profile) as dst:
            print("--> Setting up windows")

            # Get the list of windows according to the raster metadata so they can be looped through
            windows = [window for ij, window in dst.block_windows()]

            # This function will be run for each raster window.
            def process(window):
                """
                    This function is run for each raster window in parallel. The function will read in the appropriate
                    window of the HAND and catchment datasets for main stem and/or full resolution. The stages will
                    then be mapped from a numpy array to the catchment window. This will create a windowed stage array.
                    The stage array is then compared to the HAND window array to create an inundation array where the
                    HAND values are gte to the stage values.

                    Each windowed inundation array is then saved to the output array for that specific window that was
                    ran.

                    For more information on rasterio window processing, see
                    https://rasterio.readthedocs.io/en/latest/topics/windowed-rw.html

                    If main stem AND full resolution are ran, then the inundation arrays for each configuration will be
                    compared and the highest value for each element in the array will be used. This is how we 'merge'
                    the two configurations. Because the extents of fr and ms are not the same, we do have to reshape
                    the arrays a bit to allow for the comparison
                """
                # Keep the overall raster ms/fr configuration tracking separate from the window raster configuration
                # This way we can take shortcuts in processing in the window while maintaing the output raster
                # structure for the entire raster
                window_process_fr = process_fr
                window_process_ms = process_ms

                if window_process_fr:
                    # Because the fr/ms extents are not exactly the same, we need to make sure to keep track of which
                    # window belongs to which configuration
                    fr_window = window

                    with read_lock:
                        fr_catchment_window = fr_catchment_dataset.read(window=fr_window)  # Read the dataset for the specified window  # noqa

                        unique_window_catchments = np.unique(fr_catchment_window).tolist()  # Get a list of unique hydroids within the window  # noqa
                        window_valid_catchments = [catchment for catchment in unique_window_catchments if catchment in fr_valid_catchments]  # Check to see if any hydroids with stages >0 are inside this window  # noqa
                        # Only process if there are hydroids with stage >0 in this window
                        if not window_valid_catchments:
                            window_process_fr = None
                        else:
                            fr_hand_window = fr_hand_dataset.read(window=fr_window)

                if window_process_ms:
                    # Because the fr/ms extents are not exactly the same, we need to make sure to keep track of which
                    # window belongs to which configuration
                    ms_window = window

                    with read_lock:
                        # if the overall output raster is using full resolution, then the window passed to this
                        # function is a full resolution window.
                        # In order to get the main stem window that corresponds, we need to get the bounds from the
                        # fr dataset and then get a new window from the ms dataset
                        if process_fr:
                            fr_bounds = fr_hand_dataset.window_bounds(window)
                            ms_window = ms_hand_dataset.window(*fr_bounds)

                        ms_catchment_window = ms_catchment_dataset.read(window=ms_window)  # Read the dataset for the specified window  # noqa

                        unique_window_catchments = np.unique(ms_catchment_window).tolist()  # Get a list of unique hydroids within the window  # noqa
                        window_valid_catchments = [catchment for catchment in unique_window_catchments if catchment in ms_valid_catchments]  # Check to see if any hydroids with stages >0 are inside this window  # noqa

                        # Only process if there are hydroids with stage >0 in this window
                        if not window_valid_catchments:
                            window_process_ms = None
                        else:
                            ms_hand_window = ms_hand_dataset.read(window=ms_window)

                # If there are no hydroids with stage >0 for both configurations,
                # then just return 0 (an nonflooded window)
                if not window_process_fr and not window_process_ms:
                    return 0

                # If there are valid hydroids in the windowed full resolution dataset, then it will be processed
                if window_process_fr:
                    # Create an empty numpy array with the nodata value that will be overwritten
                    fr_inundation_window = np.full(fr_catchment_window.shape, fr_hand_nodata, fr_hand_dtype)

                    # If catchment window values exist, then find the max between the stage mapper (fr_hydro_id_max)
                    # and the window
                    fr_mapping_ar_max = max(fr_hydro_id_max, fr_catchment_window.max())

                    # Create a stage mapper that will convert hydroids to their corresponding stage. -9999 is null or
                    # no value. we cant use 0 because it will mess up the mapping and use the 0 index
                    fr_mapping_ar = np.full(fr_mapping_ar_max+1, -9999, dtype="float32")
                    fr_mapping_ar[fr_k] = fr_v

                    fr_catchment_window[np.where(fr_catchment_window == fr_catchment_nodata)] = 0  # Convert catchment values to 0 where the catchment = catchment_nodata  # noqa
                    fr_catchment_window[np.where(fr_hand_window == fr_hand_nodata)] = 0  # Convert catchment values to 0 where the HAND = HAND_nodata. THis will ensure we are only processing where we have HAND values!  # noqa

                    fr_reclass_window = fr_mapping_ar[fr_catchment_window]  # Convert the catchment to stage

                    condition1 = fr_reclass_window > fr_hand_window  # Select where stage is gte to HAND
                    condition2 = fr_reclass_window != -9999  # Select where stage is valid
                    fr_conditions = (condition1) & (condition2)

                    # Use where statements to select the inundated areas in the window
                    if inundation_mode == 'mask':
                        fr_inundation_window = np.where(fr_conditions, 1, 0).astype('uint8')
                    else:
                        fr_inundation_window = np.where(fr_conditions, fr_reclass_window-fr_hand_window, 0).astype('float32')  # noqa

                # If there are valid hydroids in the windowed main dataset, then it will be processed
                if window_process_ms:
                    # Create an empty numpy array with the nodata value that will be overwritten. No data value
                    # depends on the overall raster output
                    if process_fr:
                        ms_inundation_window = np.full(fr_catchment_window.shape, fr_hand_nodata, fr_hand_dtype)
                    else:
                        ms_inundation_window = np.full(ms_catchment_window.shape, ms_hand_nodata, ms_hand_dtype)

                    # If catchment window values exist, then find the max between the stage mapper (fr_hydro_id_max)
                    # and the window
                    ms_mapping_ar_max = max(ms_hydro_id_max, ms_catchment_window.max())

                    # Create a stage mapper that will convert hydroids to their corresponding stage. -9999 is null or
                    # no value. we cant use 0 because it will mess up the mapping and use the 0 index  # noqa
                    ms_mapping_ar = np.full(ms_mapping_ar_max+1, -9999, dtype="float32")
                    ms_mapping_ar[ms_k] = ms_v

                    ms_catchment_window[np.where(ms_catchment_window == ms_catchment_nodata)] = 0  # Convert catchment values to 0 where the catchment = catchment_nodata  # noqa
                    ms_catchment_window[np.where(ms_hand_window == ms_hand_nodata)] = 0  # Convert catchment values to 0 where the HAND = HAND_nodata. THis will ensure we are only processing where we have HAND values!  # noqa

                    ms_reclass_window = ms_mapping_ar[ms_catchment_window]  # Convert the catchment to a stage

                    condition1 = ms_reclass_window > ms_hand_window  # Select where stage is gte to HAND
                    condition2 = ms_reclass_window != -9999  # Select where stage is valid
                    ms_conditions = (condition1) & (condition2)

                    # Use where statements to select the inundated areas in the window
                    if inundation_mode == 'mask':
                        ms_inundation_window = np.where(ms_conditions, 1, 0).astype('uint8')
                    else:
                        ms_inundation_window = np.where(ms_conditions, ms_reclass_window-ms_hand_window, 0).astype('float32')  # noqa

                # If both fr AND ms were processed, then we need to 'merge' the datasets. We will do this by getting
                # the max of the two arrays
                if window_process_fr and window_process_ms:
                    # Using padding and reshaping, we need to make the ms and fr arrays the same shape so we can
                    # compare them
                    if fr_inundation_window.shape[1] < ms_inundation_window.shape[1]:
                        ms_inundation_window = ms_inundation_window[:, :fr_inundation_window.shape[1]-ms_inundation_window.shape[1], :]  # noqa
                    elif fr_inundation_window.shape[1] > ms_inundation_window.shape[1]:
                        dim2_pad = ((0, 0), (0, fr_inundation_window.shape[1]-ms_inundation_window.shape[1]), (0, 0))
                        ms_inundation_window = np.pad(ms_inundation_window, pad_width=dim2_pad, mode='constant', constant_values=0)  # noqa

                    if fr_inundation_window.shape[2] < ms_inundation_window.shape[2]:
                        ms_inundation_window = ms_inundation_window[:, :, :fr_inundation_window.shape[2]-ms_inundation_window.shape[2]]  # noqa
                    elif fr_inundation_window.shape[2] > ms_inundation_window.shape[2]:
                        dim3_pad = ((0, 0), (0, 0), (0, fr_inundation_window.shape[2]-ms_inundation_window.shape[2]))
                        ms_inundation_window = np.pad(ms_inundation_window, pad_width=dim3_pad, mode='constant', constant_values=0)  # noqa

                    # Get the max of both arrays to produce a merged inundation window
                    # TODO: What is the best method? Prioritize Main stem? max?
                    inundation_window = np.maximum(fr_inundation_window, ms_inundation_window)

                    del fr_inundation_window
                    del ms_inundation_window
                elif window_process_fr:
                    inundation_window = fr_inundation_window
                    del fr_inundation_window
                else:
                    inundation_window = ms_inundation_window
                    del ms_inundation_window

                # Checking to see if there is any inundated areas in the window
                if not inundation_window[np.where(inundation_window != 0)].any():
                    return 0

                # Write the final windowed inundation to the destination raster for the specified window
                with write_lock:
                    dst.write(inundation_window, window=window)

                return np.max(inundation_window)

            if process_fr and process_ms:
                print("--> Calculating windowed inundation using main stem and full resolution")
            elif process_fr:
                print("--> Calculating windowed inundation using full resolution")
            else:
                print("--> Calculating windowed inundation using main stem")

            # Use threading to parallelize the processing of the inundation windows
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                result_futures = list(map(lambda window: executor.submit(process, window), windows))
                for future in concurrent.futures.as_completed(result_futures):
                    try:
                        if future.result() is not None:
                            if future.result() != 0:
                                pass
                    except Exception as e:
                        es_logger.warning(e)

    except Exception as e:
        raise e
    finally:
        if ms_hand_dataset is not None:
            ms_hand_dataset.close()

        if ms_catchment_dataset is not None:
            ms_catchment_dataset.close()

        if fr_hand_dataset is not None:
            fr_hand_dataset.close()

        if fr_catchment_dataset is not None:
            fr_catchment_dataset.close()


def get_reach_stage_lookup(data_csv_key, config, huc, forecast_file):
    """
        Main function for converting streamflows to stages. Downloads the hydrotable and json file with the streamflow
        data. The streamflow data is then compared to the rating curve to determine interpolated stages.

        Args:
            data_csv_key(str): key (path) to the S3 json file that contains the streamflow data for the huc
            config(str): ms (main stem) or fr (full resolution) configuration
            huc(str): HUC that is being processed
            forecast_file(str): key (path) to the S3 max flows/nwm file used for overall service

        Returns:
            stage_lookup(list): list of list showing hydroids with interpolated stages. -9999 is no stage. [[100, 1],
                                [101, -9999], [102, 3], ...]
    """
    print("-->Getting rating curve data")
    s3 = boto3.client('s3')

    # These are local files that will be created from downloading S3 data
    hydro_table_output = f"/tmp/{config}_hydroTable.csv"
    local_data = "/tmp/data.csv"

    # Get the appropriate bucket and key prefix for the FIM datasets
    if config == 'fr':
        config_bucket = FR_FIM_BUCKET
        config_prefix = FR_FIM_PREFIX
    elif config == 'ms':
        config_bucket = MS_FIM_BUCKET
        config_prefix = MS_FIM_PREFIX
    else:
        raise Exception(f"{config} is invalid. Config must be fr or ms")

    # Download the rating curve from S3 and put it into a pandas dataframe
    hydro_table_key = f'{config_prefix}/{huc}/hydroTable.csv'

    s3.download_file(config_bucket, hydro_table_key, hydro_table_output)
    df_rc = pd.read_csv(hydro_table_output)
    df_rc = df_rc.set_index('feature_id')
    os.remove(hydro_table_output)

    # If there is no data json file, then return list with all invalid stages
    if not data_csv_key:
        df_rc = df_rc.reset_index()
        df_rc['interpolated_stages'] = -9999  # default all stages to null value (-9999)
        df_rc['HydroID'] = df_rc['HydroID'].astype(str)
        df_rc = df_rc.drop_duplicates(subset=['HydroID'])
        return df_rc[['HydroID', 'interpolated_stages']].values.tolist()

    # Download the csv data from S3
    s3.download_file(PROCESSED_OUTPUT_BUCKET, data_csv_key, local_data)
    df_fc = pd.read_csv(local_data)
    df_fc = df_fc.set_index('feature_id')
    os.remove(local_data)

    # Just grab the streamflow field for rating curve comparison
    df_fc = df_fc[['streamflow']]

    # Ignore reaches that are lakes
    df_rc = df_rc[df_rc['LakeID'] == -999]

    # Only calculate stages for reaches that have a valid forecast
    df_rc = df_rc[df_rc.index.isin(df_fc.index.values)]

    # Add streamflow value to the rating curve dataframe
    df_rc = df_rc.merge(df_fc, how="inner", left_index=True, right_index=True)
    df_rc = df_rc.reset_index()
    df_rc = df_rc.set_index('HydroID')

    # Grab the largest stage value for each processed reach for later db
    # dump and metadata configuration
    df_rc_max = df_rc.sort_values('stage').groupby('HydroID').tail(1)

    # Shift the stage/flow values for next rating curve step so each row has a
    # range of flows/stages for the specific rating curve step
    df_rc['next_discharge_cms'] = df_rc.groupby('HydroID')['discharge_cms'].shift(-1)
    df_rc['next_stage'] = df_rc.groupby('HydroID')['stage'].shift(-1)

    # Select reaches where the flow is between the discharge column and the next discharge column
    condition1 = (df_rc['streamflow'] >= df_rc['discharge_cms'])
    condition2 = (df_rc['streamflow'] <= df_rc['next_discharge_cms'])
    condition3 = df_rc['next_discharge_cms'].isna()

    df_rc = df_rc[condition1 & (condition2 | condition3)]

    # Remove any duplicated hydroids. This happens with some weird rating curve behavior
    # where larger stages and lower flow thresholds. Grab the lowest passed stage
    df_rc = df_rc[~df_rc.index.duplicated()]

    # Calculate the interpolated (linearly) stages using the stage rate of change and the discharge change
    stage_rate_of_change = ((df_rc['next_stage'] - df_rc['stage']) / (df_rc['next_discharge_cms'] - df_rc['discharge_cms']))  # noqa
    discharge_change = df_rc['streamflow'] - df_rc['discharge_cms']
    df_rc['interpolated_stages'] = df_rc['stage'] + discharge_change * stage_rate_of_change

    # Make the interpolated stage equal to the max stage for reaches whose streamflow exceeds the max streamflow in the rating curve
    df_rc.loc[df_rc['interpolated_stages'].isna(), 'interpolated_stages'] = df_rc['stage']
    df_rc['interpolated_stages'] = df_rc['interpolated_stages'].round(2)

    # Remove any reaches with 0 stage if not running replace and route configuration
    if "replace_route" not in forecast_file:
        df_rc = df_rc[(df_rc['interpolated_stages'] != 0)]

    print(f"Expecting to process {len(df_rc)} rows")

    # Combine metadata from multiple datasets to gather db information in one place
    df_db = pd.merge(df_fc, df_rc[["interpolated_stages", "feature_id"]], how="inner", left_index=True, right_on="feature_id")  # noqa
    df_db = df_db.merge(df_rc_max[["stage", "discharge_cms"]], how="inner", left_index=True, right_index=True)

    # Load dataframe into db if not empty
    if not df_db.empty:
        load_df_into_db(df_db, config, forecast_file)

    df_rc = df_rc.reset_index()
    stage_lookup = df_rc[['HydroID', 'interpolated_stages']].values.tolist()

    return stage_lookup


def load_df_into_db(df_db, config, forecast_file):
    """
        Creates a pandas dataframe that joins the interpolated stages with the hydro id metadata and
        then add the dataframe data to a postgis database

        Args:
            df_db(pandas.dataframe): DataFrame that contains the final entry of a
                hydro_id rating curve along with other feature metadata
            config(str): fr or ms depending on which fim configuration is being ran
            forecast_file(str): key (path) to the S3 max flows/nwm file used for overall service
    """
    # Get metadata to determine where to insert data into the DB
    services = get_service_metadata()
    metadata = get_configuration(forecast_file, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')
    reference_time = f"{date}T{hour}:00:00Z"

    insert_table = [service['ingest_table'] for service in services if service['configuration'] == f"fim_{configuration}" and service['run'] is True][0]  # noqa
    print(f"Attempting to update {insert_table}")

    df_db = df_db[~df_db.index.duplicated()]
    df_db = df_db.reset_index()

    # Add additional columns
    fim_prefix = f"{config.upper()}_FIM_PREFIX"
    df_db['fim_version'] = os.environ.get(fim_prefix).split("fim_")[-1].split(f"_{config}")[0]
    df_db['reference_time'] = reference_time
    df_db['fim_configuration'] = config
    df_db['max_rc_h'] = (df_db['stage'] * 3.28084).astype(int)  # Convert from M to FT
    df_db['max_rc_q'] = df_db['discharge_cms'] * 35.3147  # Convert from CMS to CFS
    df_db = df_db.drop(columns=['stage', 'discharge_cms'])
    df_db['max_rc_q'] = df_db['max_rc_q'].round(2)
    df_db['interpolated_stages'] = df_db['interpolated_stages'] * 3.28084  # Convert from M to FT
    df_db['streamflow'] = df_db['streamflow'] * 35.3147  # Convert from CMS to CFS
    df_db['streamflow'] = df_db['streamflow'].round(2)
    df_db['interpolated_stages'] = df_db['interpolated_stages'].round(2)

    # Connect to DB
    connection = get_db_connection("viz")

    # Load data into DB
    try:
        cursor = connection.cursor()
        f = StringIO()
        df_db.to_csv(f, sep='\t', index=False, header=False)
        f.seek(0)
        cursor.copy_from(f, insert_table, sep='\t', null='')  # This is the command that actual copies the data to the db  # noqa
        connection.commit()
    except Exception as e:
        raise e
    finally:
        cursor.close()
        connection.close()

    print(f"Updated {insert_table} with {len(df_db)} rows")


def copy_empty_raster(HUC, max_flows_key):
    '''
        Copies the empty (no inundation) raster from S3 into the S3 workspace instead of doing all the huc processing
        for nothing

        Args:
            HUC (str): HUC that will be processed
            max_flow_key (str): forecast file used for streamflows. Used to extract metadata for workspace path
    '''
    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')

    # Extract metadata from file path
    metadata = get_configuration(max_flows_key, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')

    output_folder = f"{PROCESSED_OUTPUT_BUCKET}:{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/mrf"
    es_logger.warning(f"Copying empty raster for HUC {HUC} for {configuration} for {date}T{hour}:00:00Z to {output_folder}")  # noqa

    # Connect to bucket and search for empty raster mrf files (there should be 4 files)
    FIM_Bucket = s3_resource.Bucket(EMPTY_RASTER_BUCKET)
    files_prefix = f'{EMPTY_RASTER_MRF_PREFIX}/{HUC}'
    huc_keys = FIM_Bucket.objects.filter(Prefix=files_prefix).all()
    huc_files = [huc.key for huc in huc_keys]

    if not huc_files:
        raise Exception(f"Empty Raster for {HUC} does not exist at {EMPTY_RASTER_BUCKET}:{files_prefix}")

    # Moved all the mrf files for the empty raster to the mrf workspace for the specific run
    for huc_file in huc_files:
        new_location_key = f"{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/mrf/{os.path.basename(huc_file)}"  # noqa
        copy_source = {'Bucket': EMPTY_RASTER_BUCKET, 'Key': huc_file}
        s3.copy(copy_source, PROCESSED_OUTPUT_BUCKET, new_location_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})

    es_logger.info(f"Successfully processed mrf for HUC {HUC} for {configuration} for {date}T{hour}:00:00Z")
    return
