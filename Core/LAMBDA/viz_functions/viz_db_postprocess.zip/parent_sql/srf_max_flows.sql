DROP TABLE IF EXISTS CACHE.MAX_FLOWS_SRF;
SELECT forecasts.feature_id,
   round((max(forecasts.streamflow) * 35.315::double precision)::numeric, 2) AS maxflow_18hour
INTO CACHE.MAX_FLOWS_SRF
FROM ingest.nwm_channel_rt_srf forecasts
GROUP BY forecasts.feature_id;