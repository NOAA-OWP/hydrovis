DROP TABLE IF EXISTS CACHE.MAX_FLOWS_SRF_HI;

SELECT forecasts.feature_id,
   round((max(forecasts.streamflow) * 35.315::double precision)::numeric, 2) AS maxflow_48hour
INTO CACHE.MAX_FLOWS_SRF_HI
FROM ingest.nwm_channel_rt_srf_hi forecasts
GROUP BY forecasts.feature_id;