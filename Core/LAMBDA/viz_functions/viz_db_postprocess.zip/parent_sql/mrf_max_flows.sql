DROP TABLE IF EXISTS CACHE.MAX_FLOWS_MRF;

SELECT forecasts.feature_id,
    round((max(
        CASE
            WHEN forecasts.forecast_hour <= 72 THEN forecasts.streamflow
            ELSE NULL::double precision
        END) * 35.315::double precision)::numeric, 2) AS maxflow_3day,
    round((max(
        CASE
            WHEN forecasts.forecast_hour <= 120 THEN forecasts.streamflow
            ELSE NULL::double precision
        END) * 35.315::double precision)::numeric, 2) AS maxflow_5day,
    round((max(forecasts.streamflow) * 35.315::double precision)::numeric, 2) AS maxflow_10day
INTO CACHE.MAX_FLOWS_MRF
FROM ingest.nwm_channel_rt_mrf_mem1 forecasts
GROUP BY forecasts.feature_id;