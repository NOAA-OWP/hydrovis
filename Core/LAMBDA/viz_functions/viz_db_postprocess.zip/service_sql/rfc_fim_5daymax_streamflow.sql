DROP TABLE IF EXISTS PUBLISH.rfc_fim_5daymax_streamflow;
WITH reference_time AS (
     SELECT max(ingest_status.reference_time) AS reference_time
       FROM admin.ingest_status
      WHERE ingest_status.target::text = 'ingest.rnr_max_flows'::text
    )
	
SELECT ingest.rnr_max_flows.feature_id, 
	ingest.rnr_max_flows.feature_id::TEXT AS feature_id_str,
	Name, 
	to_char(REFERENCE_TIME, 'YYYY-MM-DD HH24:MI:SS UTC') AS reference_time,
	STRING_AGG(FORECAST_NWS_LID || ' @ ' || FORECAST_ISSUE_TIME || ' (' || FORECAST_MAX_STATUS || ')', ', ') AS INHERITED_RFC_FORECASTS,
	MAX(forecast_max_value) * 35.31467 AS MAX_FLOW,
	INITCAP(MAX(REPLACE(VIZ_MAX_STATUS, '_', ' '))) AS MAX_STATUS,
	INITCAP(MAX(WATERBODY_STATUS)) AS WATERBODY_STATUS,
	Strm_Order,
	to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time,
	geom
INTO PUBLISH.rfc_fim_5daymax_streamflow
FROM INGEST.RNR_MAX_FLOWS
left join derived.channels_conus ON INGEST.RNR_MAX_FLOWS.feature_id = derived.channels_conus.feature_id, reference_time
GROUP BY INGEST.RNR_MAX_FLOWS.FEATURE_ID, feature_id_str, Name, reference_time, Strm_Order, geom;