DROP TABLE IF EXISTS PUBLISH.srf_rapid_onset_flooding;
-- Get most recent reference time from the ingest status table
WITH reference_time AS (
	SELECT max(INGEST_STATUS.reference_time) AS reference_time 
	FROM ADMIN.INGEST_STATUS
	WHERE INGEST_STATUS.target = 'ingest.nwm_channel_rt_srf' and ingest_status.status = 'Import Complete'),
-- Calculate rapid onset reaches
rapid_onset AS (
	-- Calculate the info for the start of a rapid flood event - >=100% flow in one hour.
	WITH FloodStart AS (
		-- Add a rank value by feature_id, so we can look up info for the flood start later with 'rnk = 1'
		SELECT *, rank() OVER (PARTITION BY feature_id ORDER BY forecast_hour) as rnk
		FROM 	(SELECT forecasts.feature_id, forecast_hour, streamflow * 35.315 AS flow,
				-- Use the lag funtion to calucate percent change for each reach / forecast hour timestep
				 ((streamflow * 35.315) - (lag(streamflow * 35.315, 1) OVER (PARTITION BY forecasts.feature_id ORDER by forecast_hour)))/(lag(streamflow * 35.315, 1) OVER (PARTITION BY forecasts.feature_id ORDER by forecast_hour)) AS pct_chg
				FROM ingest.nwm_channel_rt_srf AS forecasts
				order by forecasts.feature_id, forecast_hour) AS pct_change
		WHERE pct_chg >= 1)
	-- Select the forecast related fields for the attribute table
	SELECT
		forecasts.feature_id,
		min(forecasts.forecast_hour) AS flood_start_hour,
		max(forecasts.forecast_hour) AS flood_end_hour,
		max(forecasts.forecast_hour) - min(forecasts.forecast_hour) AS flood_length,
		min(FloodStart.flow) AS flood_flow,
		MIN(FloodStart.pct_chg) AS flood_percent_increase,
		max(bankfull) AS Bankfull
	FROM ingest.nwm_channel_rt_srf AS forecasts
	JOIN FloodStart ON forecasts.feature_id = FloodStart.feature_id
	JOIN derived.recurrence_flows_conus AS thresholds ON forecasts.feature_id = thresholds.feature_id
	WHERE -- This is where the main forecast filter conditions go
		(thresholds.bankfull > 0 OR thresholds.bankfull = '-9995') AND -- Don't show reaches with invalid bankfull values
		((forecasts.streamflow * 35.315) >= thresholds.bankfull) AND -- Only show reaches that hit bankfull in the forecast window
		((forecasts.forecast_hour - FloodStart.forecast_hour) <= 6) AND -- At least 100% increase and bankfull within 6 hours of rapid onset
		FloodStart.rnk = 1
	GROUP BY forecasts.feature_id)

-- Put it all together with geometry
SELECT channels.*, to_char(reference_time, 'YYYY-MM-DD HH24:MI:SS UTC') AS reference_time, flood_start_hour, flood_end_hour, flood_length, flood_flow, flood_percent_increase, Bankfull,
ST_LENGTH(channels.geom)*0.000621371 AS reach_Length_miles, to_char(now()::timestamp without time zone, 'YYYY-MM-DD HH24:MI:SS UTC') AS update_time
INTO PUBLISH.srf_rapid_onset_flooding
FROM derived.channels_conus channels
JOIN rapid_onset ON channels.feature_id = rapid_onset.feature_id, reference_time
where channels.strm_order <= 4;