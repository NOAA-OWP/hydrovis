import os
import boto3
import time
import json
import psycopg2
import psycopg2.extras
import select
import datetime
import pandas as pd
from arcgis.gis import GIS
from viz_lambda_shared_funcs import (get_secret_password, get_db_engine, get_db_connection, get_service_metadata,
                                     check_s3_file_existence)
from es_logging import get_elasticsearch_logger

es_logger = get_elasticsearch_logger()

s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')


def lambda_handler(event, context):
    start_time = time.time()
    step_time = time.time()

    # Get configuration and reference time from SNS message
    # These are passed in a string in the return of the ingest lambda function.
    event = json.loads(json.loads(event['Records'][0]['Sns']['Message'])['responsePayload'])[0] if event.get('Records') else event  # noqa: E501
    configuration = event.get('configuration')
    reference_time = event.get('reference_time') if event.get('reference_time') else None

    current_time = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    start_time_formatted = event.get('ingest_start_formatted')if event.get('ingest_start_formatted') else current_time

    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 5,
        "process_db_step": "5 - Starting Postprocessing", "configuration_db": configuration,
        "reference_time": reference_time,
        "last_step": "4 - Import Complete - Starting Postprocessing",
        "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
    }
    es_logger.info(json.dumps([dump_dict]))
    step_time = time.time()

    # Get service metadata from the admin.services table in the postgresql database.
    print("Fetching service metadata from RDS.")
    services_data = get_service_metadata(include_ingest_sources=False, include_latest_ref_time=True)

    # Use the service metadata to find the parent and service SQL files to use,
    # and only including services that are set to process
    # Service files will start executing asynchronously in sequential order.
    # Until better monitoring is setup. Try to sequence them in order of fastest to slowest run-time.
    non_sql_services = [service for service in services_data if service.get('configuration') == configuration and service.get('postprocess_sql') is None and service.get('run') is True]  # noqa: E501
    parents = [service['postprocess_parents'] for service in services_data if service['configuration'] == configuration and service['run'] is True and service['postprocess_parents'] is not None]  # noqa: E501
    services = [service for service in services_data if service.get('configuration') == configuration and service.get('run') is True]  # noqa: E501
    finals = [service for service in services if service.get('postprocess_finals') is not None]

    # If no reference time was passed in,
    # use the latest reference time ingested for the group of services being processed.
    if reference_time is None:
        reference_time = max(service['reference_time'] for service in services)[:-4]
        print(reference_time)

    if len(services) == 0:
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 999,
            "process_db_step": "Failure (invalid or innactive configuration)",
            "configuration_db": configuration, "reference_time": reference_time
        }
        es_logger.info(json.dumps([dump_dict]))
        exit

    # If non-sql services exist, publish those.
    if len(non_sql_services) > 0:
        service_logs = [(service['service'], datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')) for service in non_sql_services]  # noqa: E501
        try:
            publish_services(service_logs, non_sql_services)
        except Exception as e:
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 999,
                "process_db_step": "Failure (failed to check or publish non-sql services)",
                "configuration_db": configuration, "reference_time": reference_time,
                "services": non_sql_services, "error": str(e)
            }
            es_logger.info(json.dumps([dump_dict]))
            exit()
    else:
        # Run post-processing sql in the parent folder
        if len(parents) > 0:
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 6.1,
                "process_db_step": "6.1 - Running parent sql.", "configuration_db": configuration,
                "reference_time": reference_time, "parents": parents,
                "last_step": "5 - Starting Postprocessing",
                "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
            }
            es_logger.info(json.dumps([dump_dict]))
            step_time = time.time()
            try:
                run_sql_files_sync('parent_sql', parents)
            except Exception as e:
                dump_dict = {
                    "start_time": start_time_formatted, "process_db_code": 999,
                    "process_db_step": "Failure (failed to run parent sql)",
                    "configuration_db": configuration, "reference_time": reference_time,
                    "parents": parents, "error": str(e)
                }
                es_logger.info(json.dumps([dump_dict]))
                exit()

        # Run post-processing sql for listed services and return the service_logs list
        # es_logger.info(f"DB Pipeline - Postprocessing Services:
        # viz_db_postprocess started at {start_time}. Running {services} asyncronously.")
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 6.2,
            "process_db_step": "6.2 - Running service sql", "configuration_db": configuration,
            "reference_time": reference_time, "services": services,
            "last_step": "6.1 - Running parent sql." if len(parents) > 0 else "5 - Starting Postprocessing",
            "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
        }
        es_logger.info(json.dumps([dump_dict]))
        step_time = time.time()

        try:
            service_logs = run_sql_files_async('service_sql', services, reference_time)
        except Exception as e:
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 999,
                "process_db_step": "Failure (failed to run service sql)",
                "configuration_db": configuration, "reference_time": reference_time,
                "services": services, "error": str(e)
            }
            es_logger.info(json.dumps([dump_dict]))
            exit()

        # Run post-processing sql in the final folder
        if len(finals) > 0:
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 6.1,
                "process_db_step": "6.3 - Running final sql.", "configuration_db": configuration,
                "reference_time": reference_time, "parents": parents, "finals": finals,
                "last_step": "6.2 - Running service sql",
                "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
            }
            es_logger.info(json.dumps([dump_dict]))
            step_time = time.time()
            try:
                run_sql_files_async('final_sql', finals, reference_time, finals=True)
            except Exception as e:
                dump_dict = {
                    "start_time": start_time_formatted, "process_db_code": 999,
                    "process_db_step": "Failure (failed to run parent sql)",
                    "configuration_db": configuration, "reference_time": reference_time,
                    "parents": parents, "error": str(e)
                }
                es_logger.info(json.dumps([]))
                exit()

        # Publish any non-published services
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 7,
            "process_db_step": "7 - Publishing services if needed",
            "configuration_db": configuration, "reference_time": reference_time,
            "services": services, "last_step": "6.3 - Running final sql.",
            "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
        }
        es_logger.info(json.dumps([dump_dict]))
        step_time = time.time()

        try:
            publish_services(service_logs, services_data)
        except Exception as e:
            dump_dict = {
                "start_time": start_time_formatted, "process_db_code": 999,
                "process_db_step": "Failure (failed to check or publish services)",
                "configuration_db": configuration, "reference_time": reference_time,
                "services": services, "error": str(e)
            }
            es_logger.info(json.dumps([dump_dict]))
            exit()

    # Push a log of service updates / monitoring to the database
    connection = get_db_connection("viz")
    cur = connection.cursor()
    for service, pp_complete_time, publish_action in service_logs:
        dump_dict = {
            "start_time": start_time_formatted, "process_db_code": 8,
            "process_db_step": "8 - Service Updated Successfully",
            "configuration_db": configuration, "reference_time": reference_time, "service": service,
            "last_step": "7 - Publishing services if needed",
            "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
        }
        es_logger.info(json.dumps([dump_dict]))
        step_time = time.time()
        SQL = f"INSERT INTO admin.publish_status (service, reference_time, pp_complete_time, publish_action) " \
              f"VALUES ('{service}', '{reference_time}', '{pp_complete_time}', '{publish_action}')"
        cur.execute(SQL)
    connection.commit()
    cur.close()
    connection.close()

    # Print completion time for Lambda logs.
    completion_time = str(round(((time.time() - start_time) / 60.0), 1))
    print(f"Post-processing completed in {completion_time} minutes.")
    dump_dict = {
        "start_time": start_time_formatted, "process_db_code": 9, "process_db_step": "9 - Postprocessing Complete",
        "configuration_db": configuration, "reference_time": reference_time, "services": services,
        "last_step": "8 - Service Updated Successfully",
        "last_step_duration": round(((time.time() - step_time) / 60.0), 1)
    }
    es_logger.info(json.dumps([dump_dict]))


def run_sql_files_sync(folder, files):
    """
    This function iterates through a specified list of sql files in a specified folder and sequentionally runs those
    against the database specified in environment variables. psycopg2 waits for the database to finish processing each
    command before proceeding, so this function is to be used for sql (e.g. max flows) that needs to be run prior to
    sql that can be run asynchronously (e.g. services that rely on max flows).

    Args:
        folder (str): The name of the folder in which sql files are located.
        files (list): The list of sql files to run (omitting .sql)

    """
    connection = get_db_connection("viz")
    cursor = connection.cursor()
    for file in files:  # Loop through files and execute the sql
        print(f"Executing {folder}/{file}.sql")
        cursor.execute(open(f"{folder}/{file}.sql", 'r').read())
    connection.commit()
    cursor.close()
    connection.close()


def run_sql_files_async(folder, services, reference_time, finals=False):
    """
    This function iterates through a specified list of sql files in a specified folder and asynchronously runs those
    against the database specified in environment variables. psycopg2 starts each sql file in sequence, but does not
    Wwait for the database to finish processing each command before proceeding until the wait function is called.
    Therefore, this function should not be used for any sql that other services or queries are dependent on.

    Args:
        folder (str): The name of the folder in which sql files are located.
        services (list): The list of services dictionaries to process.

    Returns:
        run_logs (list): A list of the files ran and the timestamp associated with their finish time.

    """
    connections = []
    run_logs = []

    # Setup an a-sync database connection, execute the SQL on the database, and move on.
    def start_sql_async(folder, file, primary_key):
        connection = get_db_connection("viz", asynchronous=1)
        wait(connection)  # make sure the connection is ready
        cursor = connection.cursor()
        print(f"Starting {folder}/{file}.sql")
        cursor.execute(open(f'{folder}/{file}.sql', 'r').read())
        connections.append((file, primary_key, connection, cursor))

    # Wait for a database connection to poll OK before proceeding.
    def wait(conn):
        while 1:
            state = conn.poll()
            if state == psycopg2.extensions.POLL_OK:
                break
            elif state == psycopg2.extensions.POLL_WRITE:
                select.select([], [conn.fileno()], [])
            elif state == psycopg2.extensions.POLL_READ:
                select.select([conn.fileno()], [], [])

    # Read data from the viz_processing table, and publish it to the EGIS RDS database.
    def publish_data_to_egis(table, primary_key):
        # Add feature_id primary key to make sure we don't have any duplicates, and to speed up reading
        vizprc_engine.execute(f'ALTER TABLE publish.{table} ADD PRIMARY KEY ({primary_key});')
        df = pd.read_sql(f'SELECT * FROM publish.{table}', vizprc_engine)  # Read from the new table
        schema = 'services'
        stage_table = f'{table}_stage'
        full_stage_table_name = f"{schema}.{stage_table}"
        full_table_name = f"{schema}.{table}"

        # Generate a create table statement based on the dataframe
        create_table_statement = pd.io.sql.get_schema(df, full_stage_table_name)
        replace_values = {'"geom" TEXT': '"geom" GEOMETRY', "REAL": "DOUBLE PRECISION"}  # Correct data types
        for a, b in replace_values.items():
            create_table_statement = create_table_statement.replace(a, b)

        # pandas puts quotes around the table name. sql then assumes it is public."schema.table_name"
        create_table_statement = create_table_statement.replace(f'"{full_stage_table_name}"', full_stage_table_name)

        # Create or update the actual published data table on the egis database
        egis_engine.execute(f'DROP TABLE IF EXISTS {full_stage_table_name};')  # Drop the stage table if it exists
        egis_engine.execute(create_table_statement)  # Create the new empty stage table
        df.to_sql(con=egis_engine, schema=schema, name=stage_table, index=False, if_exists='append')  # Insert data
        egis_engine.execute(f'ALTER TABLE {full_stage_table_name} ADD COLUMN OID SERIAL PRIMARY KEY;')
        egis_engine.execute(f'CREATE INDEX ON {full_stage_table_name} USING GIST (geom);')  # Add a spatial index
        egis_engine.execute(f"SELECT UpdateGeometrySRID('{schema}','{stage_table}','geom',3857);")  # Update the SRID
        egis_engine.execute(f'DROP TABLE IF EXISTS {full_table_name};')  # Drop the published table if it exists
        egis_engine.execute(f'ALTER TABLE {full_stage_table_name} RENAME TO {table};')  # Rename the staged table

    def cache_data(table, retention_days=30):
        ref_time_dt = datetime.datetime.strptime(reference_time, '%Y-%m-%d %H:%M:%S')
        retention_cutoff = ref_time_dt - datetime.timedelta(retention_days)
        ref_time_short = ref_time_dt.strftime("%Y_%m_%d_%H_%M_%S")
        retent_cuttoff_short = retention_cutoff.strftime("%Y_%m_%d_%H_%M_%S")
        new_cache_table = f"cache.{table}_{ref_time_short}"
        cutoff_cache_table = f"cache.{table}_{retent_cuttoff_short}"
        vizprc_engine.execute(f'DROP TABLE IF EXISTS {new_cache_table};')
        vizprc_engine.execute(f'DROP TABLE IF EXISTS {cutoff_cache_table};')
        vizprc_engine.execute(f'SELECT * INTO {new_cache_table} FROM publish.{table};')
        print(f"Wrote cache data into {new_cache_table} and dropped corresponding table"
              " from {retention_days} days ago, if it existed.")

    # Start async post-processing
    for service in services:
        if finals is False:
            sql_file = service['service']
            primary_key = service['service_key']
        elif finals is True:
            sql_file = service['postprocess_finals']
            primary_key = service['postprocess_finals_key']

        start_sql_async(folder, sql_file, primary_key)

    vizprc_engine = get_db_engine("viz")
    egis_engine = get_db_engine("egis")

    # Wait for post-processing to finish in order of execution (need to figure out a better way) -
    # We can theoretically remove all this async logic and just fire SQL in automcommit mode
    # to have the lambda function close immediately while the database does its thing.
    #  Will wait to consider that until this is more stable
    for service, primary_key, conn, cur in connections:
        wait(conn)
        print(f"{service}.sql reported that it finished. (this process waits in the order that sql"
              " files were started, so this is not an accurate finish time)")
        publish_data_to_egis(service, primary_key)
        print("EGIS publish table has been updated.")
        # cache_data(service)
        cur.close()
        conn.close()
        run_logs.append((service, datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')))

        # Push the published tables into the egis database
        # We should look for ways to optimize this further as well, and we need some type of tracking.

    return run_logs


def publish_services(service_logs, services):
    """
    Iterate through services, check if already published to EGIS. If not, publish the service using a sd file stored
    on S3 to publish the service (can be exported from Arc Pro Project connected to the RDS database.)

    Args:
        service_logs (list): A list of services which have completed post-processing.
        services (dictionary): Dictionary of service metadata from admin.services db table.

    Returns:
        service_logs (list): An updated list of services which now includes publish status.

    """
    # Try getting a secret from secret manager, and look for a password environment variable if not.
    try:
        gis_password = os.getenv('GIS_PASSWORD')
    except Exception:
        try:
            gis_password = get_secret_password(os.getenv("GIS_SECRET_NAME"), 'us-east-1', 'hydrovis.proc')
        except Exception as e:
            print(f"Couldn't get egis portal password from environment variable or secret name. ({e})")

    gis = GIS(os.getenv('GIS_HOST'), os.getenv('GIS_USERNAME'), gis_password, verify_cert=False)
    service_tag = os.getenv('SERVICE_TAG')
    s3 = boto3.client('s3')
    publish_flag_bucket = os.getenv('PUBLISH_FLAG_BUCKET')
    gis_servers = gis.admin.servers.list()
    server1 = gis_servers[1]

    print(f"Checking services on {server1}")
    for index, service in enumerate(service_logs):  # Using the service_logs to publish status information.
        service_name = service[0]
        service_name_publish = service_name + service_tag
        folder = [item['folder'] for item in services if item['service'] == service_name].pop()
        summary = [item['summary'] for item in services if item['service'] == service_name].pop() + f" ({service_tag[1:].capitalize()})"  # noqa: E501
        description = [item['description'] for item in services if item['service'] == service_name].pop()
        tags = [item['tags'] for item in services if item['service'] == service_name].pop().split(', ')
        credits = [item['credits'] for item in services if item['service'] == service_name].pop()
        publish_flag_key = f"published_flags/server/{folder}/{service_name}/{service_name}"

        # Check to see if the service already exists and a publish flag is present or not.
        matching_services = [service for service in server1.services.list(folder=folder) if service.properties['serviceName'] == service_name or service.properties['serviceName'] == service_name_publish]  # noqa: E501
        publish_flag = check_s3_file_existence(publish_flag_bucket, publish_flag_key)
        if len(matching_services) > 0 and publish_flag is True:
            print(f"{matching_services[0].properties['serviceName']} is already online.")
            service_logs[index] = service + ("Already published",)
            publish = False
        elif len(matching_services) > 0 and publish_flag is False:
            print(f"{matching_services[0].properties['serviceName']} is already online, but a publish flag isn't. Attempting to republish.")
            publish = True
        else:
            print(f"{service_name_publish} does not currently exist on EGIS. Attempting to publish.")
            publish = True
            
        if publish is True:  
            # Check to see if an sd file is present on s3
            sd_s3_path = os.getenv('SD_S3_PATH') + service_name + '.sd'
            if check_s3_file_existence(os.getenv('S3_BUCKET'), sd_s3_path) is False:
                print(f"---> {sd_s3_path} does not currently exist. Skipping.")
                service_logs[index] = service + ("No sd file found",)
            else:
                print(f"---> An sd file for {service_name} is present on S3. Proceeding with publish.")
                local_sd_file = f'/tmp/{service_name}.sd'
                s3.download_file(os.getenv('S3_BUCKET'), sd_s3_path, local_sd_file)
                print(f"---> Downloaded {sd_s3_path}")
                # Publish the service
                server1.services.publish_sd(sd_file=local_sd_file, folder=folder)
                print(f"---> Published {sd_s3_path}")

                # Find the new service and update its item properties and sharing to match what's in the db
                # (yes, the ArcGIS Python API uses another class to do this for some reason)
                try:
                    portal_contents = gis.content.search(service_name, item_type='Map Service')
                    new_item = [item for item in portal_contents if item.title == service_name_publish][0]
                except IndexError:
                    print(f"Error: Didn't find the just published {service_name} on portal: {portal_contents}")
                    exit()
                new_item.update(item_properties={'snippet': summary, 'description': description,
                                'tags': tags, 'accessInformation': credits})
                print(f"---> Updated {service_name} descriptions, tags, and credits in Portal.")
                new_item.share(org=True)
                print(f"---> Updated {service_name} sharing to org in Portal.")
                
                # Create publish flag file
                tmp_published_file = f"/tmp/{service_name}"
                open(tmp_published_file, 'a').close()
                s3.upload_file(tmp_published_file, publish_flag_bucket, publish_flag_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})
                print(f"---> Created publish flag {publish_flag_key} on {publish_flag_bucket}.")

                os.remove(local_sd_file)
                print(f"---> Successfully published {service_name} using {sd_s3_path}.")
                service_logs[index] = service + ("Published Successfully",)