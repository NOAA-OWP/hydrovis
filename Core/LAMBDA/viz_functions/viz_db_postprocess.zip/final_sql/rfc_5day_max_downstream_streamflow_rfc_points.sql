DROP TABLE IF EXISTS PUBLISH.rfc_5day_max_downstream_streamflow_rfc_points;
SELECT
    ahps.nws_lid,
    usgs_sitecode,
    nws_name,
    ST_SetSRID(ST_MakePoint( longitude, latitude), 4326) AS geom
INTO PUBLISH.rfc_5day_max_downstream_streamflow_rfc_points
FROM ingest.ahps_metadata ahps
INNER JOIN ingest.rnr_max_flows rfc ON ahps.nws_lid = rfc.nws_lid
GROUP BY ahps.nws_lid, usgs_sitecode, nws_name, geom