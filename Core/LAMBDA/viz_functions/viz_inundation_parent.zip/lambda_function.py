import boto3
import re
import os
import json
import urllib.parse
import xarray as xr
import pandas as pd
import datetime
import time

from viz_lambda_shared_funcs import get_configuration, get_service_metadata, get_db_values, get_db_connection
from es_logging import get_elasticsearch_logger
es_logger = get_elasticsearch_logger()

viz_huc_inundation_function = os.environ['viz_huc_inundation_function']
max_flows_function = os.environ['max_flows_function']

FIM_DATA_BUCKET = os.environ['FIM_DATA_BUCKET']

PROCESSED_OUTPUT_BUCKET = os.environ['PROCESSED_OUTPUT_BUCKET']
PROCESSED_OUTPUT_PREFIX = os.environ['PROCESSED_OUTPUT_PREFIX']

EMPTY_RASTER_BUCKET = os.environ['EMPTY_RASTER_BUCKET']
EMPTY_RASTER_MRF_PREFIX = os.environ['EMPTY_RASTER_MRF_PREFIX']


def asynch_lambda_call(huc, filename, huc_data):
    """
        A helper function to kick off an asynchronous call for the huc processing lamba which converts creates
        inundation

        Args:
            huc (str): HUC that will be processed
            filename (str): key (path) of the forecast file that is being used
            huc_data (str): subsetted streamflow data for the specified HUC
    """
    client = boto3.client('lambda')

    print(f"Kicking off the lambda for {huc}")
    # In order to make sure we do not exceed the payload size, we need to put the HUC data into an S3 json file
    data_key = write_data_csv_file(huc, filename, huc_data)

    input_params = {    # all the inputs to the inundation function
        "huc": huc,
        "filename": filename,
        "data": data_key,
    }

    client.invoke(
        FunctionName=viz_huc_inundation_function,
        InvocationType='Event',  # asynchronous call (don't wait for function to finish)
        Payload=json.dumps(input_params)
    )

    return


def lambda_handler(event, context):
    """
        The lambda handler is the function that is kicked off with the lambda. This function will take a forecast file,
        extract features with streamflows above 1.5 year threshold, and then kick off lambdas for each HUC with valid
        data.

        Args:
            event(event object): An event is a JSON-formatted document that contains data for a Lambda function to
                                 process
            context(object): Provides methods and properties that provide information about the invocation, function,
                             and runtime environment
    """
    # parse the event to get the bucket and file that kicked off the lambda
    try:
        filename = event['data_key']
        filename_bucket = event['data_bucket']
    except Exception:
        try:
            filename = urllib.parse.unquote_plus(event["Records"][0]['s3']['object']['key'], encoding='utf-8')
            filename_bucket = urllib.parse.unquote_plus(event["Records"][0]['s3']['bucket']['name'], encoding='utf-8')
        except Exception:
            message = json.loads(event["Records"][0]['Sns']['Message'])
            filename = urllib.parse.unquote_plus(message["Records"][0]['s3']['object']['key'], encoding='utf-8')
            filename_bucket = urllib.parse.unquote_plus(message["Records"][0]['s3']['bucket']['name'], encoding='utf-8')

    # This is for one_off testing
    one_off = event.get("hucs")

    # Parses the forecast key to get the necessary metadata for the output file
    metadata = get_configuration(filename, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')
    reference_time = f"{date}T{hour}:00:00Z"

    if configuration in ["analysis_assim_7day"]:
        print(f"Lambda not configured to run {configuration}")
        return

    setup_db_table(configuration, reference_time)

    if configuration == 'replace_route':  # srf max flows, mrf max flows, or ana nwm
        service_type = "rnr"
    else:
        service_type = "nwm"

    # Extract features that are above the 1.5 year recurrence threshold
    subset_df, all_HUCs = subset_streamflows(filename_bucket, filename, service_type)

    # Get the hucs that will need to be processed
    if one_off:
        hucs_to_process = one_off
    else:
        hucs_to_process = get_hucs_to_process(all_HUCs)

    transfer_empty_hucs = []
    # launch process for each of the huc6s.
    # If it has data, pass the data else add to list for copying empty rasters
    es_logger.info(f"Kicking off {len(hucs_to_process)} hucs for {configuration} for {date}T{hour}:00:00Z")
    for huc in hucs_to_process:
        huc_data = subset_df[subset_df['huc6'] == huc]  # get data for this huc only
        if not huc_data.empty:
            asynch_lambda_call(huc, filename, huc_data)

            if one_off:
                print(f"{huc}-{huc_data}")
        else:
            transfer_empty_hucs.append(huc)

    # For each HUC with no streamflow data, copy empty rasters to workspace
    for huc in transfer_empty_hucs:
        copy_empty_raster(huc, filename)
        pass

    return


def setup_db_table(configuration, reference_time):
    """
        Sets up the necessary tables in a postgis data for later ingest from the huc processing functions

        Args:
            configuration(str): service configuration for the service being ran (i.e. srf, srf_hi, etc)
            reference_time(str): Reference time of the data being ran
    """
    # Get metadata to determine where to insert data into the DB
    services = get_service_metadata()
    insert_table = [service['ingest_table'] for service in services if service['configuration']==f"fim_{configuration}" and service['run'] is True][0]  # noqa
    index_name = f"idx_{insert_table.split('.')[-1:].pop()}_hydro_id"

    print(f"Setting up {insert_table}")
    # Connect to the postgis DB
    connection = get_db_connection("viz")

    try:
        cur = connection.cursor()

        # Add a row to the ingest status table indicating that an import has started.
        SQL = f"INSERT INTO admin.ingest_status (target, reference_time, status, update_time) " \
              f"VALUES ('{insert_table}', '{reference_time}', 'Import Started', " \
              f"'{datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')}')"
        cur.execute(SQL)

        # Drop the existing index on the target table
        print("Dropping target table index (if exists).")
        SQL = f"DROP INDEX IF EXISTS ingest.{index_name};"
        cur.execute(SQL)

        # Truncate all records.
        print("Truncating target table.")
        SQL = f"TRUNCATE TABLE {insert_table};"
        cur.execute(SQL)
        connection.commit()
    except Exception as e:
        raise e
    finally:
        cur.close()
        connection.close()


def subset_streamflows(bucket, streamflow_file, service_type):
    """
        Select all the features whose streamflow is above its 1.5 year recurrence flow

        Args:
            bucket(str): S3 bucket where the forecast file resides
            streamflow_file(str): key (path) of the forecast file
            service_type(str): forecast configuration, i.e. nwm, rfc, owp, etc

        Returns:
            subsetted_streams(dataframe): subsetted dataframe of features with streamflow above 1.5 year recurrence flow
            HUCs(list): list of all the HUCs (with or without data) from the forecast file
    """
    s3 = boto3.client('s3')

    # Download the S3 forecast file
    download_path = f'/tmp/{os.path.basename(streamflow_file)}'
    print(f"--> Downloading {bucket}/{streamflow_file} to {download_path}")
    s3.download_file(bucket, streamflow_file, download_path)

    # Open forecast files and create a pandas dataframe
    if ".nc" in download_path:
        with xr.open_dataset(download_path) as ds:
            df = ds[['feature_id', 'streamflow']].to_dataframe()
            df.reset_index(inplace=True)  # make sure feature_id is a column and not an index
    else:
        df = pd.read_csv(download_path)
        df = df.rename(columns={'Feature ID': 'feature_id', 'Max Flow': 'streamflow'})
    os.remove(download_path)

    df_hucs = get_db_values("derived.featureid_huc_crosswalk", ["feature_id", "huc6"])
    df_hucs = df_hucs.set_index('feature_id')

    # Join recurrence flows and streamflow data
    df_joined = pd.merge(df, df_hucs, on='feature_id', how='inner')
    del df_hucs
    del df

    df_joined = df_joined.loc[df_joined['huc6'] > 0]
    df_joined['huc6'] = df_joined['huc6'].astype(int).astype(str).str.zfill(6)

    HUCs = df_joined['huc6'].unique()

    # Select features with streamflow above 0
    print("Subsetting streamflows")
    df_joined = df_joined[df_joined['streamflow'] > 0]

    if service_type == 'nwm':  # nwm fim (have to use this syntax way to avoid "ambiguous" error)
        # Get the correct recurrence file based on domain
        if "_hi" in streamflow_file or "hawaii" in streamflow_file:
            recurrence_flows_table = "derived.recurrence_flows_hi"
        elif "_prvi" in streamflow_file or "puertorico" in streamflow_file:
            recurrence_flows_table = "derived.recurrence_flows_prvi"
        else:
            recurrence_flows_table = "derived.recurrence_flows_conus"

        # Get correct file and high flow threshold value for the domain
        df_high_water_threshold = get_db_values(recurrence_flows_table, ["feature_id", "high_water_threshold"])
        df_high_water_threshold = df_high_water_threshold.set_index('feature_id')

        df_joined = pd.merge(df_joined, df_high_water_threshold, on='feature_id', how='inner')
        del df_high_water_threshold

        df_joined = df_joined[df_joined["high_water_threshold"] > 0]  # Removed reaches with zero high flow threshold
        df_joined["high_water_threshold"] = df_joined["high_water_threshold"] / 35.3147  # cfs to cms conversion
        df_joined = df_joined[df_joined['streamflow'] >= df_joined["high_water_threshold"]]  # get subset of high flow threshold flows
    else:
        df_joined = df_joined[~df_joined['Viz Max Status'].isin(['no_flooding', 'none', 'no_forecast'])]
        df_joined = df_joined[df_joined['Waterbody Status'].isna()]
        df_joined = df_joined.set_index("feature_id")
        df_joined = df_joined[~df_joined.index.duplicated(keep="first")]
        df_joined = df_joined.reset_index()

    return df_joined, HUCs


def copy_empty_raster(HUC, filename):
    '''
        Copies the empty (no inundation) raster from S3 into the S3 workspace instead of doing all the huc processing
        for nothing

        Args:
            HUC (str): HUC that will be processed
            filename (str): forecast file used for streamflows. Used to extract metadata for workspace path
    '''
    s3_resource = boto3.resource('s3')
    s3 = boto3.client('s3')

    # Extract metadata from file path
    metadata = get_configuration(filename, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')

    output_folder = f"{PROCESSED_OUTPUT_BUCKET}:{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/mrf"
    print(f"Copying empty raster for HUC {HUC} for {configuration} for {date}T{hour}:00:00Z to {output_folder}")

    # Connect to bucket and search for empty raster mrf files (there should be 4 files)
    FIM_Bucket = s3_resource.Bucket(EMPTY_RASTER_BUCKET)
    files_prefix = f'{EMPTY_RASTER_MRF_PREFIX}/{HUC}'
    huc_keys = FIM_Bucket.objects.filter(Prefix=files_prefix).all()
    huc_files = [huc.key for huc in huc_keys]

    if not huc_files:
        raise Exception(f"Empty Raster for {HUC} does not exist at {EMPTY_RASTER_BUCKET}:{files_prefix}")

    # Moved all the mrf files for the empty raster to the mrf workspace for the specific run
    for huc_file in huc_files:
        new_location_key = f"{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/mrf/{os.path.basename(huc_file)}"  # noqa
        copy_source = {'Bucket': EMPTY_RASTER_BUCKET, 'Key': huc_file}
        s3.copy(copy_source, PROCESSED_OUTPUT_BUCKET, new_location_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})

    es_logger.info(f"Successfully processed mrf for HUC {HUC} for {configuration} for {date}T{hour}:00:00Z")
    return


def get_hucs_to_process(all_HUCs):
    '''
        Compare all the HUCs in the domain with the HUCs that have available datasets. Get a list where they overlap
        so we can know what HUCs will actually be processed

        Args:
            service_type(str): forecast configuration, i.e. nwm, rfc, owp, etc
            all_HUCs (list): list of all the HUCs (with or without data) from the forecast file

        Returns:
            hucs_to_process(list): list of HUCs that are both in the forecast domain and have HAND datasets
    '''
    s3_resource = boto3.resource('s3')

    config = "fr"

    # Connect to the FIM bucket and get a list of all the available datasets for the FIM version
    FIM_Bucket = s3_resource.Bucket(FIM_DATA_BUCKET)
    huc_keys = FIM_Bucket.objects.filter(Prefix=f'fim_{os.environ["FIM_VERSION"].replace(".", "_")}_{config}_c/').all()

    # Loop through the datasets and keep track of what HUCs are available
    available_huc_datasets = []
    for huc_key in huc_keys:
        try:
            huc = re.findall(r"/(\d{6})/", huc_key.key)[0]
            if huc not in available_huc_datasets:
                available_huc_datasets.append(huc)
        except Exception:
            continue

    # Select HUCs that are in the domain AND have HAND datasets
    hucs_to_process = [huc for huc in all_HUCs if huc in available_huc_datasets]

    if not hucs_to_process:
        raise Exception("No HUCs are expected. Check code and paths.")

    return hucs_to_process


def write_data_csv_file(huc, filename, huc_data):
    '''
        Write the subsetted streamflow data to a csv so that the huc processing lambdas can grab it

        Args:
            huc(str): HUC that will be processed
            filename(str): Forecast file that was used
            huc_data(pandas.datafrm): Dataframe subsetted for the specific huc

        Returns:
            data_json_key(str): key (path) to the json file in the workspace folder
    '''
    s3 = boto3.client('s3')

    # Parses the forecast key to get the necessary metadata for the output file
    metadata = get_configuration(filename, return_input_files=False)
    configuration = metadata.get('configuration')
    date = metadata.get('date')
    hour = metadata.get('hour')

    # Key for the csv file that will be stored in S3
    csv_key = f"{PROCESSED_OUTPUT_PREFIX}/{configuration}/workspace/{date}/{hour}/data/{huc}_data.csv"

    # Save the dataframe as a local netcdf file
    tmp_csv = f'/tmp/{huc}.csv'
    huc_data = huc_data.set_index("feature_id")
    huc_data.to_csv(tmp_csv)

    # Upload the csv file into S3
    print(f"Uploading {csv_key}")
    s3.upload_file(tmp_csv, PROCESSED_OUTPUT_BUCKET, csv_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})
    os.remove(tmp_csv)

    return csv_key
