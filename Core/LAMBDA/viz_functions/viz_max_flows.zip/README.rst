=============================
Viz Max Flows
=============================

Event/Context
=============

Default (triggered key is used)

Process
=======

The Viz_Max_Flows lambda performs the following main tasks:

Retrieve and Extract Data from NWM Forecast
-------------------------------------------

The lambda function will extract the file name that was used as a trigger. The function will determine the configuration based on the file name and get a list of the files that will be processed. A loop will go through these files and extract the streamflow values for each file.

Calculate Max Streamflows
-------------------------

The lambda will take all the streamflow values from all the files that are being processed (the forecast) and calculate the max flow in the forecast.

Upload Max Flows File
---------------------

The max flows array is put into a netcdf file. This netcdf file is uploaded into S3 for the corresponding configuration (short_range, medium_range_3day, medium_range_5day, or medium_range_10day)

Triggers
========

- S3
    - Bucket: hydrovis-dev-nwm-us-east-1
    - Event type: ObjectCreated
    - Prefix: common/data/model/com/nwm/prod/
    - Suffix: short_range.channel_rt.f018.conus.nc
- S3
    - Bucket: hydrovis-dev-nwm-us-east-1
    - Event type: ObjectCreated
    - Prefix: common/data/model/com/nwm/prod/
    - Suffix: medium_range.channel_rt_1.f072.conus.nc
- S3
    - Bucket: hydrovis-dev-nwm-us-east-1
    - Event type: ObjectCreated
    - Prefix: common/data/model/com/nwm/prod/
    - Suffix: medium_range.channel_rt_1.f120.conus.nc
- S3
    - Bucket: hydrovis-dev-nwm-us-east-1
    - Event type: ObjectCreated
    - Prefix: common/data/model/com/nwm/prod/
    - Suffix: medium_range.channel_rt_1.f240.conus.nc

Layers
======

- xarray_python
