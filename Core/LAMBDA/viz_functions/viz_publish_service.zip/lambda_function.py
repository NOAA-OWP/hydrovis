import boto3
import os
from arcgis.gis import GIS
from viz_classes import s3_file

def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    service_data = event['args']['service']
    service_name = service_data['service']
    service_tag = os.getenv('SERVICE_TAG')
    service_name_publish = service_name + service_tag
    folder = service_data['egis_folder']
    summary = service_data['summary']
    description = service_data['description']
    tags = service_data['tags']
    credits = service_data['credits']
    server = service_data['egis_server']
    publish_flag_bucket = os.getenv('PUBLISH_FLAG_BUCKET')
    publish_flag_key = f"published_flags/server/{folder}/{service_name}/{service_name}"

    print("Attempting to Initialize the ArcGIS GIS class with the EGIS Portal.")
    # Connect to the GIS
    try:
        gis = GIS(os.getenv('GIS_HOST'), os.getenv('GIS_USERNAME'), os.getenv('GIS_PASSWORD'), verify_cert=False)
    except Exception as e:
        print("Failed to connect to the GIS")
        raise e
    
    gis_servers = gis.admin.servers.list()
    publish_server = None
    for gis_server in gis_servers:
        if server == "server":
            if "server" in gis_server.url or "egis-gis" in gis_server.url:
                publish_server = gis_server
                break
        elif server == "image":
            if "image" in gis_server.url or "egis-img" in gis_server.url:
                publish_server = gis_server
                break
    if not publish_server:
        raise Exception(f"Could not find appropriate GIS server for {server}")

    # Check to see if the service already exists and a publish flag is present or not.
    matching_services = [service for service in publish_server.services.list(folder=folder) if service.properties['serviceName'] == service_name or service.properties['serviceName'] == service_name_publish]  # noqa: E501
    publish_flag = s3_file(publish_flag_bucket, publish_flag_key).check_existence()
    if len(matching_services) > 0 and publish_flag is True:
        print(f"{matching_services[0].properties['serviceName']} is already online.")
        print(f"{service_name} already published")
        publish = False
    elif len(matching_services) > 0 and publish_flag is False:
        print(f"{matching_services[0].properties['serviceName']} is already online, but a publish flag isn't. Attempting to republish.")
        publish = True
    else:
        print(f"{service_name_publish} does not currently exist on EGIS. Attempting to publish.")
        publish = True
        
    if publish is True:  
        # Check to see if an sd file is present on s3
        sd_s3_path = os.getenv('SD_S3_PATH') + service_name + '.sd'
        
        if not s3_file(os.getenv('S3_BUCKET'), sd_s3_path).check_existence():
            print(f"---> {sd_s3_path} does not currently exist. Skipping.")
        else:
            print(f"---> An sd file for {service_name} is present on S3. Proceeding with publish.")
            local_sd_file = f'/tmp/{service_name}.sd'
            s3.download_file(os.getenv('S3_BUCKET'), sd_s3_path, local_sd_file)
            print(f"---> Downloaded {sd_s3_path}")
            # Publish the service
            publish_server.services.publish_sd(sd_file=local_sd_file, folder=folder)
            print(f"---> Published {sd_s3_path}")

            # Find the new service and update its item properties and sharing to match what's in the db
            # (yes, the ArcGIS Python API uses another class to do this for some reason)
            try:
                portal_contents = gis.content.search(service_name, item_type='Map Service')
                new_item = [item for item in portal_contents if item.title == service_name_publish][0]
            except IndexError as e:
                print(f"Error: Didn't find the just published {service_name} on portal: {portal_contents}")
                raise e
            new_item.update(item_properties={'snippet': summary, 'description': description,
                            'tags': tags, 'accessInformation': credits})
            print(f"---> Updated {service_name} descriptions, tags, and credits in Portal.")
            new_item.share(org=True)
            print(f"---> Updated {service_name} sharing to org in Portal.")
            
            # Create publish flag file
            tmp_published_file = f"/tmp/{service_name}"
            open(tmp_published_file, 'a').close()
            s3.upload_file(tmp_published_file, publish_flag_bucket, publish_flag_key, ExtraArgs={'ServerSideEncryption': 'aws:kms'})
            print(f"---> Created publish flag {publish_flag_key} on {publish_flag_bucket}.")

            os.remove(local_sd_file)
            print(f"---> Successfully published {service_name} using {sd_s3_path}.")
            
    return True