''' 
@package This file contains application level constants like version number etc.
'''

## This file contains application level constants like version number etc.
#  
#  United States Department of Commerce 
#  NOAA (National Oceanic and Atmospheric Administration) 
#  National Weather Service 
#  Office of Water Prediction 
#  @author Shafiq Rahman
#  @version 1.0
#  @date 10/03/2017

## @var NAME
# Name of application
NAME = "HMLReceiver"

## @var VERSION
# Version of the application
VERSION = "1.1"
