''' 
@package This file contains all configuration related constants like names of section,
option keys and their default values etc
'''

## This file contains all configuration related constants like names of section,
# option keys and their default values etc
#  
#  United States Department of Commerce 
#  NOAA (National Oceanic and Atmospheric Administration) 
#  National Weather Service 
#  Office of Water Prediction 
#  @author Shafiq Rahman
#  @version 1.0
#  @date 10/03/2017

## @var DEFAULT_CONFIG_FILENAME
#  Default config file name
DEFAULT_CONFIG_FILENAME = "receiver.conf"


##################
# RABBITMQ SECTION
##################

## @var RABBITMQ_SECTION
# Name of the rabbitmq section
RABBITMQ_SECTION = "rabbitmq"

## @var RABBITMQ_URL
# connection url for RabbitMQ
RABBITMQ_URL = "url"

## @var RABBITMQ_EXCHANGE
# name of exchange to create in RabbitMQ
RABBITMQ_EXCHANGE = "exchange"

## @var RABBITMQ_HML_EVENT_QUEUE
# name of HML url message queue in RabbitMQ
RABBITMQ_HML_EVENT_QUEUE = "hml_event_queue"

## @var RABBITMQ_HML_PREFETCH_COUNT
# how many max messages an hml consumer can receive at one time
RABBITMQ_HML_PREFETCH_COUNT = "hml_prefetch_count"

## @var RABBITMQ_DL_HML_TTL
# The time to live in seconds for hml dead letter queue
RABBITMQ_DL_HML_TTL = "dl_hml_message_ttl"

##################
# DATABASE SECTION
##################

## @var DATABASE_SECTION
# Name of database section
DATABASE_SECTION = "database"

## @var DATABASE_CONNECTION_STRING
# Connection string to database
DATABASE_CONNECTION_STRING = "connection_string"

##############
# LOG SECTION
##############

## @var LOG_SECTION
# Name of the log section
LOG_SECTION = "log"

## @var LOG_LEVEL
# Level of the log like debug, or info
LOG_LEVEL = "level"

## @var LOG_DEBUG_LEVEL
# value if debug log level is intended
LOG_DEBUG_LEVEL = "debug"

## @var LOG_TARGET
# key for where to save log output
LOG_TARGET = "target"

## @var LOG_FILE
# log to a file
LOG_FILE = "file"

## @var LOG_STREAM
# log to a stream (stdout)
LOG_STREAM = "stream"

## @var LOG_FILE
# Name (and path) of the log file, needed if LOG_TARGET is set to file
LOG_FILE_PATH = "file_path"

## @var LOG_FORMAT
# Formatting string of the log file
LOG_FORMAT = "format"

##############
# OBJECTSTORE SECTION
##############

## @var OBJECTSTORE_SECTION
# Name of the object store section
OBJECTSTORE_SECTION = "objectstore"

## @var OBJECTSTORE_HOST
# The host name of the object store
OBJECTSTORE_HOST = "host"

## @var OBJECTSTORE_PORT
# The port on which to connect to object store
OBJECTSTORE_PORT = "port"

## @var OBJECTSTORE_BUCKET
# The bucket to upload hml files to
OBJECTSTORE_BUCKET = "bucket"

## @var OBJECTSTORE_ACCESSKEY
# The access key to connect to object store
OBJECTSTORE_ACCESSKEY = "access_key"

## @var OBJECTSTORE_SECRETKEY
# The secret key to connect to object store
OBJECTSTORE_SECRETKEY = "secret_key"

###############
# FILE OUTPUT SECTION
###############

# @var FILE_OUTPUT_SECTION
# Name of the file output section
FILE_OUTPUT_SECTION = "file_output"

## @var FILE_OUTPUT_DIRECTORY
# The location where files should be written
FILE_OUTPUT_DIRECTORY = "output_directory"

## @var FILE_OUTPUT_HOST
# The public location where files can be accessed
FILE_OUTPUT_HOST = "file_host"
