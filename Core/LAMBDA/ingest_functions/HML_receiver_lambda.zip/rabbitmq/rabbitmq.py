"""
This class is used to hold details about RabbitMQ connection and provide a way
to open channels on that connection as needed. It is the responsibilty of caller
to use context manager on connection and channels or close them after use.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 01/05/2018
"""

# Import system libraries
import os
import sys
import logging
import pika

# module imports
from constants import app

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class RabbitMQManager(object):
    """ 
    This class creates and manages channels to RabbitMQ 
    
    The goal is to use the same connection but multiple channels to connect to
    different queues and possibly exchanges.
    """

    MILLISECONDS_PER_SECOND = 1000

    def __init__(self, rmq_url):
        """
        Initialize an instance of class

        Args:
            rmq_url: the connection url for RabbitMQ instance. For format please
                see the configuration file.
        """

        # the connection URL to RabbitMQ
        self.rmq_url = rmq_url

        # connection object to RabbitMQ instance
        self.connection = None

    def __del__(self):
        """
        Destroy an instance of class

        """

        # Close any open connections
        if self.connection:
            self.connection.close()

    def get_connection(self):
        """
        Get a connection object to RabbitMQ

        Returns:
            A blocking connection to RabbitMQ instance identified by rmq_url
        
        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        try:
            return pika.BlockingConnection(
                pika.URLParameters(url=self.rmq_url)
            )
        except pika.exceptions.ConnectionClosed:
            logger.error("Connection refused, probably no RabbitMQ server running")
            raise

    def setup(self, exchange, queue, message_ttl):
        """
        This functions sets up the hml exchange and queue if needed

        The function creates an hml exchange, a dead-letter hml exchange, an hml
        queue and a dead-letter hml queue. 

        Args:
            exchange: name of RabbitMQ exchange to establish channel with
            queue: name of RabbitMQ to create and bind producer with
            message_ttl: message time to live in seconds
        
        Returns:
            True if setup was successful else raises exceptions below

        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        # create a connection to RabbitMQ, if not existing
        if not self.connection:
            self.connection = self.get_connection()

        # create a channel over connection
        rmq_channel = self.connection.channel()

        # create or use a direct exchange and a dead letter exchange
        rmq_channel.exchange_declare( exchange=exchange, durable=True )

        dead_letter_exchange = "dl.{}".format( exchange )
        rmq_channel.exchange_declare( 
            exchange=dead_letter_exchange,
            durable=True
            )

        dead_letter_queue = "dl_{}".format( queue )

        # create or use an hml queue and bind it to exchange
        rmq_channel.queue_declare(
            queue=queue,
            durable=True,
            arguments={
                "x-dead-letter-exchange" : dead_letter_exchange,
                "x-dead-letter-routing-key" : dead_letter_queue
                }
            )
        rmq_channel.queue_bind( exchange=exchange, queue=queue )

        # create a dead letter queue for hml queue
        rmq_channel.queue_declare(
            queue=dead_letter_queue,
            durable=True,
            arguments={
                "x-message-ttl" : \
                    message_ttl * RabbitMQManager.MILLISECONDS_PER_SECOND,
                "x-dead-letter-exchange" : exchange,
                "x-dead-letter-routing-key" : queue
                }
            )
        rmq_channel.queue_bind( 
            exchange=dead_letter_exchange,
            queue=dead_letter_queue
            )

        rmq_channel.close()

        return True

    def get_channel(self, prefetch_count):
        """
        This function creates a channel object to an exchange

        The function creates a durable exchange if it doesn't exist and a durable
        queue and binds the queue to the exchange. Finally it returns the channel
        object for caller to use.

        Args:
            prefetch_count: the max number of messages to receive at one time

        Returns:
            A channel object to send/receive messages to RabbitMQ

        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        # create a connection to RabbitMQ, if not existing
        if not self.connection:
            self.connection = self.get_connection()

        channel = self.connection.channel()
        channel.basic_qos(prefetch_count=prefetch_count)

        return channel
