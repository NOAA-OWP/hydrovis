"""
This class is used to manage database related operations

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

#  Import System libraries
import logging

# ORM
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert

from sqlalchemy.exc import DatabaseError, OperationalError, IntegrityError
from sqlalchemy.orm.exc import NoResultFound

from sqlalchemy.pool import QueuePool

# module imports
from database.db_model import utcnow, Hml
from database.db_model import HmlStatusEnum
from constants import app
from constants.database import const_hml

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class DBManager(object):
    """
    This class is used to manage database related operations
    """

    def __init__(self, connection_string):
        """
        Initialize sqlalchemy engine and create a session

        The session scope is application wide and transaction scopes are limited
        to the functions. The session is closed in class destructor.

        Args:
            connection_string: The connection string to database of interest
        Returns:
            nothing
        Raises:
            NoSuchModuleError: If database doesn't exist
            OperationalError: if connection string is invalid like domain name,
            username, email etc.
        """

        ## @var engine
        # connection string to database
        # Note that setting isolation level to AUTOCOMMIT means that all of the
        # sql transactions will commit automatically, if more than one
        # sql queries need to be committed/rolledback together, we need to do
        # something special as mentioned in the following article:
        # http://oddbird.net/2014/06/14/sqlalchemy-postgres-autocommit/
        try:
            self.engine = create_engine(
                connection_string,
                pool_size=1,
                max_overflow=0,
                poolclass=QueuePool,
                isolation_level='AUTOCOMMIT'
                )
        except DatabaseError as db_error:
            logger.error(str(db_error))
            raise

        ## @var sessionmaker
        # settings for database sessions factory method
        self.session_maker = sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            autocommit=True
            )

    def __enter__(self):
        """
        Get a db session

        Args:
             nothing
        Returns:
            an instance of Session bound to the sqlalchemy engine
        """

        self.session = self.session_maker()
        return self.session

    def __exit__(self, *args):
        """
        Close the db session
        """

        self.session.close()

    @staticmethod
    def insert_hml(session, hml_object_key):
        """
        Create an entry in HML table

        Create an entry in HML table marking the arrival time of the HML and its
        object key after uploading it to the object store. 

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_object_key: the url to the hml file in object store

        Returns:
            The synthetic key id of the row just inserted

        Raises:
            IntegrityError: if missing non-null field while inserting
        """
 
        # Check for existing record (unlikely)

        result = session.query(Hml.hml_id).filter(getattr(Hml,const_hml.COLUMN_URL) == hml_object_key).first()
        
        if not result:
            logger.debug('Inserting new database record for %s', hml_object_key)
            # hml status timestamp will be current time in UTC
            hml_row = {
                const_hml.COLUMN_URL: hml_object_key,
                const_hml.COLUMN_HML_STATUS: HmlStatusEnum.received,
                const_hml.COLUMN_HML_STATUS_TS: utcnow()
            }
            insert_statement = pg_insert(Hml).returning(Hml.hml_id).values([hml_row])
                 
            result_proxy = session.execute(insert_statement)
        
            # unpack the hml_id from the returned tuple
            hml_entry_id, = result_proxy.first()
        else:
            hml_entry_id, = result
            logger.debug('Updating existing database record for %s', hml_object_key)

            hml_row = {
                const_hml.COLUMN_HML_STATUS: HmlStatusEnum.received,
                const_hml.COLUMN_HML_STATUS_TS: utcnow()
            }
            update_statement = update(Hml).where(Hml.hml_id ==
                                                 hml_entry_id).values(hml_row)
            result_proxy = session.execute(update_statement)

        return hml_entry_id
