import json
import requests
from random import choices

LOCATION_API_TEMPLATE = "http://{{WRDS_HOST}}/api/location/v3.0/metadata/nws_lid/"

def lambda_handler(event, context):
    api_ip_address = event["PrivateIpAddress"]
    location_api_metadata_root = LOCATION_API_TEMPLATE.replace("{{WRDS_HOST}}", api_ip_address)
    
    json_response = requests.get(location_api_metadata_root).json()
    
    assert "nws_lid" in json_response
    nws_lids = json_response["nws_lid"]
    num_nws_lids = len(nws_lids)
    assert num_nws_lids > 0
    
    for nws_lid in choices(json_response["nws_lid"], k=5):
        iter_json_response = requests.get(location_api_metadata_root + nws_lid).json()
        assert "locations" in iter_json_response
        assert len(iter_json_response["locations"]) == 1
        
        location = iter_json_response["locations"][0]
        assert "identifiers" in location
        assert "nws_data" in location
        assert "usgs_data" in location
        assert "nwm_feature_data" in location
        assert "env_can_gage_data" in location
        assert "nws_preferred" in location
        assert "usgs_preferred" in location
        
        
        identifiers = location["identifiers"]
        assert "nws_lid" in identifiers
        assert "usgs_site_code" in identifiers
        assert "nwm_feature_id" in identifiers
        assert "goes_id" in identifiers
        assert "env_can_gage_id" in identifiers
        
        nws_data = location["nws_data"]
        assert "name" in nws_data
        assert "wfo" in nws_data
        assert "rfc" in nws_data
        assert "geo_rfc" in nws_data
        assert "latitude" in nws_data
        assert "longitude" in nws_data
        assert "map_link" in nws_data
        assert "horizontal_datum_name" in nws_data
        assert "state" in nws_data
        assert "county" in nws_data
        assert "county_code" in nws_data
        assert "huc" in nws_data
        assert "hsa" in nws_data
        assert "zero_datum" in nws_data
        assert "vertical_datum_name" in nws_data
        assert "rfc_forecast_point" in nws_data
        assert "rfc_defined_fcst_point" in nws_data
        assert "riverpoint" in nws_data
        
        usgs_data = location["usgs_data"]
        assert "name" in usgs_data
        assert "geo_rfc" in usgs_data
        assert "latitude" in usgs_data
        assert "longitude" in usgs_data
        assert "map_link" in usgs_data
        assert "coord_accuracy_code" in usgs_data
        assert "latlon_datum_name" in usgs_data
        assert "coord_method_code" in usgs_data
        assert "state" in usgs_data
        assert "huc" in usgs_data
        assert "site_type" in usgs_data
        assert "altitude" in usgs_data
        assert "alt_accuracy_code" in usgs_data
        assert "alt_datum_code" in usgs_data
        assert "alt_method_code" in usgs_data
        assert "drainage_area" in usgs_data
        assert "drainage_area_units" in usgs_data
        assert "contrib_drainage_area" in usgs_data
        assert "active" in usgs_data
        assert "gages_ii_reference" in usgs_data
        
        nwm_feature_data = location["nwm_feature_data"]
        assert "downstream_feature_id" in nwm_feature_data
        assert"latitude" in nwm_feature_data
        assert "longitude" in nwm_feature_data
        assert "altitude" in nwm_feature_data
        assert "stream_length" in nwm_feature_data
        assert "stream_order" in nwm_feature_data
        assert "mannings_roughness" in nwm_feature_data
        assert "slope" in nwm_feature_data
        assert "channel_side_slope" in nwm_feature_data
        assert "nhd_waterbody_comid" in nwm_feature_data
        
        env_can_gage_data = location["env_can_gage_data"]
        assert "name" in env_can_gage_data
        assert "latitude" in env_can_gage_data
        assert "longitude" in env_can_gage_data
        assert "map_link" in env_can_gage_data
        assert "drainage_area" in env_can_gage_data
        assert "contrib_drainage_area" in env_can_gage_data
        assert "water_course" in env_can_gage_data
        
        nws_preferred = location["nws_preferred"]
        assert "name" in nws_preferred
        assert "latitude" in nws_preferred
        assert "longitude" in nws_preferred
        assert "latlon_datum_name" in nws_preferred
        assert "state" in nws_preferred
        assert "huc" in nws_preferred
        
        usgs_preferred = location["usgs_preferred"]
        assert "name" in usgs_preferred
        assert "latitude" in usgs_preferred
        assert "longitude" in usgs_preferred
        assert "latlon_datum_name" in usgs_preferred
        assert "state" in usgs_preferred
        assert "huc" in usgs_preferred
        
    return {
        'statusCode': 200,
        'body': json.dumps('Tests passed!')
    }
