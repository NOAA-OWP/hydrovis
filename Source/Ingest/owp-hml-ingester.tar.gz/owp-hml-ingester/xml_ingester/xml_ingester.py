#!/usr/bin/env python3
"""
This script is the entry point for XML ingester that processes the XML messages
received from a RabbitMQ instance. The XML documents come from HML files
produced by RFCs. This application is supposed to continuously run and wait for
messages that RabbitMQ routes to it. The details about the RabbitMQ instance
and target database can be found in ingester.conf file. All environment
variables needed are defined in .env file in the script directory.

For details about usage or command line arguments please use -h option

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/07/2018
"""

# Import system libraries first
import os
import sys

import logging
from optparse import OptionParser, OptionGroup

from xml.etree import ElementTree

from sqlalchemy.exc import SQLAlchemyError

import pika

import json

# local modules imports
from config.config_reader import ConfigReader

from constants import app, conf, log, xml, xml_message

from rabbitmq.rabbitmq import RabbitMQManager

from parser.xml_parser import XMLParser
from parser.hmlexceptions import XMLParseException
from xml.etree.ElementTree import ParseError

from database.db_manager import DBManager
from database.db_model import HmlXmlStatusEnum

# Define logger specific to this application
logger = logging.getLogger( app.NAME )


def setup_logging(conf_log):
    """
    Configures global logger

    This function sets up the application logger by setting its log level,
    target, log format, etc from the information provided in input tuple.
    Note that logger is a global object that other modules reuse.

    Args:
        conf_log: a tuple representing values from log section of conf file

    Returns:
        This function doesn't return anything

    Raises:
        Exception in case log target is not specified in configuration file
    """

    conf_log_level, conf_log_target, conf_log_file = conf_log

    # set log level (don't allow any level higher than INFO)
    if conf_log_level == conf.LOG_DEBUG_LEVEL:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO

    logger.setLevel(log_level)

    # set log target to be a file or stdout
    if conf_log_target == conf.LOG_FILE:

        # default to file name in conf file if log file name is not provided
        if not conf_log_file:
            conf_log_file = log.DEFAULT_FILENAME

        log_handler = logging.FileHandler(conf_log_file)

    elif conf_log_target == conf.LOG_STREAM:
        log_handler = logging.StreamHandler(sys.stdout)

    else:
        raise Exception( "Provided logging target is not valid. Check config." )

    # set log message format
    log_formatter = logging.Formatter(
        fmt=log.DEFAULT_FORMAT,
        datefmt=log.DEFAULT_DATE_FORMAT
        )
    log_handler.setFormatter( log_formatter )
    logger.addHandler( log_handler )

    #logger.info("The logging mechanism has been created.")


def setup_options():
    """
    Configures command line arguments

    Returns:
        A tuple of program options and arguments in that order

    """

    usage_message = app.NAME + " [Options]"
    option_parser = OptionParser(
        usage=usage_message,
        version=app.NAME + " " + app.VERSION,
        description="This application gets XML document from RabbitMQ, parses "\
            "it and saves its contents in a database."
    )

    # path to application configuration file
    dir_path = os.path.dirname( os.path.realpath( __file__ ) ) + "/"
    option_parser.add_option(
        "-c", "--config-file",
        dest="config_file",
        default=dir_path + conf.DEFAULT_CONFIG_FILENAME,
        help="The path to the configuration file. default: ./" + \
            conf.DEFAULT_CONFIG_FILENAME
    )

    return option_parser.parse_args()


def process_forecasts(primary, secondary, db_session):
    """
    Insert parsed forecasts primary and secondary time series in database

    Args:
        primary: primary forecasts time series
        secondary: secondary forecasts time series
        db_session: a sqlalchemy database session object

    Returns:
        Returns True if everything went well else False

    """

    ## insert primary physical element forecasts
    primary_metadata = primary.get_metadata()
    primary_computed_metadata = primary.get_computed_metadata()

    ## there is no need to get standard unit now because for secondary, we do 
    # not know the PE code to get standard unit. Also we are only transforming
    # cfs to KCFS at the moment and there is no conversion expected for stage
    # TODO: Find out a way to get multiplier for given unit to standardize it.
    # standard_unit_primary = DBManager.get_standard_unit_for_pe(
    #     session=db_session,
    #     pe=primary_computed_metadata.parameter_code.physical_element
    #     )
    logger.info(
        "Inserting primary forecasts for gage: {}".format(
            primary.gage_code
            )
        )
    primary_existed, primary_inserted = DBManager.insert_category_forecasts(
        session=db_session,
        metadata=primary_metadata,
        computed_metadata=primary_computed_metadata,
        category_values=primary.metric_values()
    )

    if not primary_existed and not primary_inserted:
        logger.error(
            "Failed to save primary forecasts for gage: {0}".format(
                primary.gage_code
            )
        )
        return False

    ## insert secondary physical element forecasts
    if secondary:

        secondary_metadata = secondary.get_metadata()
        secondary_computed_metadata = secondary.get_computed_metadata()

        logger.info(
            "Inserting secondary forecasts for gage: {}".format(
                secondary.gage_code
                )
            )
        secondary_existed, secondary_inserted = \
            DBManager.insert_category_forecasts(
                session=db_session,
                metadata=secondary_metadata,
                computed_metadata=secondary_computed_metadata,
                category_values=secondary.metric_values()
            )

        if not secondary_existed and not secondary_inserted:
            logger.error(
                "Failed to save secondary forecast data for gage: {0}".format(
                    secondary.gage_code
                )
            )
            return False
    else:

        logging.info(
            "No secondary forecasts for gage: {0}".format(
                primary.gage_code
                )
            )

    return True

def process_xml( db_session, xml_body ):
    """
    This function is RabbitMQ consumer callback. It receives XML document from
    the RabbitMQ, parses and loads its contents in database

    Args:
        channel: channel used for communication
        method: spec.Basic.Deliver
        properties: spec.BasicProperties
        xml_body: XML document as a string
        arguments: additional arguments to this function as dict

    Returns:
        True if both observations and forecasts are processed else false

    Raises:
        XMLParseException: if problem parsing XML
        Exception: if problem processing or saving data
    """

    ## parse and process xml, if failed parsing, log error and return
    try:
        xml_parser = XMLParser(xml_body)
    except ElementTree.ParseError as e:
        raise XMLParseException(str(e))

    # process forecasts
    forecasts = xml_parser.parse_forecasts()
    saved_forecasts = False
    if forecasts:
        primary_forecasts, secondary_forecasts = forecasts
        saved_forecasts = process_forecasts(
            primary=primary_forecasts,
            secondary=secondary_forecasts,
            db_session=db_session
        )

    fcst_processed = (forecasts and saved_forecasts) or not forecasts

    return fcst_processed


def xml_event_handler( channel, method, properties, event, arguments ):
    """
    XML event handler

    This function is RabbitMQ consumer callback. It receives XML document from
    the RabbitMQ, parses and loads its contents in database. It mainly handles
    the accounting of XML parsing and delegates the actual parsing to another
    function 

    Args:
        channel: channel used for communication
        method: spec.Basic.Deliver
        properties: spec.BasicProperties
        event: JSON message with xml, and its attributes
        arguments: additional arguments to this function as dict

    Returns:
        This function returns nothing

    Raises:
        KeyError: if xml_event is missing the desired field
    """

    # whether or not xml is parsed and loaded into database
    xml_processed = False

    # by default process xml later unless it is an xml parse failure in which
    # case requeuing will happen indefinetly
    process_xml_later = True

    # convert xml event message to python dict
    xml_event = json.loads(event.decode('utf-8'))
    hml_db_entry_id = xml_event[ xml_message.HML_ID_FIELD ]
    hml_xml_index = xml_event[ xml_message.XML_INDEX_FIELD ]
    xml_body = xml_event[ xml_message.XML_BODY_FIELD ]

    ## arguments of callback
    # get database session (required)
    db_session,  = arguments

    try:

        # if xml is already processed, send ack to RabbitMQ
        xml_processed = DBManager.is_xml_processed(
            session=db_session, 
            hml_entry_id=hml_db_entry_id,
            xml_index=hml_xml_index
            )

        if xml_processed:
            logger.info(
                "XML with hml id: {} and xml index: {} is already processed".format(
                    hml_db_entry_id,
                    hml_xml_index
                    )
                )
        else:
            logger.info(
                "Processing hml id: {} with xml index: {}".format(
                    hml_db_entry_id,
                    hml_xml_index
                    )
                )

            # update xml entry with parse_begin
            DBManager.update_hml_xml_status( 
                session=db_session, 
                hml_entry_id=hml_db_entry_id, 
                xml_index=hml_xml_index,
                status=HmlXmlStatusEnum.parse_begin
                )

            xml_processed = process_xml( db_session, xml_body )

            # update xml entry with parse_complete
            if xml_processed:

                DBManager.update_hml_xml_status( 
                    session=db_session, 
                    hml_entry_id=hml_db_entry_id, 
                    xml_index=hml_xml_index,
                    status=HmlXmlStatusEnum.parse_complete
                    )

                # mark hml completed if applicable
                DBManager.try_mark_hml_processed(
                    session=db_session,
                    hml_entry_id=hml_db_entry_id
                )
    except (XMLParseException, ElementTree.ParseError) as e:

        logger.exception( str(e) )
        DBManager.update_hml_xml_status( 
            session=db_session, 
            hml_entry_id=hml_db_entry_id, 
            xml_index=hml_xml_index,
            status=HmlXmlStatusEnum.parse_failure
            )

        # mark hml status xml_parse_failure
        DBManager.try_mark_hml_parse_failure(
            session=db_session,
            hml_entry_id=hml_db_entry_id
            )
        process_xml_later = False
    except SQLAlchemyError as e:

        logger.exception( str(e) )

        # try updating the hml_xml row, if it blows up then application can't
        # proceed because it has to do with critical db error like no connection
        DBManager.update_hml_xml_status( 
            session=db_session, 
            hml_entry_id=hml_db_entry_id, 
            xml_index=hml_xml_index,
            status=HmlXmlStatusEnum.db_load_failure
            )
    except Exception as e:

        logger.exception( str(e) )
        DBManager.update_hml_xml_status( 
            session=db_session, 
            hml_entry_id=hml_db_entry_id, 
            xml_index=hml_xml_index,
            status=HmlXmlStatusEnum.post_parse_failure
            )

    if xml_processed :
        channel.basic_ack( delivery_tag=method.delivery_tag )
    else:
        if process_xml_later:

            # it will be requeued in dead-letter-exchange so don't requeue in 
            # same xml queue.
            channel.basic_nack( delivery_tag=method.delivery_tag, requeue=False )
        else:

            # requeuing will try and fail indefintely in this case so manual
            # intervention needed at some point in future
            channel.basic_ack( delivery_tag=method.delivery_tag )

    logger.info("Waiting for xml events from RabbitMQ. To exit press CTRL+C")

if __name__ == '__main__':
    """
    This is the entry point for HML's XML ingester.

    Set up command line options and read configuration from config file. Finally
    connect to RabbitMQ instance and start consuming XML messages or wait till
    one is available.
    """

    # parse command line options and arguments
    (options, args) = setup_options()
    #print("Options: ", options)
    #print("Arguments: ", args)

    # parse config params
    try:
        config_reader = ConfigReader(options.config_file)
        conf_rabbitmq, conf_db, conf_log = config_reader.read_configs()
    except Exception as e:
        print("Error: ", str(e))
        sys.exit(1)

    # setup logging (depends on configurations)
    try:
        setup_logging(conf_log)
    except Exception as e:
        print("Error: ", str(e))
        sys.exit(1)

    logger.info( "Config file: {0}".format(options.config_file) )

    rmq_url, rmq_exchange, conf_xml = conf_rabbitmq
    db_connection_string, = conf_db

    # keep rabbitmq and database connection alive during lifetime of application
    xml_queue, xml_prefetch_count, xml_message_ttl = conf_xml

    rmq_manager = RabbitMQManager( rmq_url )
    rmq_manager.setup(rmq_exchange, xml_queue, xml_message_ttl)

    with DBManager(db_connection_string) as db_session:

        with rmq_manager.get_channel(xml_prefetch_count) as rmq_channel:

            # application session to database (required)
            arguments = (db_session, )

            rmq_channel.basic_consume(queue=xml_queue, on_message_callback=
                lambda channel, method, properties, xml_body: xml_event_handler( 
                    channel, method, properties, xml_body, arguments
                    )
                )

            logger.info("Waiting for xml events from RabbitMQ. To exit press CTRL+C")
            rmq_channel.start_consuming()

    # Application should not reach here
    sys.exit(1)

