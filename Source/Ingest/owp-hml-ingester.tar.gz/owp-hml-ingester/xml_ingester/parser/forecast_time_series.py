"""
This class holds forecast time series and relevant details

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

# Import Python libraries first
from dateutil import parser
import logging

# Import third party libraries

# Import local modules
from parser.time_series import TimeSeries
from parser.metadata import ForecastMetaData, ComputedMetaData
from parser.parameter_code import ParameterCode

from constants.database import const_unit, const_metric_value, \
    const_forecast_member_metric
from constants import app, xml
from constants import time_value as const_time_value

from parser.hmlexceptions import MultipleTimeStepError

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class ForecastTimeSeries(TimeSeries):
    """
    This class store information specifically for a physical element forecast
    time series.
    """

    def __init__(self, generation_time, issued_time, gage_info, physical_element, time_value_list):
        """
        Sort incoming time value pair list with respect to time

        Args:
            generation_time: The time of observation/forecast generation
            issued_time: the time when forecast was issued to public
            gage_info: a tuple of lid, gage long name, and WFO
            physical_element: a tuple of name, units, PEDTS code and category
            time_values_list: A list of TimeValuesPair instances

        Raises:
            Exception: 
                * if any of name, units, category are missing
                * if empty time value pair list
        """

        super(ForecastTimeSeries, self).__init__(
            generation_time=generation_time,
            gage_info=gage_info,
            physical_element=physical_element,
            time_value_list=time_value_list
        )

        ## @issued_time
        # time the product was issued
        try:
            self.issued_time = parser.parse(issued_time)
        except ValueError:
            logging.error(
                "Issued time '{0}' can't be parsed to python datetime".format( 
                    issued_time
                )
            )
            raise

    def __repr__(self):
        """
        string representation of forecast time series
        """

        return "<ForecastTimeSeries( generation_time: {}, issued_time: {}"\
            "wfo:{}, gage: {}, category: {}, name: {} )>"\
            .format(
                self.generation_time,
                self.issued_time,
                self.wfo,
                self.gage_code,
                self.category,
                self.name
            )

    def get_metadata(self):
        """
        Return provided information about time series from HML

        This method only returns the time series information found in the 
        attributes of a observed/forecast tag like primary name, units etc

        Args:
            This is a getter method so doesn't accept any arguments

        Returns:
            A tuple containing series info like  
        """

        return ForecastMetaData(
            generation_time=self.generation_time,
            wfo=self.wfo,
            gage_code=self.gage_code,
            gage_name=self.gage_name,
            name=self.name,
            units=self.units,
            category=self.category,
            pedts=self.pedts,
            issued_time=self.issued_time
        )

    def get_computed_metadata(self):
        """
        Get computed metadata about the time series

        Args:
            This function doesn't take any arguments

        Returns:
            An instance of ComputedMetaData class for the time series
        """

        # make sure valid category
        if self.category == xml.TAG_PRIMARY:
            priority = const_forecast_member_metric.CONST_PRIORITY_PRIMARY
        else:
            priority = const_forecast_member_metric.CONST_PRIORITY_SECONDARY

        return ComputedMetaData(
            step_count=self.step_count,
            start_time=self.start_time,
            priority=priority,
            parameter_code=ParameterCode(self.pedts)
        )

