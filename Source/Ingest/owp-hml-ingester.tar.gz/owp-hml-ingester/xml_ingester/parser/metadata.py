"""
This class stores all metadata about a category

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/15/2017
"""

# Import Python libraries first

# Import third party libraries

# Import local modules


class MetaData(object):
    """
    The class that holds meta data about a time series. 
    
    The elements of this meta data are collected by corresponding TimeSeries
    instance and store in MetaData class temporarily for ease of access and 
    moving around.
    """

    def __init__(self, generation_time, wfo, gage_code, gage_name, name, units, category, pedts=None):
        """
        Store metadata about a time series
        """

        self.generation_time = generation_time

        self.wfo = wfo
        self.gage_code = gage_code
        self.gage_name = gage_name

        self.name = name
        self.units = units

        self.category = category
        self.pedts = pedts

    def __eq__(self, other):
        """
        Metadata object comparator

        This function is automatically called when two objects of type Metadata
        are compared using == sign
        """

        return (
            self.generation_time,
            self.wfo,
            self.gage_code,
            self.gage_name,
            self.name,
            self.units,
            self.category,
            self.pedts
        ) == (
            other.generation_time,
            other.wfo,
            other.gage_code,
            other.gage_name,
            other.name,
            other.units,
            other.category,
            other.pedts
        )

    def __str__(self):
        """
        String representation of meta data
        """

        return "MetaData<( generated at: %s, wfo: %s, gage: %s, name: %s, " \
            "units: %s, category: %s, pedts: %s )>" % (
                str(self.generation_time),
                self.wfo,
                self.gage_code,
                self.name,
                self.units,
                self.category,
                self.pedts
            )


class ForecastMetaData(MetaData):
    """
    The class that stores meta data about a forecast time series

    It has everything MetaData has and also issued time of the forecast
    """

    def __init__(self, generation_time, wfo, gage_code, gage_name, name, units, category, pedts=None, issued_time=None ):
        """
        Metadata for forecast time series
        """

        super(ForecastMetaData, self).__init__(
            generation_time=generation_time,
            wfo=wfo,
            gage_code=gage_code,
            gage_name=gage_name,
            name=name,
            units=units,
            category=category,
            pedts=pedts
        )

        # issued time for the forecast time series
        self.issued_time = issued_time

    def __str__(self):
        """
        String representation of meta data
        """

        return "ForecastMetaData<( generated at: %s, wfo: %s, gage: %s, gage name: %s "\
            "issued at: %s, name: %s, units: %s, " \
            " category: %s, pedts: %s )>" % (
                str(self.generation_time),
                self.wfo,
                self.gage_code,
                self.gage_name,
                self.issued_time,
                self.name,
                self.units,
                self.category,
                self.pedts
            )


class ComputedMetaData(object):
    """
    This class stores the computed meta data about a time series
    """

    def __init__(self, step_count, start_time, priority, parameter_code):

        self.step_count = step_count

        self.start_time = start_time
        self.priority = priority

        self.parameter_code = parameter_code

    def __str__(self):
        """
        String representation of computed metadata
        """

        return "ComputedMetaData<( start_time: %s, "\
            "step count: %s, priority: %s, parameter_codes: %s)>" % (
                str(self.start_time),
                str(self.step_count),
                str(self.priority),
                str(self.parameter_code)
            )
