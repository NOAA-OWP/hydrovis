"""
This class models a list of TimeValuesPair each storing a datum's contents.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/18/2017
"""

# Import Python libraries first
from dateutil import parser
import logging

# Import third party libraries

# Import local modules
from parser.metadata import MetaData
from parser.hmlexceptions import TimeSeriesMissingAttrib

from constants import app, xml
from constants import time_value as const_time_value
from constants.database import const_unit

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class TimeSeries(object):
    """
    This class stores information about the time series for one physical
    element. The metadata contains information like name, units, category, pedts
    etc. 
    """

    CFS_PER_KCFS = 1000

    def __init__(self, generation_time, gage_info, physical_element, time_value_list):
        """
        Sort incoming time value pair list with respect to time.

        Args:
            generation_time: The time of observation/forecast generation
            gage_info: a tuple of lid, gage long name, and WFO
            physical_element: a tuple of name, units, PEDTS code and category
            time_values_list: A list of TimeValuesPair instances

        Raises:
            Exception: 
                * if any of name, units, category are missing
                * if empty time value pair list
        """

        gage_code, gage_name, wfo = gage_info
        name, units, pedts, category = physical_element

        # generation time
        try:
            self.generation_time = parser.parse(generation_time)
        except ValueError:
            logging.error(
                "Generation time '{0}' can't be parsed to python datetime".format( 
                    generation_time
                )
            )
            raise

        # wfo name
        if not wfo:
            raise TimeSeriesMissingAttrib(
                "You must provide wfo name to create the time series"
                )
        self.wfo = wfo

        # gage code
        if not gage_code:
            raise TimeSeriesMissingAttrib(
                "You must provide gage code to create the time series"
                )
        self.gage_code = gage_code

        # gage name
        self.gage_name = gage_name

        # name of physical element
        if not name:
            raise TimeSeriesMissingAttrib(
                "You must provide name of physical element for the time series"
                )
        self.name = name.lower()

        # units of value in this time series. SHEF manual keeps units in the
        # upper case letters and so does our database.
        if not units:
            raise TimeSeriesMissingAttrib(
                "You must provide units of physical element for the time series"
                )
        self.units = units.upper()

        # category of physical element
        if not category:
            raise TimeSeriesMissingAttrib(
                "You must provide units of physical element for the time series"
                )
        self.category = category

        # pedts if time series for primary element
        self.pedts = pedts
        if not self.pedts and self.category == xml.TAG_PRIMARY:
            raise TimeSeriesMissingAttrib(
                "A primary time series must have paramter codes"
                )

        if not time_value_list:
            raise TimeSeriesMissingAttrib(
                "For wfo: {0}, gage: {1}: time series must have at least "\
                "one element".format(self.wfo, self.gage_code)
                )

        # sort the time series
        try:
            sorted_time_value_list = sorted(
                time_value_list,
                key=lambda time_value_pair: time_value_pair.valid_time
            )
        except (TypeError, AttributeError) as error:
            logging.error( str(error) )
            raise

        # get rid of repeated times ( bug in HML files for observation data )
        self.time_value_list = TimeSeries.uniqify( sorted_time_value_list )

        # start time of time series
        self.start_time = self.time_value_list[0].valid_time

        # number of elements in time series
        self.step_count = len(self.time_value_list)

        # standardize units
        self.standardize_units()

    @staticmethod
    def uniqify( time_value_pair_list ):
        """
        Remove time value pairs with duplicate valid time from time series

        The function removes the duplicates from a sorted list while maintaining
        the order of values. A key value pair is called duplicate if two or more
        pairs exist with the same valid time. The value comparison is never done
        since it is meaningless as we cannot store two time value pair with
        same valid times due to the reasons like which one is right etc. Solution
        is adopted from the following stackoverflow answer: 
        https://stackoverflow.com/questions/480214

        Args:
            An ordered list of time value pairs
        
        Returns:
            An orderd list of time value pairs with duplicates removed
        """

        seen = set()
        # to avoid runtime resolving add function in each iteration
        seen_add = seen.add 
        return [ x for x in time_value_pair_list \
            if not (x.valid_time in seen or seen_add(x.valid_time))
            ]

    def __eq__(self, other):
        """
        Tests equality of two instances of Time Series

        This method is called when two instances of TimeSeries are compared using
        the == sign.
        """

        return self.__dict__ == other.__dict__

    def __repr__(self):
        """
        string representation of time series
        """

        return "<TimeSeries( generation_time: {0}, wfo:{1}, gage: {2}, category: {3}, name: {4} )>"\
            .format(
                self.generation_time,
                self.wfo,
                self.gage_code,
                self.category,
                self.name
            )

    def get_metadata(self):
        """
        Return provided information about time series from HML

        This method only returns the time series information found in the 
        attributes of a observed/forecast tag like primary name, units etc

        Args:
            This is a getter method so doesn't accept any arguments

        Returns:
            An instance of MetaData class containing information  
        """

        return MetaData(
            generation_time=self.generation_time,
            wfo=self.wfo,
            gage_code=self.gage_code,
            gage_name=self.gage_name,
            name=self.name,
            units=self.units,
            category=self.category,
            pedts=self.pedts
        )

    def standardize_units(self):
        """
        Transform units to standard units for physical element as in SHEF manual

        For now, this function doesn't retrieve any unit multiplier from database
        to do the unit conversion because there isn't a table with units and
        multipliers yet. So only CFS gets transformed to KCFS. It modifies the
        value in place for each TimeValuePair in instance's time value list.
        """

        changed_units = False
        for time_value_pair in self.time_value_list:

            # change cfs to kcfs if applicable (divide by 1000)
            # if standard_unit == const_unit.UNIT_KCFS and
            if self.units == const_unit.UNIT_CFS:

                time_value_pair.value = \
                    time_value_pair.value / TimeSeries.CFS_PER_KCFS
                changed_units = True

        if changed_units:
            self.units = const_unit.UNIT_KCFS
            logger.info(
                "Flow units were changed from cfs to kcfs for "\
                "gage: {0} ".format(
                    self.gage_code
                    )
                )

        return self.time_value_list

    def metric_values(self):
        """
        Get the list of timeseies values

        Transform the list of TimeValuePair to a list of dictionaries with time
        and value information. This transforamtion is done so we can add more
        fields in a series point and others by overriding this method in order
        to have a consistent format.

        Returns:
            List of dictionaries with time and value information.
        """

        # trasform TimeValuePair list to a list of dictionaries with time and
        # value information.
        metric_values = []
        for time_value_pair in self.time_value_list:

            metric_values.append(
                {
                    const_time_value.VALID_TIME : time_value_pair.valid_time,
                    const_time_value.VALUE : time_value_pair.value
                }
            )

        return metric_values
