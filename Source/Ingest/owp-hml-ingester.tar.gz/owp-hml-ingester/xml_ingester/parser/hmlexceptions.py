"""
This file defines some exceptions that will be used by HML ingester

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/07/2018
"""

class HMLException(Exception):
    """
    Basic exception raised by HMLIngester
    """
    pass


## XML parsing related exceptions
class XMLParseException(HMLException):
    """
    Basic XML parse exception with reference to HMLIngester
    """
    pass


class TagError(XMLParseException):
    """
    Basic tag related error class
    """
    pass

class TagNotFound(TagError):
    """
    If a tag is not found in a given parent tag
    """
    pass


class IncorrectTag(TagError):
    """
    If tag name is not the one we are looking for
    """
    pass


class IncorrectValue(TagError):
    """
    If value of a tag is invalid
    """
    pass


class TimeStepError(XMLParseException):
    """
    Time step error
    """
    pass


class MultipleTimeStepError(TimeStepError):
    """
    More than one time step in forecast
    """
    pass


class TimeSeriesMissingAttrib(XMLParseException):
    """
    If any compulsory attribute of time series is missing
    """
    pass


## Database saving observations/foreacasts related issues
class DBLoadException(HMLException):
    """
    Basic exception for issues saving data to database
    """
    pass



