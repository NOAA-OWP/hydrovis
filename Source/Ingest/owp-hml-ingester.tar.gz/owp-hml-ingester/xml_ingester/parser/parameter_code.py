"""
This class stores PEDTS SHEF codes

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 18/12/2017
"""

# Import Python libraries first

# Import third party libraries

# Import local modules
from constants import xml

class ParameterCode(object):
    """
    This class is used to store and transform parameter codes
    """

    def __init__(self, pedts):
        """
        Stores contents of parameter codes and transform them into JSON/XML

        Each character in pedts string represent a parameter code, most common
        are physical element(2), duration(1), type and source (2) and possibly
        extremum(1) and probability(?)

        Args:
            pedts: parameter code string
        """

        # make sure pedts string is supplied
        if not pedts:
            raise Exception("Parameter codes must have pedts string.")

        # make sure that pedts has length of 5
        pedts_length = len(pedts)
        if pedts_length < 5:
            raise Exception("Parameter code must have a length of at least 5")

        ##
        # name of physical element for data points
        self.physical_element = pedts[0:2]

        ##
        # duration for data points
        self.duration = pedts[2]

        ##
        # type and source of data points
        self.type_source = pedts[3:5]

        # Add extremum and probablity if they exist

        ##
        # extremum value for data points
        self.extremum = xml.DEFAULT_EXTREMUM

        ##
        # probability for data points
        self.probability = xml.DEFAULT_PROBABILITY

        if pedts_length > 5:
            self.extremum = pedts[5]

        if pedts_length > 6:
            self.probability = pedts[6:]

    def __eq__(self, other):
        """
        Compare if two ParameterCode objects have same values

        Returns:
             True or False depending on whether two objects are same or not
        """

        return (
            self.physical_element,
            self.duration,
            self.type_source,
            self.extremum,
            self.probability
            ) == (
            other.physical_element,
            other.duration,
            other.type_source,
            other.extremum,
            other.probability
            )

    def __hash__(self):
        """
        Provide a hash function for ParameterCode to be used as set element

        Returns:
            A tuple hash for members of the ParameterCode instance
        """

        return hash(
            (
                self.physical_element,
                self.duration,
                self.type_source,
                self.extremum,
                self.probability
            )
        )

    def __str__(self):
        """
        The string representation representing pedtsep value for this instance

        Returns:
             A string with all parameter codes in pedtsep order
        """

        return "<ParameterCode( pe: {0}, d: {1}, ts: {2}, e: {3}, p: {4} "\
            ")>".format(
                self.physical_element,
                self.duration,
                self.type_source,
                "" if self.extremum is None else self.extremum,
                "" if self.probability is None else self.probability
            )


