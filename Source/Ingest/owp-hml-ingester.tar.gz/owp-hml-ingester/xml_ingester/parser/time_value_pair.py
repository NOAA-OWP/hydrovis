"""
This class stores a time and a value pair

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/09/2017
"""

# Import Python libraries first
import logging
from dateutil import parser
# Import third party libraries

# Import local modules
from constants import app

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class TimeValuePair(object):
    """
    This class saves a time value pair. The value may be for any physical
    element.
    """

    def __init__(self, valid_time, value):
        """
        Initialize an object of this class

        Args:
            valid_time: the valid time of observation/forecast
            value: floating value of physical element at that time

        Raises:
            Exception: if valid_time is is not parseable
        """

        # validate valid time
        try:
            self.valid_time = parser.parse(valid_time)
        except ValueError:
            logger.error(
                "Valid time '{0}' can't be parsed.".format( valid_time )
                )
            raise

        # value of physical element has to be floating point with double 
        # precision. Note python float is C's double
        try:
            self.value = float( value )
        except ValueError:
            logger.error(
                "Value {0} in time series can't be casted to float".format(value)
                )
            raise

    def __eq__(self, other):
        """
        Add logic for two TimeValuePair objects equality

        This function automatically gets invoked when two objects of type
        TimeValuePair are compared using == operator.
        """

        return (
            self.valid_time,
            self.value
        ) == (
            other.valid_time,
            other.value
        )

    def __repr__(self):
        """
        String representation of time value pair
        """

        return "<TimeValuePair( time: {0}, value: {1})>".format(
            str(self.valid_time),
            self.value
        )
