"""
This script is used to download, parse XML AHPS data from a URL and
insert observations and forecast values to a postgresql database. The script
assumes that we have postgresql 9.5 installed in order to use upsert operation.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service # Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/02/2017
"""

# import System libraries
import logging
from xml.etree import ElementTree

# import local modules
from parser.hmlexceptions import TagNotFound, IncorrectTag
from constants import app, xml
from parser.time_value_pair import TimeValuePair
from parser.time_series import TimeSeries
from parser.forecast_time_series import ForecastTimeSeries
from parser.hmlexceptions import XMLParseException, TagError, \
    TagNotFound, IncorrectTag, IncorrectValue

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class XMLParser(object):
    """
    This class parses the XML observation/forecast from string
    """

    def __init__(self, xml_string):
        """
        Initializes an instance of class

        Args:
            xml_string: a string containing an XML document

        Raises:
            ElementTree.ParseError: malformed xml
        """

        # read xml root tage site from string
        try:
            self.xml_root_node = ElementTree.fromstring( xml_string )
        except ElementTree.ParseError:
            logger.error( "Malformed XML document found" )
            raise

        # get originator WFO
        self.wfo = self.xml_root_node.get(xml.ATTRIB_ORIGINATOR)

        # get gage identifier or lid
        self.gage_code = self.xml_root_node.get(xml.ATTRIB_ID)

        # get gage long name
        self.gage_name = self.xml_root_node.get(xml.ATTRIB_NAME)

        logger.info( "Parsing XML from wfo: {0}, gage: {1}".format(
                self.wfo, 
                self.gage_code 
                )
            )

        # get generation time
        self.generation_time = self.xml_root_node.get( xml.ATTRIB_GENERATION_TIME ).strip()
        if not self.generation_time:
            raise Exception(
                "Forecast generation time is empty for gage: %s" % self.gage_code 
                )

    @staticmethod
    def get_child_node_with_name(node, child_name):
        """
        Get direct child for the specified name

        Return a direct child with specified name for the given XML node.

        Args:
            node: XML dom node to search for children
            child_name: Name of the direct child to search

        Returns:
            The requested child node or None if arguments are incorrect or
            node not found
        """

        # cannot find child if node is None
        if node is None:
            raise Exception( "Can't find child: '{0}' in tag: '{1}'".format(
                    child_name,
                    node
                    )
                )

        # cannot find child if child_name is not provided
        stripped_child_name = child_name.strip()
        if not stripped_child_name:
            raise Exception( "Can't find child: '{0}' in tag: '{1}'".format(
                    child_name,
                    node
                    )
                )

        # make sure that node is iterable
        try:
            iter_node = iter(node)
        except TypeError:
            logger.exception(
                "Node : " + str(node) + " is not iterable."
                )
            raise
        else:
            for child in iter_node:
                if child.tag == stripped_child_name:
                    return child
            else:
                raise TagNotFound(
                    "Could not find child: '{0}' in tag: '{1}'".format(
                        child_name,
                        node.tag
                        )
                    )

    @staticmethod
    def unmarshall_valid_time(valid_node):
        """
        This function converts xml valid node to a ValidTime instance
        example: <valid>2018-02-02T18:00:00-00:00</valid>

        Args:
            valid_node: XML node for valid tag

        Returns:
            An instance of ValidTime

        Raises:
            ValueError: if valid time is not parseable
            Exception:
                * if valid_node is None
                * if valid_node is is not the right tag
                * if valid node text is empty
        """

        # if invalid node
        if valid_node is None:
            raise TagNotFound("XML valid time node is None")

        # make sure that we have a valid tag
        valid_node_tag = valid_node.tag
        if valid_node_tag != xml.TAG_VALID:
            raise IncorrectTag("XML valid node has wrong tag: " + valid_node_tag)

        # if empty text value
        valid_time = valid_node.text.strip()
        if not valid_time:
            raise IncorrectValue( "Valid time can't be empty or none." )

        return valid_time

    @staticmethod
    def unmarshall_datum(datum_node):
        """
        Parse datum tag to primary and secondary time value pairs

        The datum tag contains a valid timestamp in UTC format, primary tag
        with stage/flow value and a secondary tag with flow/stage value.

        Args:
             datum_node: XML node for datum tag

        Returns:
            A tuple of primary and secondary TimeValuePairs

        Raises:
            TagNotFound:
                * if not a datum tag
            IncorrectTag:
                * if incoming node's tag is not a datum tag
        """

        # if node is None
        if datum_node is None:
            raise TagNotFound("Incoming datum node is None")

        # make sure we got a datum node
        datum_tag = datum_node.tag
        if datum_tag != xml.TAG_DATUM:
            raise IncorrectTag("Incoming datum node has wrong tag: " + datum_tag)

        # parse valid tag
        valid_time_node = datum_node.find(xml.TAG_VALID)
        valid_time = XMLParser.unmarshall_valid_time(valid_time_node)

        # parse primary tag
        primary_node = datum_node.find(xml.TAG_PRIMARY)
        if primary_node is None:
            raise TagNotFound("Unable to find " + xml.TAG_PRIMARY + " tag in '" +
                              str(ElementTree.tostring(datum_node)) + "'")
        primary_value = primary_node.text.strip()

        # primary TimeValuePair
        primary_pair = TimeValuePair( valid_time=valid_time, value=primary_value )

        # parse secondary tag
        secondary_node = datum_node.find(xml.TAG_SECONDARY)
        
        secondary_pair = None
        if secondary_node is not None:
            
            secondary_value = secondary_node.text.strip()

            # secondary TimeValuePair
            secondary_pair = TimeValuePair( valid_time=valid_time, value=secondary_value )

        return ( primary_pair, secondary_pair )

    @staticmethod
    def parse_datums(node):
        """
        Parse datums into lists of TimeValuePair for primary and secondary 

        Args:
             node: observation or forecast XML node
        Returns:
            Two TimeValuePair lists one for each of primary and secondary
            None:
                * if node doesn't exist or
                * if node tag is neither observed nor forecast
                * if node is not iterable
        Raises:
            XMLParseException: if problem parsing any datum
        """

        # can't proceed if not a valid node
        if node is None:
            return None

        node_tag = node.tag
        if node_tag not in [xml.TAG_OBSERVED, xml.TAG_FORECAST]:
            logger.warning(node_tag + " is not a valid tag for datums")
            return None

        # parse datums
        primary_time_value_pairs = None
        secondary_time_value_pairs = None
        try:
            node_iter = iter(node)
        except TypeError as type_error:
            logger.warning(str(type_error))
            return None
        else:
            for datum_node in node_iter:
                primary_pair, secondary_pair = \
                    XMLParser.unmarshall_datum(datum_node)

                # before adding first item, instantiate list
                if primary_time_value_pairs is None:
                    primary_time_value_pairs = []
                primary_time_value_pairs.append(primary_pair)

                # before adding first item, instantiate list
                if secondary_pair is not None:
                    if secondary_time_value_pairs is None:
                        secondary_time_value_pairs = []
                    secondary_time_value_pairs.append(secondary_pair)

        return ( primary_time_value_pairs, secondary_time_value_pairs )

    @staticmethod
    def get_secondary_pedts( primary_pedts, secondary_name ):
        """
        Derive secondary pedts from primary pedts

        Since HML files do not provide PEDTS string for secondary physical
        element, we chose to set secondary PE code to be HG if it was stage and
        QR if it was flow. The rest of DTS string remains same as for primary

        Args:
            primary_pedts: The PEDTS string for primary physical element

        Returns:
            The PEDTS string for secondary physical element
        """

        # Hardcoded exception until source data is fixed
        if primary_pedts[0:2] == 'HP':
            pe = xml.DEFAULT_STORAGE_PE
        elif secondary_name == xml.STAGE:
            pe = xml.DEFAULT_STAGE_PE
        elif secondary_name == xml.FLOW:
            pe = xml.DEFAULT_FLOW_PE
        elif secondary_name == xml.STORAGE:
            pe = xml.DEFAULT_STORAGE_PE
        else:
            raise XMLParseException(
                "Secondary name MUST be either stage or flow or storage"
                )

        # return PE code concatenated with DTS characters from primary pedts
        return "{0}{1}".format( pe, primary_pedts[2:] )

    def parse_observations(self):
        """
        Parse contents of observed tag to primary/secondary time series

        This function parses datums tags in observed tag and constructs a
        time series for primary and secondary tags each.

        Args:
            This function doesn't take any arguments

        Returns:
            A list of parsed datums
            None:
                * if observed tag has no data or
                * if there was error parsing time series

        Raises:
            Exception: if observed tag is not found in root node
            XMLParseException: if problem parsing any datum
        """

        # get observation tag node
        try:
            observed_node = XMLParser.get_child_node_with_name(
                self.xml_root_node,
                xml.TAG_OBSERVED
                )
        except TagNotFound:
            logger.info("No observations for gage: %s" % self.gage_code)
            return None

        ## get observed tag attributes
        # get primary name, units, pedts
        primary_name = observed_node.get( xml.ATTRIB_PRIMARY_NAME ).strip().lower()
        primary_units = observed_node.get( xml.ATTRIB_PRIMARY_UNITS ).strip().lower()
        primary_pedts = observed_node.get( xml.ATTRIB_PEDTS ).strip()

        # parse datums into two lists of TimeValuePair
        primary_datums, secondary_datums = XMLParser.parse_datums(
            observed_node
            )

        # primary time-series
        primary_timeseries = TimeSeries(
            generation_time=self.generation_time,
            gage_info=( self.gage_code, self.gage_name, self.wfo ),
            physical_element=(
                primary_name,
                primary_units,
                primary_pedts,
                xml.TAG_PRIMARY
                ),
            time_value_list=primary_datums
            )
        logger.info( str(primary_timeseries) )

        # secondary time-series
        secondary_timeseries = None
        if secondary_datums is not None:
            
            # get secondary name, units, pedts
            secondary_name = observed_node.get( xml.ATTRIB_SECONDARY_NAME ).strip().lower()
            secondary_units = observed_node.get( xml.ATTRIB_SECONDARY_UNITS ).strip().lower()
            secondary_pedts = XMLParser.get_secondary_pedts(
                primary_pedts, 
                secondary_name
                )

            secondary_timeseries = TimeSeries(
                generation_time=self.generation_time,
                gage_info=( self.gage_code, self.gage_name, self.wfo ),
                physical_element=(
                    secondary_name,
                    secondary_units,
                    secondary_pedts,
                    xml.TAG_SECONDARY
                    ),
                time_value_list=secondary_datums
                )
            logger.info( str(secondary_timeseries) )

        return ( primary_timeseries, secondary_timeseries)

    def parse_forecasts(self):
        """
        Parse contents of forecast tag to primary/secondary time series

        This function parses datums tags in forecast tag and constructs a
        time series for primary and secondary tags each.

        Args:
            This function doesn't take any arguments

        Returns:
            A list of parsed datums
            None:
                * if forecast tag has no data or
                * if there was error parsing time series

        Raises:
            Exception: if forecast tag is not found in root node
            XMLParseException: if problem parsing a datum
        """

        # get forecast tag node
        try:
            forecast_node = XMLParser.get_child_node_with_name(
                self.xml_root_node,
                xml.TAG_FORECAST
                )
        except TagNotFound:
            logger.info("No forecasts for gage: %s" % self.gage_code)
            return None

        ## get forecast tag attributes

        # get issued time
        issued_time = forecast_node.get( xml.ATTRIB_ISSUED ).strip().lower()
        if not issued_time:
            raise Exception(
                "Forecast issued time is empty for gage: %s" % self.gage_code 
                )

        # get primary name, units, pedts
        primary_name = forecast_node.get( xml.ATTRIB_PRIMARY_NAME ).strip().lower()
        primary_units = forecast_node.get( xml.ATTRIB_PRIMARY_UNITS ).strip().lower()
        primary_pedts = forecast_node.get( xml.ATTRIB_PEDTS ).strip()

        # parse datums into two lists of TimeValuePair
        primary_datums, secondary_datums = XMLParser.parse_datums(
            forecast_node
            )

        # primary time-series
        primary_timeseries = ForecastTimeSeries(
            generation_time=self.generation_time,
            issued_time=issued_time,
            gage_info=( self.gage_code, self.gage_name, self.wfo ),
            physical_element=(
                primary_name,
                primary_units,
                primary_pedts,
                xml.TAG_PRIMARY
                ),
            time_value_list=primary_datums
            )
        logger.info( str(primary_timeseries) )

        # secondary time-series
        secondary_timeseries = None
        if secondary_datums is not None:
            
            # get secondary name, units, pedts
            secondary_name = forecast_node.get( xml.ATTRIB_SECONDARY_NAME ).strip().lower()
            secondary_units = forecast_node.get( xml.ATTRIB_SECONDARY_UNITS ).strip().lower()
            secondary_pedts = XMLParser.get_secondary_pedts(
                primary_pedts,
                secondary_name
                )

            secondary_timeseries = ForecastTimeSeries(
                generation_time=self.generation_time,
                issued_time=issued_time,
                gage_info=( self.gage_code, self.gage_name, self.wfo ),
                physical_element=(
                    secondary_name,
                    secondary_units,
                    secondary_pedts,
                    xml.TAG_SECONDARY
                    ),
                time_value_list=secondary_datums
                )
            logger.info( str(secondary_timeseries) )

        return ( primary_timeseries, secondary_timeseries)
