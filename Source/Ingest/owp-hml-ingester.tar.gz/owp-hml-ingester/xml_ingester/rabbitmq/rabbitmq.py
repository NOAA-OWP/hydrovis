"""
This class is used to hold the hml file object. It also provides the methods to
parse XML documents from HML using an iterator.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 05/04/2018
"""

# Import system libraries
import os
import sys
import logging
import pika

# module imports
from constants import app

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class RabbitMQManager(object):
    """ 
    This class creates and manages channels to RabbitMQ 
    
    The goal is to use the same connection but multiple channels to connect to
    different queues and possibly exchanges.
    """

    MILLISECONDS_PER_SECOND = 1000

    def __init__(self, rmq_url):
        """
        Initialize an instance of class

        Args:
            rmq_url: the connection url for RabbitMQ instance. For format please
                see the configuration file.
        """

        # the connection URL to RabbitMQ
        self.rmq_url = rmq_url

        # connection object to RabbitMQ instance
        self.connection = None

    def __del__(self):
        """
        Destroy an instance of class

        """

        # Close any open connections
        if self.connection:
            self.connection.close()

    def get_connection(self):
        """
        Get a connection object to RabbitMQ

        Returns:
            A blocking connection to RabbitMQ instance identified by rmq_url
        
        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        try:
            return pika.BlockingConnection(
                pika.URLParameters(url=self.rmq_url)
            )
        except pika.exceptions.ConnectionClosed:
            logger.error("Connection refused, probably no RabbitMQ server running")
            raise

    def setup(self, exchange, xml_queue, xml_message_ttl):
        """
        This functions sets up the xml exchange and queue if needed

        The function creates an xml exchange, a dead-letter hml exchange, an xml
        queue and a dead-letter xml queue. 

        Args:
            exchange: name of RabbitMQ exchange to establish channel with
            xml_queue: name of xml events queue
            xml_message_ttl: the time to live for xml messages in dead-letter-queue
        
        Returns:
            True if setup was successful else raises exceptions below

        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        # create a connection to RabbitMQ, if not existing
        if not self.connection:
            self.connection = self.get_connection()

        # create a channel over connection
        rmq_channel = self.connection.channel()

        # create or use a direct exchange and a dead letter exchange
        rmq_channel.exchange_declare( exchange=exchange, durable=True )

        dead_letter_exchange = "dl.{}".format( exchange )
        rmq_channel.exchange_declare( 
            exchange=dead_letter_exchange,
            durable=True
            )

        ## XML queue
        dead_letter_xml_queue = "dl_{}".format( xml_queue )

        # create or use an xml queue and bind it to exchange
        rmq_channel.queue_declare(
            queue=xml_queue,
            durable=True,
            arguments={
                "x-dead-letter-exchange" : dead_letter_exchange,
                "x-dead-letter-routing-key" : dead_letter_xml_queue
                }
            )
        rmq_channel.queue_bind( exchange=exchange, queue=xml_queue )

        # create a dead letter queue for xml queue
        rmq_channel.queue_declare(
            queue=dead_letter_xml_queue,
            durable=True,
            arguments={
                "x-message-ttl" : \
                    xml_message_ttl * RabbitMQManager.MILLISECONDS_PER_SECOND,
                "x-dead-letter-exchange" : exchange,
                "x-dead-letter-routing-key" : xml_queue
                }
            )
        rmq_channel.queue_bind(
            exchange=dead_letter_exchange,
            queue=dead_letter_xml_queue
            )

        rmq_channel.close()

        return True

    def get_channel(self, prefetch_count):
        """
        This function creates a channel object to an exchange

        The function creates a channel to RabbitMQ and sets the prefetch count
        on that channel.

        Args:
            prefetch_count: The max number of unack-ed messages it can receive

        Returns:
            A channel object to send/receive messages to RabbitMQ

        Raises:
            pika.exceptions.ConnectionClosed: if no RabbitMQ server running
        """

        # create a connection to RabbitMQ, if not existing
        if not self.connection:
            self.connection = self.get_connection()

        # create a channel over connection
        rmq_channel = self.connection.channel()

        rmq_channel.basic_qos(prefetch_count=prefetch_count)

        return rmq_channel
