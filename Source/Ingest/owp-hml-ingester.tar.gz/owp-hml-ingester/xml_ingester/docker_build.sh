# This is only used if docker-compose is not available
sudo docker build -t wrds_xml_ingester:latest -f Dockerfile .
