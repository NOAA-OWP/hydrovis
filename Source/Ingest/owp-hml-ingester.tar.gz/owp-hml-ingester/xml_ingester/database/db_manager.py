"""
This class is used to manage database related operations

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

#  Import System libraries
import logging
import datetime
from datetime import timedelta

# ORM
from sqlalchemy import create_engine, asc, func
from sqlalchemy.orm import sessionmaker

from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import insert as pg_insert

from sqlalchemy.sql.expression import update, select, and_, or_, exists

from sqlalchemy.exc import DatabaseError, OperationalError, IntegrityError
from sqlalchemy.orm.exc import NoResultFound

from sqlalchemy.pool import QueuePool

# module imports
from parser.parameter_code import ParameterCode
from database.db_model import utcnow,\
    Entity, Unit, Station, PhysicalElement, ForecastValues, \
    ForecastValuesLatest, HmlXmlStatusEnum, HmlXml, Hml, HmlStatusEnum
from constants import xml, app
from constants import time_value as const_time_value
from constants.database import const_forecast_values, \
    const_forecast_values_latest, const_entity, \
    const_station, const_hml_xml

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class DBManager(object):
    """
    This class is used to manage database related operations
    """

    def __init__(self, connection_string):
        """
        Initialize sqlalchemy engine and create a session

        The session scope is application wide and transaction scopes are limited
        to the functions. The session is closed in class destructor.

        Args:
            connection_string: The connection string to database of interest
        Returns:
            nothing
        Raises:
            NoSuchModuleError: If database doesn't exist
            OperationalError: if connection string is invalid like domain name,
            username, email etc.
        """

        ## @var engine
        # connection string to database
        # Note that setting isolation level to AUTOCOMMIT means that all of the
        # sql transactions will commit automatically, if more than one
        # sql queries need to be committed/rolledback together, we need to do
        # something special as mentioned in the following article:
        # http://oddbird.net/2014/06/14/sqlalchemy-postgres-autocommit/
        try:
            self.engine = create_engine(
                connection_string,
                pool_size=1,
                max_overflow=0,
                poolclass=QueuePool,
                isolation_level='AUTOCOMMIT',
                echo=False
                )
        except DatabaseError as db_error:
            logger.error(str(db_error))
            raise

        ## @var sessionmaker
        # settings for database sessions factory method
        self.session_maker = sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            autocommit=True
            )

    def __enter__(self):
        """
        Get a db session

        Args:
             nothing
        Returns:
            an instance of Session bound to the sqlalchemy engine
        """

        logger.debug( "Opening the database session" )
        self.session = self.session_maker()
        return self.session

    def __exit__(self, *args):
        """
        Close the db session
        """

        logger.debug("Closing the database session")
        self.session.close()

    @staticmethod
    def compile_query(query):
        """
        Get a string version of the query

        Args:
            query: the query object standalone or related to session
        Returns:
            String version of the query
        """

        compiler = query.compile \
            if not hasattr(query, 'statement') \
            else query.statement.compile
        return compiler(dialect=postgresql.dialect())

    @staticmethod
    def upsert_rows(
            session,
            model_name,
            rows,
            index_elements,
            no_update_cols=[]
    ):
        """
        Upsert rows in the given table

        This function performs the upsert operation on the rows of the table
        deduced from the model_name. The upsert operation determines the unique
        -ness of the rows based of the index_elements which can be either a
        string with name of the constrain or a list of unique columns. The
        columns specified in no_update_cols list are not among the columns
        mentioned in the upsert query

        Args:
            session: a sqlalchemy session object for this transaction
            model_name: The name of class representing the db relation
            rows: A list of the rows with values to insert
            index_elements: The uniqueness constraint
            no_update_cols: A list of the columns not to be updated
        Returns:
            True if upsert was successful, False otherwise
        """

        # get table object from model name
        try:
            table = model_name.__table__
        except NameError as name_error:
            logger.exception(str(name_error))
            return False
        except AttributeError as attrib_error:
            logger.exception(str(attrib_error))
            return False

        upsert_status = False

        try:
            all_cols = [ c.name for c in table.c ]
            index_cols = [c.name for c in table.primary_key.columns]
            update_cols = [
                c.name for c in table.c
                if c not in list(table.primary_key.columns) and
                   c.name not in no_update_cols
            ]

            # The following should be used if table partitioning with rules are not used.

            stmt = pg_insert(table).values(rows)
            on_conflict_stmt = stmt.on_conflict_do_update(
                index_elements=index_elements,
                set_=dict((k, getattr(stmt.excluded, k)) for k in update_cols)
                )

            session.execute(on_conflict_stmt)
            upsert_status = True
        except OperationalError as oper_error:
            logger.exception(str(oper_error))
            raise
        except DatabaseError as err:
            logger.exception(str(err))
            raise

        return upsert_status

    @staticmethod
    def get_or_create(session, model, exclude_in_select=None, **kwargs):
        """
        Get or create a row in database for table specified

        This method is taken from https://stackoverflow.com/questions/2546207

        Args:
            session: current sqlalchemy session to execute this transaction
            model: the DAO model class representing a table
            exclude_in_select: a list for column names not used for select
            kwargs: a dictionary of column names and their values for the row

        Returns:
            A tuple containing a row and a flag indicating if the row existed

        Raises:
            IntegrityError: if missing non-null field while inserting
            MultipleResultsFound: if somehow more than one row exist in database
                with given kwargs except ones in exclude_in_select
        """

        # don't use exclude_in_select for querying
        qkwargs = dict(kwargs)

        if exclude_in_select:
            for k in exclude_in_select:
                qkwargs.pop(k)

        try:
            row = session.query(model).filter_by(**qkwargs).one()
            existed = True
        except NoResultFound:
            #created = model(**kwargs)
            try:
                rows = [kwargs]
                stmt = pg_insert(model).values(rows)
                session.execute(stmt)
                #session.add(created)
                logger.debug(
                    "Added a row of type %s", model().__class__.__name__
                )
                existed = False
            except IntegrityError as e:
                logger.warning(str(e))
                existed = True

            row = session.query(model).filter_by(**qkwargs).one()

        return row, existed

    @staticmethod
    def get_or_create_entity(session, short_name, name=None, description=None):
        """
        Get or create a producer/consumer entity

        This function looks up an entity using the short_name available. If no
        such entity exists then it creates one and return information about it.

        Args:
            session: sqlalchemy session object to use for transaction
            short_name: abbreviation for the name of entity
            name: long name of entity if available
            description: Any description, if available

        Returns:
            A row from entity table
        """

        kwargs = {
            const_entity.COLUMN_NAME: name,
            const_entity.COLUMN_SHORT_NAME: short_name,
            const_entity.COLUMN_DESCRIPTION: description
        }

        return DBManager.get_or_create(
            session=session,
            model=Entity,
            exclude_in_select=[
                const_entity.COLUMN_NAME,
                const_entity.COLUMN_DESCRIPTION
                ],
            **kwargs
        )

    @staticmethod
    def get_standard_unit_for_pe(session, pe):
        """
        Get an existing standard unit for given physical element


        Args:
            session: sqlalchemy session object to use for transaction
            pe: the SHEF code for physical element

        Returns:
            A row from the physical_element table
        """

        unit = None
        try:
            physical_element = session.query(PhysicalElement).get(pe)
            unit = physical_element.unit
        except OperationalError as oper_error:
            logger.exception(str(oper_error))
            raise
        except DatabaseError as db_err:
            logger.exception(str(db_err))
            raise

        return unit

    @staticmethod
    def get_or_create_station(session, wfo, gage_code, gage_name):
        """
        Get information about a station given the lid or create one

        The current location information may have duplicate rows for given lid,
        therefore we need to select one of the rows returned by the select.

        Args:
            session: sqlalchemy session object to use for transaction
            wfo: The weather forecast office code
            gage_code: lid for the given station
            gage_name: long name of gage

        Returns:
            An instance of station with gage_code and flag indicating whether
            record existed or was created.
        """

        kwargs = {
            const_station.COLUMN_HSA: wfo,
            const_station.COLUMN_LID: gage_code,
            const_station.COLUMN_NWS_NAME: gage_name
        }

        return DBManager.get_or_create(
            session=session,
            model=Station,
            exclude_in_select=[
                const_station.COLUMN_NWS_NAME,
                const_station.COLUMN_HSA
            ],
            **kwargs
        )

    ###########################################################################
    ## Forecast related
    ###########################################################################

    @staticmethod
    def update_forecast_values_latest(session, rows):
        """
        Upsert latest forecast value record

        This function inserts or updates the latest record, only if the
        product time is later or the generation time is more recent.

        Args:
            session: sqlalchemy session object to use for transaction
            rows: List of rows to insert

        Returns:
            True if upsert was successful or False otherwise.
        """

        # Get table object from model name
        model_name=ForecastValuesLatest
        table = model_name.__table__
        update_status = False
        newer = False
        remove_old = False

        qarg = {
            const_forecast_values_latest.COLUMN_LOCATION_ID:
                rows[0][const_forecast_values_latest.COLUMN_LOCATION_ID],
            const_forecast_values_latest.COLUMN_PE: 
                rows[0][const_forecast_values_latest.COLUMN_PE],
            const_forecast_values_latest.COLUMN_DTSEP: 
                rows[0][const_forecast_values_latest.COLUMN_DTSEP],
            const_forecast_values_latest.COLUMN_PRODUCER_ENTITY_ID: 
                rows[0][const_forecast_values_latest.COLUMN_PRODUCER_ENTITY_ID],
            const_forecast_values_latest.COLUMN_DISTRIBUTOR_ENTITY_ID: 
                rows[0][const_forecast_values_latest.COLUMN_DISTRIBUTOR_ENTITY_ID],
            const_forecast_values_latest.COLUMN_PE_PRIORITY: 
                rows[0][const_forecast_values_latest.COLUMN_PE_PRIORITY],
            const_forecast_values_latest.COLUMN_MEMBER_ID: 
                rows[0][const_forecast_values_latest.COLUMN_MEMBER_ID] }
        
        try:
            # Checking for the existence of newer records
            result = session.query(model_name).filter_by(**qarg).first()
            if result:
                logger.debug("Found latest records from issued time %s generation time %s", 
                             result.product_time,
                             result.generation_time)
                if ((result.product_time < rows[0][const_forecast_values_latest.COLUMN_PRODUCT_TIME]) or
                    (result.product_time == rows[0][const_forecast_values_latest.COLUMN_PRODUCT_TIME] and
                     result.generation_time < rows[0][const_forecast_values_latest.COLUMN_GENERATION_TIME])):
                   newer = True
                   # Delete existing records
                   logger.debug("Removing older existing latest records")
                   remove_old = True
                else:
                   logger.debug("Not inserting issued time %s generation time %s",
                                rows[0][const_forecast_values_latest.COLUMN_PRODUCT_TIME],
                                rows[0][const_forecast_values_latest.COLUMN_GENERATION_TIME])
                   newer = False
            else:
                logger.debug("No result returned")
                newer = True

        except NoResultFound:
            logger.debug("No existing latest records found")
            newer = True

        if newer:
            with session.begin():
                if remove_old:
                    session.query(model_name).filter_by(**qarg).delete(synchronize_session='evaluate')
                # Insert new records
                logger.debug("Inserting latest records")

                statement = (pg_insert(table).values(rows)).on_conflict_do_nothing()
                session.execute(statement)

            update_status = True
        else:
            update_status = True

        return update_status

    @staticmethod
    def upsert_forecast_values(session, location_id, pe, dtsep, product_time,
                               start_time, generation_time,
                               distributor_id, producer_id, pe_priority,
                               member_id, time_data_pairs, basis_time=None):
        """
        Upsert forecast values

        This function upserts a record for each entry in the time_data_pairs
        list.

        Args:
            session: sqlalchemy session object to use for transaction
            location_id: the synthetic_key for station location
            pe: The 2-character physical element code
            dtsep: The up to 5-character rest of the physical element
            product_time: time the forecast was issued
            start_time: the earliest valid time in the forecast time series
            generation_time: time the forecast was generated
            distributor_id: the synthetic_key for distributor entity
            producer_id: the synthetic_key for producer entity
            pe_priority: defined constants for primary of secondary forecast
            member_id: an integer representing forecast member index
            time_data_pairs: A list of dictionaries each representing a valid
                time, value and lead interval
            basis_time: unknown at the time but is the reference time

        Returns:
            True if upsert was successful or False otherwise.
        """

        # Construct data rows

        rows = []

        for time_data_pair in time_data_pairs:
            rows.append(
                {
                    const_forecast_values.COLUMN_LOCATION_ID : location_id,
                    const_forecast_values.COLUMN_PE : pe,
                    const_forecast_values.COLUMN_DTSEP : dtsep,
                    const_forecast_values.COLUMN_PRODUCT_TIME : product_time,
                    const_forecast_values.COLUMN_VALID_TIME : \
                        time_data_pair.get( const_time_value.VALID_TIME ),
                    const_forecast_values.COLUMN_START_TIME : start_time,
                    const_forecast_values.COLUMN_GENERATION_TIME : \
                        generation_time,
                    const_forecast_values.COLUMN_DISTRIBUTOR_ENTITY_ID : \
                        distributor_id,
                    const_forecast_values.COLUMN_PRODUCER_ENTITY_ID : \
                        producer_id,
                    const_forecast_values.COLUMN_PE_PRIORITY : pe_priority,
                    const_forecast_values.COLUMN_MEMBER_ID : member_id,
                    const_forecast_values.COLUMN_BASIS_TIME : basis_time,
                    const_forecast_values.COLUMN_VALUE : \
                        time_data_pair.get( const_time_value.VALUE )
                }
            )

        logger.debug("Inserting %d rows", len(rows))
        if DBManager.upsert_rows(session=session,
                                 model_name=ForecastValues,
                                 rows=rows,
                                 index_elements=[
                                     const_forecast_values.COLUMN_LOCATION_ID,
                                     const_forecast_values.COLUMN_PE,
                                     const_forecast_values.COLUMN_DTSEP,
                                     const_forecast_values.COLUMN_PRODUCT_TIME,
                                     const_forecast_values.COLUMN_VALID_TIME,
                                     const_forecast_values.COLUMN_START_TIME,
                                     const_forecast_values.COLUMN_GENERATION_TIME,
                                     const_forecast_values.COLUMN_DISTRIBUTOR_ENTITY_ID,
                                     const_forecast_values.COLUMN_PRODUCER_ENTITY_ID,
                                     const_forecast_values.COLUMN_PE_PRIORITY,
                                     const_forecast_values.COLUMN_MEMBER_ID]) and \
            DBManager.update_forecast_values_latest(session=session, rows=rows):
            return True
        else:
            return False

    @staticmethod
    def insert_category_forecasts(
            session,
            metadata,
            computed_metadata,
            category_values
    ):
        """
        Insert forecast values for primary/secondary

        Given the metadata about a forecast and the forecast values, insert or
        update the existing values for that forecast, if any. The ingester needs
        to make sure that all the intermediate table entries exist or get
        created before the actual forecast insertion takes place.

        Args:
            session: sqlalchemy session object to use for transaction(s)
            metadata: an instance of MetaData describing forecast time step,
                start time, pedts etc.
            computed_metadata: calculated metadata for forecast series
            category_values: an array of the actual forecast values

        Returns:
            A tuple of booleans (existed, inserted)
        """

        # get station
        station, existed = DBManager.get_or_create_station(
            session=session,
            wfo=metadata.wfo,
            gage_code=metadata.gage_code,
            gage_name=metadata.gage_name
        )
        logger.debug(str(station))
        logger.debug("Station existed: %s", str(existed))

        ## set distributor entity
        # get or insert a distributor entity (it will be hardcoded by ingester)
        distributor_entity, existed = DBManager.get_or_create_entity(
            session=session,
            short_name=const_entity.DEFAULT_DISTRIBUTOR_ENTITY_SHORT_NAME,
            name=const_entity.DEFAULT_DISTRIBUTOR_ENTITY_NAME
        )
        logger.debug(str(distributor_entity))
        logger.debug("Distributor entity existed: %s", str(existed))

        # get or insert a WFO producer entity
        wfo_short_name = metadata.wfo
        producer_entity, existed = DBManager.get_or_create_entity(
            session=session,
            short_name=wfo_short_name
        )
        logger.debug(str(producer_entity))
        logger.debug("Producer entity existed: %s", str(existed))

        # Insert values
        DBManager.upsert_forecast_values(
            session=session,
            location_id=station.location_id,
            pe=computed_metadata.parameter_code.physical_element,
            dtsep=(computed_metadata.parameter_code.duration +
                   computed_metadata.parameter_code.type_source +
                   computed_metadata.parameter_code.extremum +
                   computed_metadata.parameter_code.probability),
            product_time=metadata.issued_time,
            start_time=computed_metadata.start_time,
            generation_time=metadata.generation_time,
            distributor_id=distributor_entity.entity_id,
            producer_id=producer_entity.entity_id,
            pe_priority= computed_metadata.priority,
            member_id=const_forecast_values.DEFAULT_MEMBER_ID,
            time_data_pairs=category_values
        )

        return False, True


    ###########################################################################
    ## XML Event related
    ###########################################################################

    @staticmethod
    def update_hml_xml_status(session, hml_entry_id, xml_index, status):
        """
        Update an entry in HML XML table with new status

        Updates existing entry in hml_xml table with new status and the time
        the status is updated as current UTC time.

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: The foreign key to the hml table
            xml_index: the position of xml in parent hml file. It can be used to
                track down a malformed XML along with lid and pedts below
            status: the status of the xml processing stage

        Returns:
            This function returns nothing

        Raises:
            Exception: if there is no key
        """

        # update the status to split and status timestamp to current utc time
        update_values = {
            const_hml_xml.COLUMN_XML_STATUS: status,
            const_hml_xml.COLUMN_XML_STATUS_TS: utcnow()
        }

        update_statement = update( HmlXml )\
            .where(
                and_(
                    HmlXml.hml_id == hml_entry_id,
                    HmlXml.xml_index == xml_index
                    )
                )\
            .values( update_values )
        session.execute( update_statement )

        return True

    @staticmethod
    def is_xml_processed(session, hml_entry_id, xml_index):
        """
        Check if XML has already been processed

        If the xml status is set to parse_complete or not.

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: The foreign key to the hml table
            xml_index: the index of xml which together with hml_id unqiuely
                defines an xml entry in hml_xml table

        Returns:
            True if xml is already processed else false
        """

        # statement to get the xml_status of xml with given hml id and xml index
        select_xml_status_query = select([ HmlXml.xml_status ])\
            .where(
                and_(
                    HmlXml.hml_id == hml_entry_id,
                    HmlXml.xml_index == xml_index
                    )
                )

        # get xml status of given found xml
        result_proxy = session.execute(select_xml_status_query)
        result_tuple = result_proxy.fetchone()
        # This shouldn't really happen
        if result_tuple is None:
            logger.debug("Did not find XML status of hml_id %d xml index %d",
                         hml_entry_id, xml_index )
            return False

        xml_status = result_tuple[0]

        return xml_status == HmlXmlStatusEnum.parse_complete

    @staticmethod
    def try_mark_hml_processed(session, hml_entry_id):
        """
        Mark the HML processed if all its xmls are processed.

        This method checks if all xmls for given hml id are processed or not. If
        they are processed then it marks hml as processed in hml table.

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: The foreign key to the hml table

        Returns:
            nothing
        """

        # CTE to get any xmls for the hml that are not marked complete
        incomplete_xmls = session.query(HmlXml.hml_id)\
            .filter( HmlXml.hml_id == hml_entry_id )\
            .filter( HmlXml.xml_status != HmlXmlStatusEnum.parse_complete )\
            .exists()

        # update hml entry if incomplete_xmls sub-query returns empty set while
        # making sure that there are xmls in hml_xml table for given hml
        session.query( Hml )\
            .filter( Hml.hml_id == HmlXml.hml_id )\
            .filter(HmlXml.hml_id == hml_entry_id )\
            .filter( ~incomplete_xmls )\
            .update(
                {
                    Hml.hml_status : HmlStatusEnum.xml_parse_complete,
                    Hml.hml_status_ts : utcnow()
                },
                synchronize_session=False
                )

    @staticmethod
    def try_mark_hml_parse_failure(session, hml_entry_id):
        """
        Mark the HML status to parse_failure

        """

        # CTE to get parse failed xmls
        parse_failed_xmls = session.query(HmlXml.hml_id)\
            .filter( HmlXml.hml_id == hml_entry_id )\
            .filter( HmlXml.xml_status == HmlXmlStatusEnum.parse_failure )\
            .exists()

        # update hml entry to parse failure if any xml for that hml is marked as
        # parse failed.
        session.query(Hml)\
            .filter( Hml.hml_id == HmlXml.hml_id )\
            .filter( HmlXml.hml_id == hml_entry_id )\
            .filter( parse_failed_xmls )\
            .update(
                {
                    Hml.hml_status : HmlStatusEnum.xml_parse_failure,
                    Hml.hml_status_ts : utcnow()
                },
                synchronize_session=False
                )
