"""
This file gets tables from database provided in connection string using
reflection. Modifications are made to keep old observation schema in the way it
was designed with object-first ORM approach.


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

# ORM imports
from sqlalchemy import Column, DateTime, ForeignKey
from sqlalchemy import Integer, SmallInteger, Float, String, Text

from sqlalchemy.schema import UniqueConstraint, Table, Index

from sqlalchemy.orm import relationship

from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy.ext.compiler import compiles

from sqlalchemy.sql import expression, text

from sqlalchemy.types import Enum as DBEnum
from enum import Enum

# postgres specific
from sqlalchemy.dialects.postgresql.base import INTERVAL, TIMESTAMP

# local imports
from constants.database import const_entity, \
    const_forecast_values, const_forecast_values_latest, \
    const_unit, const_physical_element, \
    const_station, const_hml, const_hml_xml

Base = declarative_base()
metadata = Base.metadata


# used to populate db columns with current UTC timestamp
class utcnow(expression.FunctionElement):
    """
    This class defines the current UTC time
    """

    type = DateTime()


@compiles(utcnow, 'postgresql')
def pg_utcnow(element, compiler, **kw):
    """
    This function computes the UTC timestamp for postgresql dialect
    """

    return "TIMEZONE('utc', CURRENT_TIMESTAMP)"


class AutoNumber(Enum):
    """
    Number the enum member values automatically

    Python 3.4 lacks the auto() method to automatically number the enum member
    values so here is the hack provided on following link:
    docs.python.org/3.4/library/enum.html#enum.Enum
    """

    def __new__(cls):
        value = len(cls.__members__)
        obj = object.__new__(cls)
        obj._value_ = value
        return obj


class HmlStatusEnum(AutoNumber):
    """
    The enums for the status column of HML table

    SQLAlchemy persists the enum class variable names by default as strings in
    the database enum columns not the value of enum variables. Strange? Read at
    following link:
    docs.sqlalchemy.org/en/latest/core/type_basics.html?#sqlalchemy.types.Enum
    """

    # using auto here as enum member value to reinforce the point that enum
    # member names will be used by SQLAlchemy not their values hence auto
    received = ()
    split = ()
    xml_parse_complete = ()
    xml_parse_failure = ()
    aborted = ()


class HmlXmlStatusEnum(AutoNumber):
    """
    The enums for the status column of hml_xml table

    SQLAlchemy persists the enum class variable names by default as strings in
    the database enum columns not the value of enum variables. Strange? Read at
    following link:
    docs.sqlalchemy.org/en/latest/core/type_basics.html?#sqlalchemy.types.Enum
    """

    # using auto here as enum member value to reinforce the point that enum
    # member names will be used by SQLAlchemy not their values hence auto
    parse_task_created = ()
    parse_begin = ()
    parse_complete = ()
    parse_failure = ()
    post_parse_failure = ()
    db_load_failure = ()
    aborted = ()


###############################################################################
# Common Tables
###############################################################################


class Entity(Base):
    """ This class models a consumer or producer entity like WFO """

    __tablename__ = const_entity.TABLE_ENTITY

    entity_id = Column(
        Integer,
        primary_key=True,
        server_default=text("nextval('entity_entity_id_seq'::regclass)")
    )
    name = Column(String(50), unique=True)
    short_name = Column(String(10), nullable=False, unique=True)
    description = Column(Text)

    def __repr__(self):

        return "Entity<( entity_id: %s, short_name: %s )>" % (
            str(self.entity_id),
            self.short_name
        )


class Unit(Base):
    """ This class models standard unit for SHEF physical element """

    __tablename__ = const_unit.TABLE_UNIT

    name = Column(String(5), primary_key=True, unique=True)
    description = Column(Text, nullable=False)


class PhysicalElement(Base):
    """ This table models information about physical elements """

    __tablename__ = const_physical_element.TABLE_PHYSICAL_ELEMENT

    unit = Column(
        ForeignKey(
            'unit.name',
            ondelete='RESTRICT',
            onupdate='RESTRICT',
            deferrable=True,
            initially='DEFERRED'
        ),
        nullable=False,
        server_default=text("nextval('physical_element_unit_id_seq'::regclass)")
    )
    pe = Column(String(2), primary_key=True, unique=True)
    short_description = Column(String(100), nullable=False)
    description = Column(Text)

    unit1 = relationship('Unit')


class Station(Base):
    """ This class represent a geographical station """

    __tablename__ = const_station.TABLE_STATION

    location_id = Column(
        Integer,
        primary_key=True,
        server_default=text("nextval('station_location_id_seq'::regclass)"))
    lid = Column(String(8), nullable=False)
    comid = Column(Text)
    ahps_site = Column(String(1))
    gage_id = Column(Text)
    huc = Column(Text)
    rfc = Column(Text)
    fcst = Column(Text)
    hsa = Column(Text)
    typ = Column(Text)
    fip = Column(Text)
    st = Column(String(2))
    nws_st = Column(String(2))
    atv = Column(String(1))
    ref = Column(String(1))
    hcdn = Column(String(1))
    da = Column(Float)
    nws_lat = Column(Text)
    nws_lon = Column(Text)
    usgs_lat = Column(Float)
    usgs_lon = Column(Float)
    cac = Column(String(1))
    coord = Column(Text)
    alt = Column(Float)
    alt_acy = Column(Text)
    datum = Column(Text)
    goes_id = Column(Text)
    n1_0 = Column(String(1))
    n1_1 = Column(String(1))
    nws_name = Column(Text)
    usgs_name = Column(Text)

    def __repr__(self):

        return "Station<( location_id: %s, wfo: %s, lid: %s, name; %s)>" % (
                    str(self.location_id),
                    self.hsa,
                    self.lid,
                    self.nws_name
                )

###############################################################################
# Forecast related tables
###############################################################################

class ForecastValues(Base):
    """ This class describes forecast data """

    __tablename__ = const_forecast_values.TABLE_FORECAST_VALUES

    location_id = Column(ForeignKey('station.location_id'),
                         primary_key=True, nullable=False)
    pe = Column(ForeignKey('physical_element.pe'), 
                           primary_key=True, nullable=False)
    dtsep = Column(String(5),
                   primary_key=True, nullable=False)
    product_time = Column(TIMESTAMP(True),
                          primary_key=True, index=True, nullable=False)
    valid_time = Column(TIMESTAMP(True),
                        primary_key=True, nullable=False)
    start_time = Column(TIMESTAMP(True),
                        primary_key=True, nullable=False)
    generation_time = Column(TIMESTAMP(True),
                             primary_key=True, nullable=False)
    distributor_entity_id = Column(ForeignKey('entity.entity_id'),
                                   primary_key=True, nullable=False)
    producer_entity_id = Column(ForeignKey('entity.entity_id'),
                                primary_key=True, nullable=False)
    pe_priority = Column(Integer,
                         primary_key=True, nullable=False)
    member_id = Column(SmallInteger,
                       primary_key=True, nullable=False)
    basis_time = Column(TIMESTAMP(True), nullable=True)
    value = Column(Float(53), nullable=False)

    distributor_entity = relationship(
        'Entity',
        primaryjoin='ForecastValues.distributor_entity_id == Entity.entity_id'
    )
    producer_entity = relationship(
        'Entity',
        primaryjoin='ForecastValues.producer_entity_id == Entity.entity_id'
    )

    def __repr__(self):

        return "ForecastValues<( location_id: %s, pe: %s, dtsep: %s, "\
               "product_time: %s, valid_time: %s, start_time: %s, "\
               "generation_time: %s, distributor_entity_id: %s, "\
               "producer_entity_id: %s, pe_priority: %s, member_id: %s, "\
               "basis_time: %s, value: %s )>" % (
                    str(self.location_id), str(self.pe), str(self.dtsep),
                    str(self.product_time), str(self.valid_time),
                    str(self.start_time), str(self.generation_time),
                    str(self.distributor_entity_id),
                    str(self.producer_entity_id), str(self.pe_priority),
                    str(self.member_id), str(self.basis_time), str(self.value)
                )

###############################################################################
# Latest stored forecast table
###############################################################################
class ForecastValuesLatest(Base):
    """ This class describes latest forecast data """

    __tablename__ = const_forecast_values_latest.TABLE_FORECAST_VALUES_LATEST

    location_id = Column(ForeignKey('station.location_id'),
                         primary_key=True, nullable=False)
    pe = Column(ForeignKey('physical_element.pe'),
                           primary_key=True, nullable=False)
    dtsep = Column(String(5),
                   primary_key=True, nullable=False)
    product_time = Column(TIMESTAMP(True),
                          primary_key=True, index=True, nullable=False)
    valid_time = Column(TIMESTAMP(True),
                        primary_key=True, nullable=False)
    start_time = Column(TIMESTAMP(True),
                        primary_key=True, nullable=False)
    generation_time = Column(TIMESTAMP(True),
                             primary_key=True, nullable=False)
    distributor_entity_id = Column(ForeignKey('entity.entity_id'),
                                   primary_key=True, nullable=False)
    producer_entity_id = Column(ForeignKey('entity.entity_id'),
                                primary_key=True, nullable=False)
    pe_priority = Column(Integer,
                         primary_key=True, nullable=False)
    member_id = Column(SmallInteger,
                       primary_key=True, nullable=False)
    basis_time = Column(TIMESTAMP(True), nullable=True)
    value = Column(Float(53), nullable=False)

    distributor_entity = relationship(
        'Entity',
        primaryjoin='ForecastValuesLatest.distributor_entity_id == Entity.entity_id'
    )
    producer_entity = relationship(
        'Entity',
        primaryjoin='ForecastValuesLatest.producer_entity_id == Entity.entity_id'
    )

    def __repr__(self):

        return "ForecastValuesLatest<( location_id: %s, pe: %s, dtsep: %s, "\
               "product_time: %s, valid_time: %s, start_time: %s, "\
               "generation_time: %s, distributor_entity_id: %s, "\
               "producer_entity_id: %s, pe_priority: %s, member_id: %s, "\
               "basis_time: %s, value: %s )>" % (
                    str(self.location_id), str(self.pe), str(self.dtsep),
                    str(self.product_time), str(self.valid_time),
                    str(self.start_time), str(self.generation_time),
                    str(self.distributor_entity_id),
                    str(self.producer_entity_id), str(self.pe_priority),
                    str(self.member_id), str(self.basis_time), str(self.value)
                )

###############################################################################
# HML Processing Metrics
###############################################################################


class Hml(Base):
    """
    This class models the HML relation in database
    """

    __tablename__ = const_hml.TABLE_HML

    hml_id = Column(
        Integer,
        primary_key=True,
        server_default=text("nextval('hml_hml_id_seq'::regclass)")
    )
    url = Column(Text, nullable=False, unique=True)
    hml_status = Column(
        DBEnum( HmlStatusEnum ),
        nullable=False
    )
    hml_status_ts = Column(TIMESTAMP(True), nullable=False)


class HmlXml(Base):
    """
    This class models the hml_xml relation in database
    """

    __tablename__ = const_hml_xml.TABLE_HML_XML

    hml_id = Column(
        ForeignKey(
            'hml.hml_id',
            ondelete='RESTRICT',
            onupdate='RESTRICT',
            deferrable=True,
            initially='DEFERRED'
        ),
        primary_key=True,
        nullable=False
    )
    xml_index = Column(SmallInteger, primary_key=True, nullable=False)
    lid = Column(Text, nullable=False)
    pedts = Column(Text, nullable=False)
    xml_status = Column(
        DBEnum( HmlXmlStatusEnum ),
        nullable=False
    )
    xml_status_ts = Column(TIMESTAMP(True))

    hml = relationship('Hml')
