# This is only used if docker-compose is not available
sudo docker run -d --restart=always --name wrds_xml_ingester \
                --env-file=".env.prod" wrds_xml_ingester
