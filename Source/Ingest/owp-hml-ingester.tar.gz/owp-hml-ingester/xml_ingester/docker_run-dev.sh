# This is only used if docker-compose is not available
sudo docker run --name wrds_xml_ingester \
                --env-file=".env.dev" wrds_xml_ingester
