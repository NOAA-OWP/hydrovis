"""
This file contains all configuration related constants like names of section,
option keys and their default values etc

This file contains all configuration related constants like names of section,
option keys and their default values etc

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/07/2018
"""

## @var DEFAULT_CONFIG_FILENAME
#  Default config file name
DEFAULT_CONFIG_FILENAME = "ingester.conf"


##################
# RABBITMQ SECTION
##################

## @var RABBITMQ_SECTION
# Name of the rabbitmq section
RABBITMQ_SECTION = "rabbitmq"

## @var RABBITMQ_URL
# connection url for RabbitMQ
RABBITMQ_URL = "url"

## @var RABBITMQ_EXCHANGE
# name of exchange to create in RabbitMQ
RABBITMQ_EXCHANGE = "exchange"

## @var RABBITMQ_XML_QUEUE
# name of XML message queue in RabbitMQ
RABBITMQ_XML_QUEUE = "xml_queue"

## @var RABBITMQ_XML_PREFETCH_COUNT
# the maximum messages that can be sent to an xml consumer
RABBITMQ_XML_PREFETCH_COUNT = "xml_prefetch_count"

## @var RABBITMQ_DL_XML_MESSAGE_TTL
# the number of seconds an xml message will stay in dead-letter-queue
RABBITMQ_DL_XML_MESSAGE_TTL = "dl_xml_message_ttl"


##################
# DATABASE SECTION
##################

## @var DATABASE_SECTION
# Name of database section
DATABASE_SECTION = "database"

## @var DATABASE_CONNECTION_STRING
# Connection string to database
DATABASE_CONNECTION_STRING = "connection_string"


##############
# LOG SECTION
##############

## @var LOG_SECTION
# Name of the log section
LOG_SECTION = "log"

## @var LOG_LEVEL
# Level of the log like debug, or info
LOG_LEVEL = "level"

## @var LOG_DEBUG_LEVEL
# value if debug log level is intended
LOG_DEBUG_LEVEL = "debug"

## @var LOG_TARGET
# key for where to save log output
LOG_TARGET = "target"

## @var LOG_FILE
# log to a file
LOG_FILE = "file"

## @var LOG_STREAM
# log to a stream (stdout)
LOG_STREAM = "stream"

## @var LOG_FILE
# Name (and path) of the log file, needed if LOG_TARGET is set to file
LOG_FILE_PATH = "file_path"

