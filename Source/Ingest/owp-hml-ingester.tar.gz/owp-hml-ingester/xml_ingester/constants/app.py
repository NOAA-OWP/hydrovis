"""
This file contains application level constants like version number etc.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/07/2018
"""

## @var NAME
# Name of application
NAME = "HMLXMLIngester"

## @var VERSION
# Version of the application
VERSION = "1.0"
