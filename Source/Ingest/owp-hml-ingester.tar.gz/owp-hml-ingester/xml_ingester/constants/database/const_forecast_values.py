"""
Constants related to forecast_values table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Anders Nilsson
@version 1.0
@date 08/08/2019
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_FORECAST_VALUES
# Name of forecast values table
TABLE_FORECAST_VALUES = "forecast_values"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_LOCATION_ID
# Foreign key to the location
COLUMN_LOCATION_ID = "location_id"

## @COLUMN_PE
# Name of physical element column
COLUMN_PE = "pe"

## @COLUMN_DTSEP
# Name of rest of physical element column
COLUMN_DTSEP = "dtsep"

## @COLUMN_PRODUCT_TIME
# Name of product time column
COLUMN_PRODUCT_TIME = "product_time"

## @COLUMN_VALID_TIME
# Name of valid time column
COLUMN_VALID_TIME = "valid_time"

## @COLUMN_START_TIME
# Name of start time column
COLUMN_START_TIME = "start_time"

## @COLUMN_GENERATION_TIME
# Name of generation time column
COLUMN_GENERATION_TIME = "generation_time"

## @COLUMN_DISTRIBUTOR_ENTITY_ID
# Foreign key to the distributor entity
COLUMN_DISTRIBUTOR_ENTITY_ID = "distributor_entity_id"

## @COLUMN_PRODUCER_ENTITY_ID
# Foreign key to the producer entity
COLUMN_PRODUCER_ENTITY_ID = "producer_entity_id"

## @COLUMN_PE_PRIORITY
# Name of physical element priority
COLUMN_PE_PRIORITY = "pe_priority"

## @COLUMN_MEMBER_ID
# Name of forecast member
COLUMN_MEMBER_ID = "member_id"

## @DEFAULT_MEMBER_ID
# An integer representing forecast member default when non-ensemble forecast
DEFAULT_MEMBER_ID = 0

## @COLUMN_BASIS_TIME
# Name of basis time column
COLUMN_BASIS_TIME = "basis_time"

## @COLUMN_VALUE
# Name of value column
COLUMN_VALUE = "value"
