"""
Constants for metric table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_METRIC
# Name of metric table
TABLE_METRIC = "metric"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_LOCATION_ID
# Name of location id column
COLUMN_LOCATION_ID = "location_id"

## @COLUMN_PHYSICAL_ELEMENT
# Name of physical element column
COLUMN_PHYSICAL_ELEMENT = "pe"

## @COLUMN_DURATION
# Name of duration column
COLUMN_DURATION = "d"

## @COLUMN_TYPE_SOURCE
# Name of type source column
COLUMN_TYPE_SOURCE = "ts"

## @COLUMN_EXTREMUM
# Name of extremum column
COLUMN_EXTREMUM = "e"

## @COLUMN_PROBABILITY
# Name of probability column
COLUMN_PROBABILITY = "p"
