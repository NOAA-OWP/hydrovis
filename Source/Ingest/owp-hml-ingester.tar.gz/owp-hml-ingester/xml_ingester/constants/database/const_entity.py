"""
Constants for unit table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/16/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_ENTITY
# Name of metric table
TABLE_ENTITY = "entity"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_NAME
# name column of entity
COLUMN_NAME = "name"

## @COLUMN_SHORT_NAME
# short name column of entity
COLUMN_SHORT_NAME = "short_name"

## @COLUMN_DESCRIPTION
# description column for entity
COLUMN_DESCRIPTION = "description"

###############################################################################
### SUPPLEMENTAL
###############################################################################

## @DEFAULT_DISTRIBUTOR_ENTITY_SHORT_NAME
# Hard coded short name (abbreivation) of the HML distributor
DEFAULT_DISTRIBUTOR_ENTITY_SHORT_NAME = "SBN"

## @DEFAULT_DISTRIBUTOR_ENTITY_NAME
# The full name of HML distributor
DEFAULT_DISTRIBUTOR_ENTITY_NAME = "Satellite Broadcast Network"
