"""
Constants for station table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_STATION
# Name of station table
TABLE_STATION = "station"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_LID
# The location id or gage code of gage
COLUMN_LID = "lid"

## @COLUMN_HSA
# The WFO or HSA related to gage
COLUMN_HSA = "hsa"

## @COLUMN_NWS_NAME
# The long name of the location id
COLUMN_NWS_NAME = "nws_name"
