"""
Constants for metric value table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_METRIC_VALUE
# Name of metric value table
TABLE_METRIC_VALUE = "metric_value"

###############################################################################
### COLUMN NAMES
###############################################################################

## @var COLUMN_MEMBER_METRIC_ID
# Synthetic key for forecast_member_metric table
COLUMN_MEMBER_METRIC_ID = "member_metric_id"

## @var COLUMN_VALID_TIME
# The actual timestamp associated with a forecast data value
COLUMN_VALID_TIME = "valid_time"

## @var COLUMN_VALUE
# The value fo the forecast time series value
COLUMN_VALUE = "value"

## @var COLUMN_LEAD_INTERVAL
# The name of lead interval column
COLUMN_LEAD_INTERVAL = "lead_interval"
