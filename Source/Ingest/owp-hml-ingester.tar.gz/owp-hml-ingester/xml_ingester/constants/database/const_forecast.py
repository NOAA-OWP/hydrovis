"""
Constants related to forecast table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/18/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_FORECAST
# Name of forecast table
TABLE_FORECAST = "forecast"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_BASIS_TIME
# Name of basis time column
COLUMN_BASIS_TIME = "basis_time"

## @COLUMN_GENERATION_TIME
# Name of gneration time column
COLUMN_GENERATION_TIME = "generation_time"

## @COLUMN_PRODUCT_TIME
# Name of product time column
COLUMN_PRODUCT_TIME = "product_time"

## @COLUMN_START_TIME
# Name of start time column
COLUMN_START_TIME = "start_time"

## @COLUMN_DISTRIBUTOR_ENTITY_ID
# Foreign key to the distributor entity
COLUMN_DISTRIBUTOR_ENTITY_ID = "distributor_entity_id"

## @COLUMN_PRODUCER_ENTITY_ID
# Foreign key to the producer entity
COLUMN_PRODUCER_ENTITY_ID = "producer_entity_id"
