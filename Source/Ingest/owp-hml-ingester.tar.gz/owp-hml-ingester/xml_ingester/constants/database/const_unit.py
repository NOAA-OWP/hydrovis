"""
Constants for unit table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_UNIT
# Name of metric table
TABLE_UNIT = "unit"

###############################################################################
### COLUMN NAMES
###############################################################################


###############################################################################
### CONSTANT VALUES
###############################################################################

## @UNIT_CFS
# cubic feet per second
UNIT_CFS = "CFS"

## @UNIT_KCFS
# kilo cubic feet per second
UNIT_KCFS = "KCFS"
