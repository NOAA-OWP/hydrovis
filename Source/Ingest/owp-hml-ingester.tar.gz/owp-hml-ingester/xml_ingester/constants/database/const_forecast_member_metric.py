"""
Constants for forecast_member_metric table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_FORECAST_MEMBER_METRIC
# Name of forecast member metric table
TABLE_FORECAST_MEMBER_METRIC = "forecast_member_metric"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_FORECAST_ID
# Synthetic key for forecast table
COLUMN_FORECAST_ID = "forecast_id"

## @COLUMN_MEMBER_ID
# Synthetic key for member table, indicates the forecast index in Ensemble
COLUMN_MEMBER_ID = "member_id"

## @COLUMN_METRIC_ID
# Synthetic key for metric table, identifies physical element at a location
COLUMN_METRIC_ID = "metric_id"

## @COLUMN_PE_PRIORITY
# The synthetic
COLUMN_PE_PRIORITY = "pe_priority"

###############################################################################
### SUPPLEMENTAL
###############################################################################

## @DEFAULT_MEMBER_ID
# An integer representing forecast member default when non-ensemble forecast
DEFAULT_MEMBER_ID = 0

## @CONST_PRIORITY_PRIMARY
# An integer representing priority to be primary
CONST_PRIORITY_PRIMARY = 1

## @CONST_PRIORITY_SECONDARY
# An integer representing priority to be secondary
CONST_PRIORITY_SECONDARY = 2
