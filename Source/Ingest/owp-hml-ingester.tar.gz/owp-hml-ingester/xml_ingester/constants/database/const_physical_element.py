"""
Constants for physical element table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_PHYSICAL_ELEMENT
# Name of physical element table
TABLE_PHYSICAL_ELEMENT = "physical_element"

###############################################################################
### COLUMN NAMES
###############################################################################



