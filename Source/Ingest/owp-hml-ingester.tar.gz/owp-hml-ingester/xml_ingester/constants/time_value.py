"""
This file contains the constants that are used as keys in the dictionary of
individual observation/forecast time series.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.2
@date 10/09/2018
"""

## @var VALID_TIME
# valid time key for time series data point
VALID_TIME = "valid_time"

## @var VALUE
# numerical value for time series data point
VALUE = "value"

## @var LEAD
# lead interval of a data point with respect to start time
LEAD = "lead"
