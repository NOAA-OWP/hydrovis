''' 
@package This file contains a list of xml related constants including tags and
attribute names of interest
'''

## This file contains a list of xml related constants including tags and
# attribute names of interest
#
#  United States Department of Commerce 
#  NOAA (National Oceanic and Atmospheric Administration) 
#  National Weather Service 
#  Office of Water Prediction 
#  @author Shafiq Rahman
#  @version 1.0
#  @date 10/03/2017


################
### TAG SECTION
################


## @var TAG_OBSERVED
# Name of the the XML observation tag to be read from API response
TAG_OBSERVED = "observed"

## @var TAG_FORECAST
# Name of the the XML forecast tag to be read from API response
TAG_FORECAST = "forecast"

## @var TAG_DATUM
# name of datum tag
TAG_DATUM = "datum"

## @var TAG_VALID
# datum valid time tag
TAG_VALID = "valid"

## @var TAG_MESSAGE
# message element tag
TAG_MESSAGE = "message"

## @var TAG_PRIMARY
# datum primary tag
TAG_PRIMARY = "primary"

## @var TAG_SECONDARY
# datum secondary tag
TAG_SECONDARY = "secondary"

## @var TAG_PEDTS
# datum pedts tag
TAG_PEDTS = "pedts"


#######################
### ATTRIBUTES SECTION
#######################

## @var ATTRIB_ORIGINATOR
# valid timezone attribute
ATTRIB_ORIGINATOR = "originator"

## @var ATTRIB_ID
# gage id for xml
ATTRIB_ID = "id"

## @var ATTRIB_TIMEZONE
# valid timezone attribute
ATTRIB_TIMEZONE = "timezone"

## @var ATTRIB_PRIMARY_NAME
# datum primary name attribute
ATTRIB_PRIMARY_NAME = "primaryName"

## @var ATTRIB_SECONDARY_NAME
# datum secondary name attribute
ATTRIB_SECONDARY_NAME = "secondaryName"

## @var ATTRIB_PRIMARY_UNITS
# datum primary units
ATTRIB_PRIMARY_UNITS = "primaryUnits"

## @var ATTRIB_SECONDARY_UNITS
# datum secondary units
ATTRIB_SECONDARY_UNITS = "secondaryUnits"

## @var ATTRIB_PEDTS
# datum primary pedts values
ATTRIB_PEDTS = "pedts"

## @var ATTRIB_ISSUED
# Date time in UTC when forecast was issued
ATTRIB_ISSUED = "issued"

## @var ATTRIB_NAME
# name of the gage
ATTRIB_NAME = "name"

## @var ATTRIB_GENERATION_TIME
# Datetime in UTC when XML was generated
ATTRIB_GENERATION_TIME = "generationtime"

########################
### Miscellaneous
########################

## @var STAGE
# name of variable to be stage. Keep lowercase for comparison
STAGE = "stage"

## @var FLOW
# name of variable to be flow. Keep lowercase for comparison
FLOW = "flow"

## @var STORAGE
# name of variable to be storage. Keep lowercase for comparison
STORAGE = "storage"

## @var DEFAULT_STAGE_PE
# The default value of stage physical element if it is secondary
DEFAULT_STAGE_PE = "HG"

## @var DEFAULT_FLOW_PE
# The default value of flow physical element if it is secondary
DEFAULT_FLOW_PE = "QR"

## @var DEFAULT_STORAGE_PE
# The default value ot storage physical element if it is secondary
DEFAULT_STORAGE_PE = "LS"

## @var DEFAULT_EXTREMUM
# default value of extremum from SHEF manual
DEFAULT_EXTREMUM = "Z"

## @var DEFAULT_PROBABILITY
# default value of probability from SHEF manual
DEFAULT_PROBABILITY = "Z"
