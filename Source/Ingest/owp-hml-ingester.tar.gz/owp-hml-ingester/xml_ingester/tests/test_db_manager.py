"""
This module provides tests for the database manager module

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service # Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/17/2018
"""

import pytest
from mock import patch, Mock, MagicMock

from datetime import timedelta
from dateutil import parser

from sqlalchemy.exc import DatabaseError, OperationalError, IntegrityError
from sqlalchemy.pool import QueuePool

from database.db_manager import DBManager
from database.db_model import MetricValue

class TestDBManager(object):
    """
    The test suite for DBManager class
    """

    @pytest.fixture(scope="module")
    def connection_string(self):
        """
        Get a test string used as place holder for actual db connection string
        """

        return "postgresql://user:password@host:5432/database"

    @patch('database.db_manager.create_engine', return_value=Mock())
    @patch('database.db_manager.sessionmaker')
    def test_db_manager_instance(self, sessionmaker, create_engine, connection_string):
        """
        Tests the constructor of DBManager class
        """

        DBManager(connection_string=connection_string)
        create_engine.assert_called_with(
            connection_string,
            pool_size=1,
            max_overflow=0,
            poolclass=QueuePool,
            isolation_level='AUTOCOMMIT',
            echo=True
        )

        sessionmaker.assert_called_with(
            bind=create_engine(),
            expire_on_commit=False,
            autocommit=True
        )
    
    @patch(
        'database.db_manager.create_engine', 
        return_value=Mock(), 
        side_effect=DatabaseError('Some database error', None, None)
    )
    @patch('database.db_manager.sessionmaker')
    def test_db_manager_error_creating_engine(self, sessionmaker, create_engine, connection_string):
        """
        Tests the constructor of DBManager class
        """

        with pytest.raises(DatabaseError) as excinfo:
            DBManager(connection_string=connection_string)

        assert 'database' in str(excinfo.value)


    @patch('database.db_manager.pg_insert', return_value=Mock())
    def test_upsert_rows(self, mock_pg_insert, connection_string):
        """
        Tests the upsert method for normal operation
        """

        with patch.object(DBManager, '__enter__', return_value=Mock()), \
            patch.object(DBManager, '__exit__', return_value=None):

            with DBManager(connection_string) as db_session:

                rows = [
                    {
                        "valid_time": parser.parse("2018-04-24T12:45:00-00:00"),
                        "value": 5.61,
                        "lead_interval":  timedelta(0, 0)
                    }
                ]

                index_elements = ["member_metric_id", "valid_time"]

                table = MagicMock()
                table.__table__ = MagicMock()
                table.primary_key.columns.return_value = [
                    "member_metric_id", "valid_time", "value", "lead_interval"
                ]
                DBManager.upsert_rows(db_session, table, rows, index_elements)

                assert mock_pg_insert.assert_called
