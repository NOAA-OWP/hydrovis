"""
This script tests the time series module

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service # Office of Water Prediction
@author Shafiq Rahman
@version 1.2
@date 10/12/2018
"""

import pytest
from dateutil import parser
from collections import OrderedDict

from parser.hmlexceptions import TimeSeriesMissingAttrib
from parser.time_value_pair import TimeValuePair
from parser.time_series import TimeSeries
from parser.metadata import MetaData

from constants import time_value as const_time_value
from constants.database import const_unit


# These time series attributes are used for parametrized test. If in future
# parametrize function start accepting fixture, we can remove this and instead
# use a fixture to get a list of tuples with each tuple having one element set
# to empty.
wfo='ARX'
gage_code='DEHI4'
gage_name='UPPER IOWA RIVER AT DECORAH IA'
name='streamflow'
units='CFS'
category='primary'
time_value_list=[
    TimeValuePair('2018-04-25T11:00:00-00:00', 100.0),
    TimeValuePair('2018-04-25T15:00:00-00:00', 300.0),
    TimeValuePair('2018-04-25T12:00:00-00:00', 200.0)
    ]
pedts='HGIRG'

class TestTimeSeries(object):
    """
    The test suite for TimeSeries class
    """

    @pytest.fixture(scope="module")
    def sample_time_series(self):
        """
        Get a sample time series object
        """

        return TimeSeries(
            wfo='ARX',
            gage_code='DEHI4',
            gage_name='UPPER IOWA RIVER AT DECORAH IA',
            name='streamflow',
            units='CFS',
            category='primary',
            time_value_list=[
                TimeValuePair('2018-04-25T11:00:00-00:00', 100.0),
                TimeValuePair('2018-04-25T15:00:00-00:00', 300.0),
                TimeValuePair('2018-04-25T12:00:00-00:00', 200.0)
            ],
            pedts='HGIRG'
        )

    @pytest.fixture(scope="module")
    def sample_time_value_pair_list(self, sample_time_series):
        """
        Get a sample of time value pair list
        """

        return sample_time_series.time_value_list

    @pytest.fixture(scope="module")
    def sample_time_value_pair_list_with_duplicates(self):
        """
        Get a sample time value pair list with duplicates
        """

        return [
            TimeValuePair('2018-04-24T13:45:00-00:00', 200.0),
            TimeValuePair('2018-04-24T13:45:00-00:00', 100.0),
            TimeValuePair('2018-04-24T18:00:00-00:00', 300.0)
        ]

    @pytest.mark.parametrize(
        "wfo, gage_code, gage_name, name, units, category, time_value_list, pedts", 
        [
            ('', gage_code, gage_name, name, units, category, time_value_list, pedts),
            (wfo, '', gage_name, name, units, category, time_value_list, pedts),
            (wfo, gage_code, gage_name, '', units, category, time_value_list, pedts),
            (wfo, gage_code, gage_name, name, '', category, time_value_list, pedts),
            (wfo, gage_code, gage_name, name, units, '', time_value_list, pedts),
            (wfo, gage_code, gage_name, name, units, category, '', pedts),
            (wfo, gage_code, gage_name, name, units, category, time_value_list, '')
        ]
    )
    def test_raises_exception_for_missing_attribute(self,
        wfo, gage_code, gage_name, name, units, category, time_value_list, pedts
    ):
        """
        Tests for exception if physical element unit is empty

        Time Series constructor requires the units of physical element. It raises
        exception if provided units are empty or None.
        """

        with pytest.raises(TimeSeriesMissingAttrib) as excinfo:
            TimeSeries(
                wfo=wfo,
                gage_code=gage_code,
                gage_name=gage_name,
                name=name,
                units=units,
                category=category,
                time_value_list=time_value_list,
                pedts=pedts
            )

        assert any( [
            x in str(excinfo.value) for x in ['provide','time series'] 
            ]
        )

    @staticmethod
    def test_uniqify(sample_time_value_pair_list_with_duplicates) :
        """
        Tests the uniqify function to get unique time value pairs from time series
        """

        assert all([
            first_pair == second_pair \
            for first_pair, second_pair in zip(
                TimeSeries.uniqify(sample_time_value_pair_list_with_duplicates),
                [
                    TimeValuePair('2018-04-24T13:45:00-00:00', 200.0),
                    TimeValuePair('2018-04-24T18:00:00-00:00', 300.0)
                ]
            )
        ]), "There is at least one TimeValuePair mismatch in provided series"

    def test_get_metadata(self, sample_time_series):
        """
        Test the get_metadata function
        """

        assert sample_time_series.get_metadata() == MetaData(
            wfo='ARX',
            gage_code='DEHI4',
            gage_name='UPPER IOWA RIVER AT DECORAH IA',
            name='streamflow',
            units='KCFS',
            category='primary',
            pedts='HGIRG'
        ), "MetaData mismatch in get_metadata test"

    def test_streamflow_standardize_units(self, sample_time_series):
        """
        Tests streamflow unit standardization for time series

        The standardize_units function gets called in the constructor of
        TimeSeries so units should be standardized in the sample time series
        """

        # check if units field is standardized
        assert sample_time_series.units == const_unit.UNIT_KCFS, \
            "Units mismatch after a call to standardize units function"

        # check actual values to confirm unit transformation
        expected_time_value_list = [
            TimeValuePair('2018-04-25T11:00:00-00:00', 0.1),
            TimeValuePair('2018-04-25T12:00:00-00:00', 0.2),
            TimeValuePair('2018-04-25T15:00:00-00:00', 0.3)
        ]
        assert all([
            received_pair.value == expected_pair.value \
            for received_pair, expected_pair in zip(
                sample_time_series.time_value_list,
                expected_time_value_list
            )
        ]), "Value mismatch after the call to standardize units function"

    def test_metric_values(self, sample_time_series):
        """
        Tests correctness of the list of time-value dictionaries

        It validates the actual values in dictionary as well as the order of
        each dictionary describing a valid time and a value at that time. 
        """

        expected_metric_values = [
            {
                const_time_value.VALID_TIME : 
                    parser.parse('2018-04-25T11:00:00-00:00'),
                const_time_value.VALUE : 0.1
            },
            {
                const_time_value.VALID_TIME : 
                    parser.parse('2018-04-25T12:00:00-00:00'),
                const_time_value.VALUE : 0.2
            },
            {
                const_time_value.VALID_TIME : 
                    parser.parse('2018-04-25T15:00:00-00:00'),
                const_time_value.VALUE : 0.3
            }
        ]

        assert sample_time_series.metric_values() == expected_metric_values, \
            "There is at least one mismatch in metric values list"

    def test_repr(self, sample_time_series):
        """
        Tests the string representation of TimeSeries class
        """

        sample_time_series_str = '<TimeSeries( wfo:ARX, gage: DEHI4, '\
            'category: primary, name: streamflow )>'

        assert str(sample_time_series) == sample_time_series_str