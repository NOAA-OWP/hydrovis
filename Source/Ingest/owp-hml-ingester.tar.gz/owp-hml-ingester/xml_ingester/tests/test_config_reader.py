"""
This script tests the config_reader module.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service # Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 20/03/2018
"""

import pytest

from config.config_reader import ConfigReader
from constants import conf

class TestConfigReader(object):
    """
    The test suite for ConfigReader class
    """

    @pytest.fixture(scope="module")
    def config_reader(self):
        """
        Get the configuration file path for all tests
        """

        config_file = "./ingester.conf"
        return ConfigReader(config_file)

    def test_get_correct_config_value(self, config_reader):
        """
        Test if function correctly parses a config value.
        """
        
        rabbitmq_section = conf.RABBITMQ_SECTION
        exchange_key = conf.RABBITMQ_EXCHANGE
        exchange_value = "hml"

        retrieved_exchange_value = config_reader.get_config_value(
            section=rabbitmq_section,
            parameter_name=exchange_key
        )

        assert retrieved_exchange_value == exchange_value, \
            'Expected config value: ' + exchange_value + ' does not match ' + \
            'retrieved config value: ' + retrieved_exchange_value

    def test_get_nonexisting_config_value(self, config_reader):
        """
        Test when a non-existent config is requested

        The get config value function returns None if a config value is
        requested that does not exist.
        """

        assert not config_reader.get_config_value(
            section='section',
            parameter_name='key'
        ), 'Config value is NOT None'
