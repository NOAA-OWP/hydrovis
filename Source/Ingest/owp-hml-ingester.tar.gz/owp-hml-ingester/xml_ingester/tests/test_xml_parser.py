"""
This module provides tests for the xml parser module

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service # Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/17/2018
"""

import pytest

from xml.etree.ElementTree import ParseError

from parser.hmlexceptions import XMLParseException, TagNotFound, IncorrectTag, \
    IncorrectValue
from parser.xml_parser import XMLParser
from parser.time_value_pair import TimeValuePair
from parser.forecast_time_series import ForecastTimeSeries

from constants import xml

class TestXmlParser(object):
    """
    The test suite for XmlParser class
    """

    @pytest.fixture(scope="module")
    def sample_xml(self):
        """
        Get a sample XML file string
        """

        return '<?xml version="1.0" standalone="yes"?>\
                <site xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\
                    generationtime="2018-04-24T13:39:06+00:00"\
                    timezone="PST8PDT"\
                    originator="STO"\
                    name="Delta  AT Antioch"\
                    id="ATIC1"\
                    xsi:noNamespaceSchemaLocation="http://weather.gov/ohd/hydroxc/schemas/hydrogen/HydData.xsd">\
                <disclaimers>\
                    <AHPSXMLversion>2.0</AHPSXMLversion>\
                    <status>Experimental</status>\
                    <standing trace="forecast" />\
                </disclaimers>\
                <forecast primaryUnits="ft"\
                            pedts="HGIFE"\
                            primaryName="Stage"\
                            timezone="UTC"\
                            issued="2018-04-24T13:22:00-00:00"\
                            secondaryUnits="kcfs"\
                            secondaryName="Flow">\
                    <datum>\
                        <valid>2018-04-24T12:45:00-00:00</valid>\
                        <primary>3.6</primary>\
                        <secondary>5.61</secondary>\
                    </datum>\
                    <datum>\
                        <valid>2018-04-24T18:00:00-00:00</valid>\
                        <primary>5.6</primary>\
                        <secondary>7.61</secondary>\
                    </datum>\
                    <datum>\
                        <valid>2018-04-25T01:30:00-00:00</valid>\
                        <primary>1.8</primary>\
                        <secondary>3.83</secondary>\
                    </datum>\
                </forecast>\
            </site>    '

    @pytest.fixture(scope="module")
    def incomplete_sample_xml(self, sample_xml):
        """
        Get an incomplete xml string
        """

        sample_xml_length = len(sample_xml)
        return sample_xml[ : int( sample_xml_length / 2 )]

    @pytest.fixture(scope="module")
    def sample_xml_parser(self, sample_xml):
        """
        Get an instance of XML Parser
        """

        return XMLParser(
            xml_string=sample_xml
        )

    @pytest.fixture(scope="module")
    def sample_xml_root(self, sample_xml_parser):
        """
        Get the root node of valid xml
        """

        return sample_xml_parser.xml_root_node

    @pytest.fixture(scope="module")
    def sample_forecast_node(self, sample_xml_root):
        """
        Get a sample forecast node under the provided root xml node
        """

        return sample_xml_root.find( xml.TAG_FORECAST )

    @pytest.fixture(scope="module")
    def sample_datum_node(self, sample_forecast_node):
        """
        Get a sample datum node under the provided forecast node
        """

        return sample_forecast_node.find( xml.TAG_DATUM )

    @pytest.fixture(scope="module")
    def sample_valid_time_node(self, sample_datum_node):
        """
        Get a sample forecast node under the provided root xml node
        """

        return sample_datum_node.find( xml.TAG_VALID )

    @pytest.fixture(scope="module")
    def primary_time_value_pairs(self):
        """
        Get expected list of primary TimeValuePairs
        """

        return [
            TimeValuePair('2018-04-24T12:45:00-00:00', 3.6),
            TimeValuePair('2018-04-24T18:00:00-00:00', 5.6),
            TimeValuePair('2018-04-25T01:30:00-00:00', 1.8)
        ]

    @pytest.fixture(scope="module")
    def secondary_time_value_pairs(self):
        """
        Get expected list of secondary TimeValuePairs
        """

        return [
            TimeValuePair('2018-04-24T12:45:00-00:00', 5.61),
            TimeValuePair('2018-04-24T18:00:00-00:00', 7.61),
            TimeValuePair('2018-04-25T01:30:00-00:00', 3.83)
        ]

    @pytest.fixture(scope="module")
    def time_value_pair_tuples(self, primary_time_value_pairs, secondary_time_value_pairs):
        """
        Get a list of tuples with primary and secondary time value pairs
        """

        return zip(primary_time_value_pairs, secondary_time_value_pairs)

    @pytest.fixture(scope="module")
    def first_time_value_pair_tuple(self, time_value_pair_tuples):
        """
        Get the first tuple of primary and secondary time value pairs
        """

        return next(time_value_pair_tuples)


    def test_parse_exeception_for_empty_xml(self):
        """
        Tests that an XML parse exception is thrown for empty xml string
        """

        with pytest.raises(ParseError) as excinfo:
            XMLParser('')

        assert 'no element' in str(excinfo.value)

    def test_parse_exception_for_incomplete_xml(self, incomplete_sample_xml):
        """
        Tests tha an XML parse exception is thrown for incomplete xml string
        """

        with pytest.raises(ParseError) as excinfo:
            XMLParser( incomplete_sample_xml )

        assert any( 
            [
                x in str( excinfo.value ) \
                for x in [ 'not well-formed', 'unclosed token']
            ]
        )


    def test_get_child_with_correct_name(self, sample_xml_root):
        """
        Tests the get child node method with correct node and child name
        """

        observed_node = XMLParser.get_child_node_with_name(
            node=sample_xml_root,
            child_name=xml.TAG_FORECAST
        )

        assert observed_node.tag == xml.TAG_FORECAST

    def test_get_child_with_none_node(self):
        """
        Tests the get child node method with node as None
        """

        with pytest.raises(Exception) as excinfo:
            XMLParser.get_child_node_with_name( 
                node=None,
                child_name=xml.TAG_FORECAST
            )

        assert "Can't find child" in str( excinfo.value )

    def test_get_child_with_empty_child_name(self, sample_xml_root):
        """
        Tests the get child node method with node as None
        """

        with pytest.raises(Exception) as excinfo:
            XMLParser.get_child_node_with_name( 
                node=sample_xml_root,
                child_name=''
            )

        assert "Can't find child" in str( excinfo.value )

    def test_get_child_with_wrong_tag(self, sample_xml_root):
        """
        Tests the get child node method with incorrect tag
        """

        with pytest.raises(TagNotFound) as excinfo:
            XMLParser.get_child_node_with_name(
                node=sample_xml_root,
                child_name='wrong'
            )

        assert 'Could not find' in str( excinfo.value )
    
    def test_get_child_with_non_iterable_node(self, sample_xml_root):
        """
        Tests the get child node method with non iterable node
        """

        with pytest.raises(TypeError) as excinfo:
            XMLParser.get_child_node_with_name(
                node=0,
                child_name='wrong'
            )

        assert 'not iterable' in str( excinfo.value )


    def test_unmarshall_valid_time_when_none(self):
        """
        Tests the unmarshall valid time when provided node is None
        """

        with pytest.raises(TagNotFound) as excinfo:
            XMLParser.unmarshall_valid_time(None)

        assert 'node is None' in str( excinfo.value )

    def test_unmarshall_valid_time_wrong_tag(self, sample_forecast_node):
        """
        Tests the unmarshall valid time method when incorrect node is provided
        """

        with pytest.raises( IncorrectTag ) as excinfo:
            XMLParser.unmarshall_valid_time(sample_forecast_node)

        assert 'wrong tag' in str( excinfo.value )
    
    def test_unmarshall_valid_time(self, sample_valid_time_node):
        """
        Tests a valid time extraction from a valid node
        """

        expected_valid_time = '2018-04-24T12:45:00-00:00'

        assert XMLParser.unmarshall_valid_time(sample_valid_time_node) == \
            expected_valid_time

    
    def test_unmarshall_datum_when_none(self, sample_datum_node):
        """
        Tests unmarshall datum when datum node is Node
        """

        with pytest.raises( TagNotFound ) as excinfo:
            XMLParser.unmarshall_datum( None )

        assert 'datum node is None' in str( excinfo.value )

    def test_unmarshall_datum_wrong_tag(self, sample_forecast_node):
        """
        Tests unmarshall datum when passed datum node is not really a datum node
        """

        with pytest.raises( IncorrectTag ) as excinfo:
            XMLParser.unmarshall_datum( sample_forecast_node )

        assert 'wrong tag' in str( excinfo.value )

    def test_unmarshall_datum(
        self,
        sample_datum_node,
        first_time_value_pair_tuple
        ):
        """
        Tests whether a valid datum got parsed correctly or not

        The test expects the function to return a tuple of TimeValuePairs one
        for primary and secondary with valid time incorporated in both pairs.
        """

        assert first_time_value_pair_tuple == \
            XMLParser.unmarshall_datum( sample_datum_node )


    def test_parse_datums_when_node_is_none(self):
        """
        Tests if parse datums returns None if node is None
        """

        assert XMLParser.parse_datums(None) is None

    def test_parse_datums_tag_unexpected(self, sample_valid_time_node):
        """
        Tests if parse datums returns None if tag is niether forecast or observed
        """

        assert XMLParser.parse_datums(sample_valid_time_node) is None

    def test_parse_datums(
            self,
            sample_forecast_node, 
            primary_time_value_pairs,
            secondary_time_value_pairs    
            ):
        """
        Tests if parsing a forecast tags works as expected
        """

        assert all(
            [
                primary_pair_list == secondary_pair_list \
                for primary_pair_list, secondary_pair_list in zip(
                    XMLParser.parse_datums(sample_forecast_node),
                    (primary_time_value_pairs, secondary_time_value_pairs)
                )
            ]
        )


    def test_get_secondary_pedts_for_primary_stage_pedts(self):
        """
        Tests conversion of primary pedts for stage to secondary pedts
        """

        primary_stage_pedts = 'HGIRG'

        assert XMLParser.get_secondary_pedts(
            primary_pedts=primary_stage_pedts,
            secondary_name=xml.FLOW
        ) == 'QRIRG'

    def test_get_secondary_pedts_for_primary_flow_pedts(self):
        """
        Tests conversion of primary pedts for flow to secondary pedts
        """

        primary_stage_pedts = 'QRIRG'

        assert XMLParser.get_secondary_pedts(
            primary_pedts=primary_stage_pedts,
            secondary_name=xml.STAGE
        ) == 'HGIRG'
    

    @pytest.mark.skip(reason="No reason to test because parsing observation will be removed")
    def test_parse_observation(self):
        """
        Tests observation parsing 
        """

        pass

    def test_parse_forecasts(
        self,
        sample_xml_parser,
        primary_time_value_pairs,
        secondary_time_value_pairs
    ):
        """
        Tests the time series received from parse_forecast with expected ones
        """

        primary_timeseries = ForecastTimeSeries(
            wfo='STO',
            gage_code='ATIC1',
            gage_name='Delta  AT Antioch',
            issued_time='2018-04-24T13:22:00-00:00',
            name='stage',
            units='ft',
            category=xml.TAG_PRIMARY,
            time_value_list=primary_time_value_pairs,
            pedts='HGIFE'
            )
        secondary_timeseries = ForecastTimeSeries(
            wfo='STO',
            gage_code='ATIC1',
            gage_name='Delta  AT Antioch',
            issued_time='2018-04-24T13:22:00-00:00',
            name='flow',
            units='kcfs',
            category=xml.TAG_SECONDARY,
            time_value_list=secondary_time_value_pairs,
            pedts='QRIFE'
            )

        assert (
            primary_timeseries,
            secondary_timeseries
            ) == sample_xml_parser.parse_forecasts()
        