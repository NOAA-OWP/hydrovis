# XML Ingester

XML ingester, as the name suggests, is designed to parse XML files received
from RabbitMQ instance and load their contents into Postgres database.

## Getting Started

In order to get started, you will need to clone the repository from VLAB which
I assume you already have as you are reading this.

Populate the `.env.prod` file located in splitter directory and run following
command to import environment variables defined in that file:

```
set -a; source .env.prod; set +a
```

Assuming that you have an instance of RabbitMQ running, and you have provided
all the environment variables listed in .env.prod correctly, you can run the
python application as following:

```
./xml_ingester.py
```

### Testing

In order to test the xml ingester, you need to install development version of
python packages installed i.e.:
```
pip install -r requirements-dev.txt
```
This will install all application dependencies as well as pytest and pytest-cov
that we will use below to run tests and generate test coverage report. Please 
note that some sub-directories like tests/ and constants/ are excluded from 
tests in `.coveragerc` file.

You can run the tests and see coverage report as following:
```
pytest  --cov=.  tests/
```

If you just want to run tests:
```
pytest
```

### Prerequisites

The HTMLSplitter required at least Python 3 to be able to use context manager for
fileinput module. You can check the version of python using:
```
python --version
```

You will also need to install following pip packages:
* configreader    (for reading config file)
* pika            (for communicating with RabbitMQ)
* psycopg2        (for communicating with Postgres)
* python-datautil (for parsing datetime from string)
* SQLAlchemy      (for ORM level functions)

You can install them using:
```
pip install -r requirements.txt
```

The other important thing is that you need to either install and run RabbitMQ
instance or provide a url in `splitter.conf` file for an existing instance. The
environment variables in the url must be defined in the `.env` file. You can
install [RabbitMQ](https://packagecloud.io/rabbitmq/rabbitmq-server/) server
for RPM based linux. The RabbitMQ depends on erlang and a minimal erlang
installation can be done by fllowing instructions on this 
[link]( https://packagecloud.io/install/repositories/rabbitmq/erlang/script.rpm.sh).

## Deployment

--*Virtual Machine*--

If you are using virtual environment for Python 3.4, source the activate script
of virtual environment and then run the program as described in Getting Started
section.

--*Docker*--

This application comes with a `Dockerfile` that can be used to build an image
and deploy the application in a docker container. Here are the minimal set of
commands that can be used to run the application in docker container:

```
cd /opt/xml_ingester
docker build --tag hml_xml_ingester:latest .
docker images
docker run --env-file .env.prod --restart 'always' --detach hml_xml_ingester:latest
docker ps
```

