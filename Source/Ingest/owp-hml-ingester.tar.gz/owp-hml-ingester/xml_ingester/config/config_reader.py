"""
This class is used to parse the configuration file contents


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/31/2017
"""

# Import system libraries
import logging
from configparser import SafeConfigParser, NoOptionError, NoSectionError
import os

# local modules
from constants import app, conf

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class ConfigReader(object):

    def __init__(self, config_file):

        # path to the config file
        self.config_file = config_file

    def get_config_value(self, section, parameter_name):
        """
        Get value of a configuration parameter in specified section

        Args:
            section: The section to search from in configuration file
            parameter_name: The name of the parameter we are searching for
        Returns:
            String value of the parameter or None if not found
        """

        try:

            configuration = SafeConfigParser(os.environ)
            configuration.read(self.config_file)
            value = configuration.get(section, parameter_name )
        except (NoSectionError, NoOptionError) as err:

            logger.warning(err)
            return None

        return value

    def read_conf_rabbitmq( self ):
        '''
        Parse the rabbitmq section of configuration file

        Args:
            There are no arguments

        Returns:
            A tuple with connection url to rabbitmq node. Keeping tuple for
            ease of extensibility

        Raises:
            Exception: if url is missing
        '''

        # make sure user specified url parameter
        rabbitmq_url = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_URL
            )

        if rabbitmq_url is None:
            raise Exception(
                "You must provide url to RabbitMQ node/cluster. Aborting!"
                )

        # get exchange name specified
        rabbitmq_exchange = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_EXCHANGE
            )

        if rabbitmq_exchange is None:
            raise Exception(
                "You must provide name of RabbitMQ exchange. Aborting!"
                )

        # get xml queue anme specified
        rabbitmq_xml_queue = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_XML_QUEUE
            )

        if rabbitmq_xml_queue is None:
            raise Exception(
                "You must provide RabbitMQ queue name to send XML messages to. "\
                "Aborting!"
                )

        # get prefetch count for a channel/consumer
        rabbitmq_xml_prefetch_count = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_XML_PREFETCH_COUNT
        )

        try:
            rabbitmq_xml_prefetch_count = int(rabbitmq_xml_prefetch_count)
        except ValueError:
            raise Exception(
                "You must provide an integer prefetch count for xml queue. Aborting!"
            )

        # xml message time to live in xml dead-letter-queue
        rabbitmq_xml_message_ttl = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_DL_XML_MESSAGE_TTL
        )

        try:
            rabbitmq_xml_message_ttl = int( rabbitmq_xml_message_ttl )
        except ValueError:
            raise Exception(
                "You must provide an integer xml message time to live "\
                "for xml queue. Aborting!"
            )

        return (
            rabbitmq_url,
            rabbitmq_exchange,
            (
                rabbitmq_xml_queue,
                rabbitmq_xml_prefetch_count,
                rabbitmq_xml_message_ttl
            )
        )


    def read_conf_db( self ):
        '''
        Parse the database section of configuration file

        Args:
            Ther are no arguments

        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get database connection string
        conf_connection_string = self.get_config_value(
            conf.DATABASE_SECTION,
            conf.DATABASE_CONNECTION_STRING
        )

        return (conf_connection_string, )


    def read_conf_log( self ):
        '''
        Parse the log section of configuration file

        Args:
            Theere are no arguments

        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get log debug level
        conf_log_level = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_LEVEL
        )

        # log to file|stream
        log_output_to = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_TARGET
        )

        # log file, if applicable
        log_file = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_FILE_PATH
        )

        return (conf_log_level, log_output_to, log_file)


    def read_configs( self ):
        '''
        This function parses all configuration parameters

        The function reads all sections of the configuration file and return a tuple
        containing the tuples one for each section.

        Returns:
            A tuple of tuples each corresponding to a configuration section
        Raises:
            Exception: if any of the section parser raises exception
        '''

        # rabbitmq section
        conf_rabbitmq = self.read_conf_rabbitmq()

        # database section
        conf_database = self.read_conf_db()

        # log section
        conf_log = self.read_conf_log()

        return (conf_rabbitmq, conf_database, conf_log)

