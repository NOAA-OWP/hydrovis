#!/bin/bash

env_file=".env.dev"
if [[ "$1" == 'p' ]]; then
    env_file=".env.prod"
fi

source ~/activate_venv_3.4
set -a; source "$env_file"; set +a;

env | grep "^R"
echo ""
env | grep "^DB"
./xml_ingester.py
