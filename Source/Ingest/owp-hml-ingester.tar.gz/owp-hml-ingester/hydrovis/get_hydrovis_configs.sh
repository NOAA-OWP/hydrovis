#!/bin/bash
############################################################################
#
#  get_aws_configs.sh <environment>
#
#  This script gets configuration information for the specified environment,
#  such as "dev" or "ti".
#
#  History:
#  Anders Nilsson, UCAR, 2021-09-29, Created
#
############################################################################

### Constants ###

PROJECT="hydrovis"
REGION="us-east-1"
MODULE="ingest"
DBPASSWORD=
RPASSWORD=

### Get arguments ###

INSTANCE=$1

if [ -z "${INSTANCE}" ]
then
  echo "An instance type needs to be specified, like 'dev' or 'ti'" 1>&2
  exit 1
fi

### Get PostgreSQL endpoint location ###
DBHOST=$(aws rds describe-db-instances --query \
         "DBInstances[?DBInstanceIdentifier==\`${PROJECT}-${INSTANCE}-ingest\`].Endpoint.Address" \
         --output text --region ${REGION})

### Get RabbitMQ endpoint location ###

BROKER_ID=$(aws mq list-brokers --query \
            "BrokerSummaries[?BrokerName==\`${PROJECT}-${INSTANCE}-dataingest-rabbitmq\`].BrokerId" \
            --output text --region ${REGION})

if [ -n "${BROKER_ID}" ]
then
  RENDPOINT=$(aws mq describe-broker --broker-id ${BROKER_ID} --query \
              'BrokerInstances[0].Endpoints' --output text --region ${REGION})
fi
if [ -n "${RENDPOINT}" ]
then
  RSCHEME="${RENDPOINT/:*}"
  RPORT="${RENDPOINT##*:}"
  RHOST=$(echo ${RENDPOINT} | cut -d : -f 2 | tr -d "/")
fi

### Get PostgreSQL password from secrets ###
SECRET=$(aws secretsmanager get-secret-value \
         --secret-id "hydrovis-ingest-postgresql-access" --region ${REGION})
if [ -n "${SECRET}" ]
then
  DBPASSWORD=$(echo "${SECRET}" | \
               python -c "import sys, json; \
                          print (json.load(sys.stdin)['SecretString'])")
fi


### Get RabbitMQ password from secrets ###
SECRET=$(aws secretsmanager get-secret-value \
         --secret-id "hydrovis-ingest-rabbitmq-access" --region ${REGION})
if [ -n "${SECRET}" ]
then
  RPASSWORD=$(echo "${SECRET}" | \
               python -c "import sys, json; \
                          print (json.load(sys.stdin)['SecretString'])")
fi

### Output ###

echo "${RHOST}"
echo "${RPASSWORD}"
echo "${DBHOST}"
echo "${DBPASSWORD}"
