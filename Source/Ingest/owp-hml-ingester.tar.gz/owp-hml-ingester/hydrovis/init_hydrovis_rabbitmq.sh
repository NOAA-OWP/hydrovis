#!/bin/bash
############################################################################
#
#  init_hydrovis_rabbitmq <instance>
#
#  This script initializes the contents of the rabbitmq system.
#
#  History:
#  Anders Nilsson, UCAR, 2021-10-01, Created
#
############################################################################

### Constants ###

PROJECT="hydrovis"
REGION="us-east-1"

### Get current directory ###
DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

### Get arguments ###
INSTANCE=$1
if [ -z "${INSTANCE}" ]
then
  echo "An instance type needs to be specified, like 'dev' or 'ti'" 1>&2
  exit 1
fi

### Construct RabbitMQ definitions file path ###
DEFINITIONS_FILE="${DIR/\/hydrovis}/rabbitmq/definitions_${INSTANCE}.json"
if [ ! -f "${DEFINITIONS_FILE}" ]
then
  echo "The RabbitMQ definitions file \"${DEFINITIONS_FILE}\" is not present." 1>&2
  exit 1
fi

### Get RabbitMQ Endpoint ###

BROKER_NAME="${PROJECT}-${INSTANCE}-dataingest-rabbitmq"
BROKER_ID=$(aws mq list-brokers --query \
            "BrokerSummaries[?BrokerName==\`${BROKER_NAME}\`].BrokerId" \
            --output text --region ${REGION})

if [ -n "${BROKER_ID}" ]
then
  RENDPOINT=$(aws mq describe-broker --broker-id ${BROKER_ID} --query \
              'BrokerInstances[0].Endpoints' --output text --region ${REGION})
else
  echo "No broker found with the name ${BROKER_NAME}" 1>&2
  exit 1
fi

if [ -n "${RENDPOINT}" ]
then
  RSCHEME="${RENDPOINT/:*}"
  RPORT="${RENDPOINT##*:}"
  RHOST=$(echo ${RENDPOINT} | cut -d : -f 2 | tr -d "/")
else
  echo "No endpoint found for broker ID ${BROKER_ID}" 1>&2
  exit 1
fi

### Get RabbitMQ admin authentication information ###

SECRET=$(aws secretsmanager get-secret-value \
         --secret-id "hydrovis-${INSTANCE}-dataingest-mqsecret" --region ${REGION})
if [ -n "${SECRET}" ]
then
  RAUTHINFO=$(echo "${SECRET}" | \
             python -c "import sys, json; \
                          print (json.load(sys.stdin)['SecretString'])")
fi
if [ -n "${RAUTHINFO}" ]
then
  RUSERNAME=$(echo "${RAUTHINFO}" | \
             python -c "import sys, json; print (json.load(sys.stdin)['username'])")
  RPASSWORD=$(echo "${RAUTHINFO}" | \
             python -c "import sys, json; print (json.load(sys.stdin)['password'])")
fi

# Update definitions. It is OK if this runs more than once.
echo "Attempting to update https://${RHOST}/api/definitions with ${DEFINITIONS_FILE}..."
curl -H "Accept:application/json" -u ${RUSERNAME}:${RPASSWORD} \
     -F "file=@${DEFINITIONS_FILE}" "https://${RHOST}/api/definitions"

