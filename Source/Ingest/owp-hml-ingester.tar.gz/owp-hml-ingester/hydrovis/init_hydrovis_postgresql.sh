#!/bin/bash
############################################################################
#
#  init_hydrovis_postgresql <instance>
#
#  This script tests to see if the database has been created for the 
#  HML Ingest process, and if it has not the script will create it./
#
#  History:
#  Anders Nilsson, UCAR, 2021-10-04, Created
#
############################################################################

### Check HOME ###
if [ -z "${HOME}" ] && [ "$(whoami)" = "root" ]
then
  HOME="/root"
fi

### Constants ###

PROJECT="hydrovis"
REGION="us-east-1"
DBNAME="rfcfcst"
DBUSERS="rfc_fcst, rfc_fcst_ro"
PGPASS="${HOME}/.pgpass"
PGPORT=5432
DEPLOYMENT_BUCKET="${PROJECT}-dev-ti-ingest-deployment-${REGION}"
USERS_SCRIPT="rfcfcst_users.sql"
BASE_SCRIPT="rfcfcst_base.sql.gz"
DOWNLOAD_DIRECTORY="${HOME}/postgres_data"
BASE_FILE="${DOWNLOAD_DIRECTORY}/${BASE_SCRIPT}"
USERS_FILE="${DOWNLOAD_DIRECTORY}/${USERS_SCRIPT}"
DROP_DATABASE=0
REMOVE_BASE_FILE=0
REMOVE_USERS_FILE=0
REMOVE_DIRECTORY=0

### Clean up after an error ###
function cleanup()
{
  ERROR=$1

  # Stop signal/error handling
  trap - SIGHUP SIGINT SIGTERM ERR

  ### Clean up database ###
  if [ ${DROP_DATABASE} -ne 0 ]
  then
    echo "Dropping database ${DBNAME}..."
    psql -h "${PGHOST}" -U "${PGUSERNAME}" -c "DROP DATABASE ${DBNAME}"
    DROP_DATABASE=0
  fi

  # Remove downloads
  if [ ${REMOVE_BASE_FILE} -ne 0 ]
  then
    rm -f "${BASE_FILE}"
    REMOVE_BASE_FILE=0
  fi
  if [ ${REMOVE_USERS_FILE} -ne 0 ]
  then
    rm -f "${USERS_FILE}"
    REMOVE_USERS_FILE=0
  fi
  if [ "${REMOVE_DIRECTORY}" -ne 0 ]
  then
    rmdir "${DOWNLOAD_DIRECTORY}"
    REMOVE_DIRECTORY=0
  fi

  ### Error ### 
  exit ${ERROR}
}

### Create/validate pgpass file ###
function create_pgpass()
{
  local FOUND=0
  local PGPASSLINE="${PGHOST}:*:*:${PGUSERNAME}:${PGPASSWORD}"
  ### Check to see if file is present, and if so, validate it ###
  if [ -f "${PGPASS}" ]
  then
    while IFS= read -r LINE
    do
      if [ "${LINE}" = "${PGPASSLINE}" ]
      then
        FOUND=1
        break 
      fi
    done < "${PGPASS}"
    if [ ${FOUND} -eq 0 ]
    then
      echo "Appending line to ${PGPASS}"
      echo "${PGPASSLINE}" >> "${PGPASS}"
    else
      echo "Matching entry found in ${PGPASS}. No need to modify."
    fi
  else
    echo "Creating new ${PGPASS}..."
    echo "${PGPASSLINE}" > "${PGPASS}"
  fi

  chmod 600 "${PGPASS}"
}


### Get current directory ###
DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

### Get arguments ###
INSTANCE=$1
if [ -z "${INSTANCE}" ]
then
  echo "An instance type needs to be specified, like 'dev' or 'ti'" 1>&2
  exit 1
fi

### Set up signal/error handling ###

trap "cleanup 1" SIGHUP SIGINT SIGTERM ERR
trap "cleanup 0" EXIT

### Get PostgreSQL endpoint location ###
PGHOST=$(aws rds describe-db-instances --query \
         "DBInstances[?DBInstanceIdentifier==\`${PROJECT}-${INSTANCE}-ingest\`].Endpoint.Address" \
         --output text --region ${REGION})

### Get PostgreSQL admin authentication information ###

SECRET=$(aws secretsmanager get-secret-value \
         --secret-id "hydrovis-${INSTANCE}-ingest-pg-rdssecret" --region ${REGION})
if [ -n "${SECRET}" ]
then
  PGAUTHINFO=$(echo "${SECRET}" | \
               python -c "import sys, json; \
                          print (json.load(sys.stdin)['SecretString'])")
fi
if [ -n "${PGAUTHINFO}" ]
then
  PGUSERNAME=$(echo "${PGAUTHINFO}" | \
               python -c "import sys, json; print (json.load(sys.stdin)['username'])")
  PGPASSWORD=$(echo "${PGAUTHINFO}" | \
               python -c "import sys, json; print (json.load(sys.stdin)['password'])")

  # The host could also be fetched from here, if desired.
fi

# Create PGPASS
create_pgpass

# Check to see if the database already exists #
echo "Checking to see if database ${DBNAME} exists..."
EXISTS=$( psql -h ${PGHOST} -U "${PGUSERNAME}" -p ${PGPORT} \
          -tAc "select datname from pg_database where datname = '${DBNAME}'")

# Database already exists?
if [ -z "${EXISTS}" ]
then
  echo "Database ${DBNAME} does not exist. Creating"
  # Check download directory
  if [ ! -d "${DOWNLOAD_DIRECTORY}" ]
  then
    mkdir -p "${DOWNLOAD_DIRECTORY}"
    REMOVE_DIRECTORY=1
  fi

  # Check if files already present
  if [ -f "${BASE_FILE}" ]
  then
    echo "Base file ${BASE_FILE} already exists. Halting." 1>&2
    exit 1
  fi
  if [ -f "${USERS_FILE}" ]
  then
    echo "Users file ${USERS_FILE} already exists. Halting." 1>&2
    exit 1
  fi

  # Download database contents
  echo "Downloading s3://${DEPLOYMENT_BUCKET}/${BASE_SCRIPT}..."
  aws s3 cp s3://${DEPLOYMENT_BUCKET}/${BASE_SCRIPT} ${DOWNLOAD_DIRECTORY}/
  REMOVE_BASE_FILE=1
  echo "Downloading s3://${DEPLOYMENT_BUCKET}/${USERS_SCRIPT}..."
  aws s3 cp s3://${DEPLOYMENT_BUCKET}/${USERS_SCRIPT} ${DOWNLOAD_DIRECTORY}/
  REMOVE_USERS_FILE=1

  # Uncompress
  gzip -d "${BASE_FILE}"
  BASE_FILE="${BASE_FILE/.gz}"

  # Create database
  echo "Creating database..."
  psql -h "${PGHOST}" -U "${PGUSERNAME}" -p ${PGPORT} -tAc "CREATE DATABASE ${DBNAME}"
  DROP_DATABASE=1

  # Update users
  echo "Creating users..."
  psql -h "${PGHOST}" -U "${PGUSERNAME}" -p ${PGPORT} -d "${DBNAME}" \
       -f "${USERS_FILE}"

  # Updating permissions
  echo "Granting database level permissions..."
  psql -h "${PGHOST}" -U "${PGUSERNAME}" -p ${PGPORT} -d "${DBNAME}" \
       -tAc "GRANT CONNECT ON DATABASE ${DBNAME} to ${DBUSERS};
             COMMENT ON DATABASE ${DBNAME} IS 
             'database for storing river forecasts';"

  # Create database and table schemas
  echo "Creating database ${DBNAME} on ${PGHOST}..."
  psql -h "${PGHOST}" -U "${PGUSERNAME}" -p ${PGPORT} -d "${DBNAME}" \
       -f "${BASE_FILE}"
  DROP_DATABASE=0

else
  echo "Database ${DBNAME} already exists on ${PGHOST}"
fi

# Done

