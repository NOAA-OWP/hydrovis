# This is only used if docker-compose is not available
sudo docker run -d --restart=always --name wrds_hml_cleaner wrds_hml_cleaner
