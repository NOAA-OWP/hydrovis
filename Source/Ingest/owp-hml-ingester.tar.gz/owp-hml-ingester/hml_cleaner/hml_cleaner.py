#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################

""" This removes old records from database tables as configured by config
    files
"""

# Global system imports
import logging
import sys
import psycopg2

# Local imports
from utilities.Busy_file import Busy_file
from utilities import Exceptions
from utilities.Global_config import Global_config
from utilities.setup import init_logging
from utilities.setup import set_logging_options
from utilities.setup import setup_arguments

# Global logger instance
logger = logging.getLogger()

##############################################################################
#
#  "Main"
#
##############################################################################
def main():
    """ Main

    This program loops through a list of configured tables and removes
    old records.

    Args:
        None (see utilities.setup.setup_arguments for command line arguments)

    Returns:
        None

    Exceptions:
        None
    """

    try:
        program_description = ('This program loops through a list of '
                               'configured tables and removes ' "\n"
                               'old records.')

        epilogue = ('The global configuration file has the following fields:'
                    "\n\n"
                    'connection_string = <database connection string>' "\n"
                    'database_schema   = <database search path>' "\n"
                    'clean_tables      = <a comma-delimited list of tables'
                    ' to clean>' "\n"
                    'clean_columns     = <a comma-delimited list of columns'
                    ' to filter by,' "\n"
                    '                     one for each table to clean>' "\n"
                    'clean_days        = <a comma-delimited list of days'
                    ' after which' "\n"
                    '                     the records will be removed>' "\n")

        # Set up logging
        init_logging()

        # Get command line arguments
        # This can raise SystemExit if the help option is requested
        options = setup_arguments(program_description, epilogue)

        # Further configure logging
        set_logging_options(options)

        # Hardcoded constants from config file
        constants = Global_config(options.config_pathname)

        # Check to see if other processes are running
        # If not specified by command line arguments, this will do nothing
        busy = Busy_file(options.pidfile)

        # Open connection to database and set search_path
        conn = psycopg2.connect(constants.database_connection_string)
        conn.autocommit = True
        if constants.database_schema:
            cursor = conn.cursor()
            cursor.execute('SET search_path to %s',
                           [constants.database_schema])

        # Do work
        for task in constants.clean_tasks:

            logger.info('Removing records older than %s from table %s',
                        task.datetime_value, task.table_name)

            records = task.clean(conn)

            logger.info('Removed %s records from table %s',
                        records, task.table_name)

        # Terminate logging interface. This might be automatic
        logging.shutdown()

        # Success
        return

    except SystemExit:
        return
    except KeyboardInterrupt:
        logger.warning('KeyboardInterrupt encountered')
        return
    except BaseException:

        # The database connection will automatically be closed at destruction
        # Log any exception message
        logger.error(Exceptions.format_current_exception())

        # Terminate logging interface. This might be automatic
        logging.shutdown()

        # Busy lock file should destruct normally

        # Failure
        sys.exit(1)

# Is this main?
if __name__ == "__main__":
    main()
