# This is only used if docker-compose is not available.
# The instance argument can either be prod or dev
docker build -t wrds_hml_cleaner:latest -f Dockerfile --build-arg instance=dev .

