#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################
""" This contains methods to set up logging and command-line parsing
"""
# Global system imports
from argparse import ArgumentParser, RawDescriptionHelpFormatter
import logging
import socket

# Global default constants

__version__ = '1.0'

# Format for logged messages
DEFAULT_LOG_FORMAT = '%(asctime)s ' + socket.gethostname() + \
                     ' %(filename)s[%(process)d]: %(levelname)s: %(message)s'

# Format for the dates used in logged messages
DEFAULT_DATE_FORMAT = '%Y-%m-%d %H:%M:%S %Z'

#  Level of messages that are written to the log
DEFAULT_LEVEL = logging.INFO

############################################################################
#
#  setup_arguments
#
############################################################################
def setup_arguments(program_description,
                    epilogue):
    """ Configure command line parser

    This method configures the command line argument parser and help message.

    Args:
        program_description (str): A description of the program that occurs
            before the command line options.
        epilogue (str): The part of the help documentation that falls after
            the command line arguments

    Returns:
        A namespace containing all set configuration options

    Exceptions:
        None
    """
    # Get command line arguments
    parser = ArgumentParser(description=program_description,
                            epilog=epilogue,
                            formatter_class=RawDescriptionHelpFormatter)

    # Get global configuration file location from the command line
    parser.add_argument('config_pathname',
                        action='store',
                        type=str,
                        help='Global configuration file. ' + \
                             'This is required.')

    # Unique option
    parser.add_argument('-p',
                        '--pidfile',
                        action='store',
                        type=str,
                        dest='pidfile',
                        help='Enforce unique processing using '
                             ' lock file PIDFILE',
                        metavar='PIDFILE')

    # Get version information
    parser.add_argument('--version',
                        action='version',
                        version='%(prog)s ' + str(__version__),
                        help='Display version number')

    # Log message filtering by level
    parser.add_argument('-v',
                        '--verbose',
                        action='store_true',
                        dest='verbose',
                        help='Display all info messages')

    parser.add_argument('-q',
                        '--quiet',
                        action='store_true',
                        dest='quiet',
                        help='Display only error messages')

    # Additional logging options
    parser.add_argument('-s',
                        '--syslog',
                        dest='log_facility',
                        action='store',
                        type=str,
                        help='Route logging messages to syslog facility FACILITY',
                        metavar='FACILITY')
    parser.add_argument('-l',
                        '--log',
                        dest='log_file',
                        action='store',
                        type=str,
                        help='Route logging messages to log file LOGFILE',
                        metavar='LOGFILE')

    # This can exit if the help option is requested
    return parser.parse_args()

############################################################################
#
#  init_logging
#
############################################################################
def init_logging():
    """ Initialize logging setup

    This method intializes logging for the program.

    Args:
        None

    Returns:
        None

    Exceptions:
        None
    """
    # Set up logging
    logging.basicConfig(format=DEFAULT_LOG_FORMAT,
                        datefmt=DEFAULT_DATE_FORMAT)


############################################################################
#
#  set_logging_options
#
############################################################################
def set_logging_options(options):
    """ Set logging options

    This method toggles any logging options set from the command line.

    Args:
        options (namespace argparse return) A namespace containing set
            variables from the command line. This is returned from the
            parse_args() method.

    Returns:
        None

    Exceptions:
        None
    """

    # Get logger
    logger = logging.getLogger()

    # Verbose logging?
    if options.verbose:
        log_level = logging.DEBUG
    elif options.quiet:
        log_level = logging.WARNING
    else:
        log_level = DEFAULT_LEVEL

    logger.setLevel(log_level)

    # Set up other logging destinations
    formatter = logging.Formatter(DEFAULT_LOG_FORMAT,
                                  datefmt=DEFAULT_DATE_FORMAT)

    if options.log_facility:
        syshandler = logging.handlers.SysLogHandler(facility=options.log_facility)
        syshandler.setFormatter(formatter)
        logger.addHandler(syshandler)
    if options.log_file:
        filehandler = logging.FileHandler(options.log_file)
        filehandler.setFormatter(formatter)
        logger.addHandler(filehandler)
