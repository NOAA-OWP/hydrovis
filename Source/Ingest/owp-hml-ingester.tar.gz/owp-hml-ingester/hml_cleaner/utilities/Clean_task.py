#!/usr/bin/python
#####################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
#####################################################################
""" This module contains the Clean_task class, which represents a 
single table to be cleaned.
"""

# Global imports
from datetime import datetime, timedelta
import psycopg2

######################################################################
#
#  Clean_task
#
######################################################################

class Clean_task(object):
    """ Clean_task class

    This class represents a potential table cleaning action to perform. It
    includes a table name, a column to filter by, and a maximum_value to 
    set the upper bounds of the records to be removed.
    """

    ####################################################################
    #
    #  __init__
    #
    ###################################################################
    def __init__(self,
                 table_name,
                 column_name,
                 datetime_value):
        """ Clean_task class constructor

        Args:
            table_name (str): The name of the table to be cleaned
            column_name (str): The table column name that defines the
                cleaning filter
            datetime_value (datetime datetime obj): A constraining date
                used by the cleaning filter on the table to be cleaned

        Exceptions:
            None

        """
        self.table_name = table_name
        self.column_name = column_name
        self.datetime_value = datetime_value

    #####################################################################
    #
    #  clean
    #
    #####################################################################
    def clean(self,
              conn):
        """ Remove old records from a database table

        This method removes old records from a database table, as defined
        by a table_name, column_name, datetime triple.

        Args:
            conn (namespace psycopg2 Connection): An opened database connection

        Returns:
            The number of removed rows

        Exceptions:
            None
        """

        # Construct cursor
        cursor = conn.cursor()

        # Construct run statement
        cursor.execute('DELETE FROM ' + self.table_name +
                       ' WHERE ' + self.column_name + ' < %s',
                       [self.datetime_value])

        return cursor.rowcount
