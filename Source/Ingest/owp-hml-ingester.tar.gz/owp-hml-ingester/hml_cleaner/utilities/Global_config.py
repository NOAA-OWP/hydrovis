#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################
""" This contains a class for reading the global configuration file
"""
# Global imports
import ConfigParser
from datetime import timedelta, datetime

# Local imports
from Clean_task import Clean_task

###############################################################################
#
#  Global_config
#
###############################################################################
class Global_config(object):
    """ Read global config file class

    This class read high level program configuration paramters from a
    configuration file
    """

    ###########################################################################
    #
    #  __init__
    #
    ###########################################################################

    def __init__(self,
                 config_pathname):
        """ Global_config class constructor

        This creates a Global_config object. This exists just to read and store
        global parameters.

        Args:
            config_pathname (str): The file path to a config file

        Exceptions:
            None

        """

        self.clean_tasks = []
        self.database_connection_string = ''
        self.database_schema = ''

        # Populate internal values with data from config file
        self.read_config_file(config_pathname)

    ###########################################################################
    #
    #  read_string_parameters
    #
    ###########################################################################
    def read_string_parameters(self,
                               config,
                               section):
        """ Read the string type parameters from the configuration file

        This method reads the various string parameters from an earlier
        specified parameter file.

        Args:
            config (namespace ConfigParser ConfigParser obj): An already created
                configuration file parsing object
            section (str): The section name in the configuration file

        Returns:
            None

        Exceptions:
            None
        """
        if config.has_option(section, 'connection_string'):
            self.database_connection_string = \
                config.get(section, 'connection_string').strip('"\'')

        if config.has_option(section, 'database_schema'):
            self.database_schema = \
                config.get(section, 'database_schema').strip('"\'')

    ###########################################################################
    #
    #  read_list_parameters
    #
    ###########################################################################
    def read_list_parameters(self,
                             config,
                             section):
        """ Read the list parameters from the configuration file
            
        This method reads a trio of configuration parameters that define
        a list of tables to clean.

        Args:
            config (namespace ConfigParser ConfigParser obj): An already created
                configuration file parsing object
            section (str): The section name in the configuration file

        Returns:
            None

        Exceptions:
            None
        """

        clean_tables = []
        clean_columns = []
        clean_days = []

        # Make sure that config line is present and set to something
        if config.has_option(section, 'clean_tables'):
            clean_tables = config.get(section,
                                      'clean_tables').strip('"\'').split(',')

        if config.has_option(section, 'clean_columns'):
            clean_columns = config.get(section,
                                       'clean_columns').strip('"\'').split(',')

        if config.has_option(section, 'clean_days'):
            clean_days = config.get(section,
                                    'clean_days').strip('"\'').split(',')

        # Will only go as far as the smallest list. Ideally, they should
        # have the same size.
        for index in range(min(len(clean_tables), len(clean_columns),
                               len(clean_days))):

            # Construct removal date
            clean_date = datetime.utcnow() - \
                         timedelta(days=int(clean_days[index].strip()))

            self.clean_tasks.append( Clean_task( clean_tables[index].strip(),
                                                 clean_columns[index].strip(),
                                                 clean_date ) )

    ###########################################################################
    #
    #  read_config_file
    #
    ###########################################################################
    def read_config_file(self,
                         config_pathname):
        """ Read the configuration file

        This method reads the configuration file, and populates class values.

        Args:
            config_pathname (str): The file path to a config file.

        Exceptions:
            ValueError if unable to read config file
        """

        config = ConfigParser.ConfigParser()

        if config.read(config_pathname) != [config_pathname]:
            raise ValueError('Unable to read config file "' +
                             config_pathname + '"')

        # Get list of sections
        sections = config.sections()

        for section in sections:

            # Get string configuration parameters
            self.read_string_parameters(config, section)

            # Get list configuration parameters
            self.read_list_parameters(config, section)
