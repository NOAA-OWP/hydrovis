#!/bin/bash
###############################################################################
#
#  This contains several functions that are handy when dealing with log files.
#
#  History:
#  Anders Nilsson, UCAR, 06/06/16, Created
#  Anders Nilsson, UCAR, 07/06/16, get_log_file_contents sets IFS to load
#                                  each line rather than each word
#  Anders Nilsson, UCAR, 07/21/16, Appends a datestamp at the end of each 
#                                  log entry, which is ignored on reading
#  Anders Nilsson, UCAR, 07/26/16, append_log_entry attempts to touch log
#                                  file before writing, in case of 
#                                  nonexistent parent directory/permissions.
#                                  Added get_lock_file
#                                  Uses lock files instead of file locks
#  Anders Nilsson, UCAR, 08/02/16, Added get_common_log_file_contents
#  Anders Nilsson, UCAR, 11/06/16, Fixed minutes component of complete time
#  Anders Nilsson, UCAR, 05/28/19, Added LC_ALL=C to help sort deal with
#                                  non-alphanumeric characters
#
###############################################################################

###############################################################################
#
#  Read contents of an existing log files
#
#  This sets a LOG_FILE_CONTENTS array variable
#  This also discards the second datestamp column
#
#  Usage:
#  get_log_file_contents <log file path>
#
###############################################################################
get_log_file_contents()
{
    local LOG_FILE_PATH=$1
    LOG_FILE_CONTENTS=()
 
    if [ -f "${LOG_FILE_PATH}" ]
    then
        local IFS="
"
        # A shared lock would be better, but using exclusive
        get_lock_file "${LOG_FILE_PATH}.lock"
        LOG_FILE_CONTENTS=( $( LC_ALL=C sort "${LOG_FILE_PATH}" | \
                               sed -e "s/|[^|]*$//g" | uniq ) )
        rm -f "${LOG_FILE_PATH}.lock"
    fi
}

###############################################################################
#
#  Get common log file contents
#
#  This reads the files specified in its arguments and sets
#  a LOG_FILE_CONTENTS array variable with the elements that are present
#  in both.
#
#  Usage:
#  get_common_log_file_contents <log1> <log2> <logn...>
#
###############################################################################
get_common_log_file_contents()
{
    LOG_FILE_CONTENTS=()
    local FILE_PATH
    local IFS="
"
    # Get first in list
    if [ $# -gt 0 ]
    then
        FILE_PATH=$1
        
        get_log_file_contents "${FILE_PATH}"
        shift
    fi

    # Read next in list
    while [ $# -gt 0 ] && [ ${#LOG_FILE_CONTENTS[@]} -gt 0 ]
    do
        FILE_PATH="$1"
        shift

        # Copy array so that same function can be used
        local OTHER_LOG_FILE_CONTENTS=( "${LOG_FILE_CONTENTS[@] }" )
        get_log_file_contents "${FILE_PATH}"

        if [ ${#LOG_FILE_CONTENTS[@]} -gt 0 ]
        then
            # Comparing contents of log file. Use only duplicate lines
            LOG_FILE_CONTENTS=( $( printf '%s\n' "${LOG_FILE_CONTENTS[@]}" \
                                          "${OTHER_LOG_FILE_CONTENTS[@]}" | \
                                   LC_ALL=C sort | uniq -d ) )
        else
            # Empty, clearing list
            LOG_FILE_CONTENTS=()
        fi
    done
}

###############################################################################
#
# Append log entry to log file
#
# Usage:
# append_log_entry <log_file_path> <entry>
#
###############################################################################
append_log_entry()
{
    local LOG_FILE_PATH=$1
    local LOG_ENTRY=$2

    # Add date stamp as a second column, pipe-delimited
    local DATESTAMP=$( date -u +"%Y-%m-%d %H:%M:%S %Z" )

    # Attempt to look at the file, in case the parent directory does not
    # exist or the file is not writeable
    touch "${LOG_FILE_PATH}"
    if [ $? -ne 0 ]
    then 
        message error "Unable to touch ${LOG_FILE_PATH}"
        exit 1
    fi

    get_lock_file "${LOG_FILE_PATH}.lock"
    echo "${LOG_ENTRY}|${DATESTAMP}" >> "${LOG_FILE_PATH}"
    rm -f "${LOG_FILE_PATH}.lock"
}

###############################################################################
#
#  Remove old entries from the log file. "Old" is jsut defined as being
#  alphanumerically earlier than a maximum line limit.
#
#  Usage:
#  prune_log_file <log_file_path> <record_limit> {-unsorted}
#
###############################################################################
prune_log_file()
{   
    # Get arguments
    local LOG_FILE_PATH
    local RECORD_LIMIT
    local TEMP_LOG_FILE
    local SORT_FLAG
    
    LOG_FILE_PATH=$1
    RECORD_LIMIT=$2

    # Have the option to keep log file unsorted. This is necessary if the data
    # is stored in multiple directories, as the sorted list would eventually 
    # place out the early alphabetical directory. The reading of the file 
    # also sorts, anyways
    if [ "$3" = "-unsorted" ]
    then
        SORT_FLAG=0
    else
        SORT_FLAG=1
    fi
    
    TEMP_LOG_FILE_PATH="${LOG_FILE_PATH}.tmp$$"
    
    if [ -f "${LOG_FILE_PATH}" ]
    then
        # Using lock files instead of flock due to NFS strangeness
        get_lock_file "${LOG_FILE_PATH}.lock"
        if [ ${SORT_FLAG} -ne 0 ]
        then
            LC_ALL=C sort "${LOG_FILE_PATH}" | uniq | \
                     tail -n ${RECORD_LIMIT} > "${TEMP_LOG_FILE_PATH}"
        else
            tail -n ${RECORD_LIMIT} "${LOG_FILE_PATH}" > "${TEMP_LOG_FILE_PATH}"
        fi
        mv "${TEMP_LOG_FILE_PATH}" "${LOG_FILE_PATH}"
        
        rm -f "${LOG_FILE_PATH}.lock"
    fi
}

#############################################################################
#
#  This function binary searches through the sorted log file contents array
#  for a match of the function argument.
#
#  This function returns 0 if found, 1 if not found
#
#  Usage:
#  if find_in_log_contents <search_line> ...
#
#  Input arguments:
#  ================
#  SEARCH_LINE        : A string to look for in the log file contents array
#
#  Input variables:
#  ================
#  LOG_FILE_CONTENTS  : A sorted array of strings
#
############################################################################
find_in_log_contents()
{
    local SEARCH_LINE=$1
    local COMPLETED_SIZE=${#LOG_FILE_CONTENTS[@]}
    local LEFT_IDX=0
    local RIGHT_IDX=$((COMPLETED_SIZE-1))
    local MID_IDX

    # Binary search
    while [ ${LEFT_IDX} -le ${RIGHT_IDX} ]
    do
        MID_IDX=$(( (LEFT_IDX+RIGHT_IDX) / 2 ))
        if [ "${SEARCH_LINE}" == "${LOG_FILE_CONTENTS[${MID_IDX}]}" ]
        then
            # Found log file, will not process
            return 0
            break
        elif [ "${SEARCH_LINE}" \< "${LOG_FILE_CONTENTS[${MID_IDX}]}" ]
        then
            RIGHT_IDX=$(( MID_IDX - 1 ))
        else
            LEFT_IDX=$(( MID_IDX + 1 ))
        fi
    done

    # Not found
    return 1
}

