#!/bin/bash
#############################################################################
#
#  Gets a busy file. Will exit 1 if unable to successfully create a busy file
#  or one already exists.
#
#  This assumes message_function.sh has already been sourced
#
#  Usage:
#  get_busy_file <lock file path> <age of stale busy record>
#
#  History:
#  Anders Nilsson, UCAR, 05/31/16, Created from other functions
#  Anders Nilsson, UCAR, 06/01/16, Reads busy file contents for more
#                                  informative messages
#  Anders Nilsson, UCAR, 06/27/16, Reads busy file contents once
#  Anders Nilsson, UCAR, 07/14/16, Checks to see if busy process id exists
#                                  if the host matches
#  Anders Nilsson, UCAR, 07/26/16, Checks if parent directory is writable
#  Anders Nilsson, UCAR, 08/05/16, Attempts to kill old busy process id if
#                                  it still exists, rather than erroring
#  Tom Niedzielski UCAR, 09/06/16, Now capable of checking and killing
#                                  processes on remote machines.
#  Anders Nilsson, UCAR, 11/03/16, Does not display busy message if not in tty
#                                  This is done because the scripts that use
#                                  this particular version of this function
#                                  run very frequently.
#                                  Does not use ssh if process is not on a
#                                  remote machine
#  Anders Nilsson, UCAR, 04/05/18, Added -H option to find
#  Anders Nilsson, UCAR, 08/17/20, Added remove_busy_file
#  Anders Nilsson, UCAR, 11/19/20, Checks presence of running process on local
#                                  machine if existing busy file present
#
#############################################################################

## This function is used to determine all child processes and their descendants

  pidtree()
  (
    [ -n "$ZSH_VERSION"  ] && setopt shwordsplit
    declare -A CHILDS
    while read P PP;do
        CHILDS[$PP]+=" $P"
    done < <(ps -e -o pid= -o ppid=)

    walk() {
        echo $1
        for i in ${CHILDS[$1]};do
            walk $i
        done
    }

    for i in "$@";do
        walk $i
    done
  )

## This function removes a busy file if it was the one that created it

  function remove_busy_file
  {
      local BUSY_LOCK_FILE=$1
      local BUSY_PID

      # Check for existence of busy file
      if [ -f "${BUSY_LOCK_FILE}" ]
      then
          # Potential race condition here
          BUSY_PID=$( cat "${BUSY_LOCK_FILE}" | cut -f 2 -d " " )

          # Make sure pid matches
          if [ "${BUSY_PID}" != "$$" ]
          then
              message info "Busy file ${BUSY_LOCK_FILE} was created by someone else (${BUSY_PID}). Not removing"
          else
              rm -f "${BUSY_LOCK_FILE}"
          fi
      fi
  }

  function get_busy_file
  {
      local BUSY_DATE=
      local BUSY_HOST=
      local BUSY_LOCK_FILE=$1
      local BUSY_STALE_HOURS=$2
      local BUSY_OLD=
      local BUSY_PID=
      local BUSY_DIR=$( dirname "${BUSY_LOCK_FILE}" )
      local BUSY_BASE=$( basename "${BUSY_LOCK_FILE}" )
      local THIS_HOST=$( hostname -s )

      # Check for writability of parent directory
      if [ ! -w "${BUSY_DIR}" ]
      then
          message error "Parent directory ${BUSY_DIR} is not writable"
          exit 1
      fi

      # Check for existence of busy file
      if [ -f "${BUSY_LOCK_FILE}" ]
      then
          # Potential race condition here
          BUSY_CONTENTS=$( cat "${BUSY_LOCK_FILE}" )

          # Check age of busy file
          BUSY_OLD=$( find -H "${BUSY_DIR}" -ignore_readdir_race -maxdepth 1 \
                           -name "${BUSY_BASE}" -mmin +$((BUSY_STALE_HOURS*60)) )

          # Read contents for an informative message
          BUSY_HOST=$( echo "${BUSY_CONTENTS}" | cut -f 1 -d " " )
          BUSY_PID=$( echo "${BUSY_CONTENTS}" | cut -f 2 -d " " )
          BUSY_DATE=$( echo "${BUSY_CONTENTS}" | cut -f 3-4 -d " " )

          if [ -n "${BUSY_OLD}" ]
          then
              # Check to see if the process is still running.
              # The process is not reentrant, so it must be killed before
              # starting the new process.
              if [ "${BUSY_HOST}" != "${THIS_HOST}" ]
              then
                  if [ ! -z "$( ssh -q ${BUSY_HOST} /bin/ps --no-headers -q ${BUSY_PID} )" ]
                  then
                      message notice "Process ${BUSY_PID} on ${BUSY_HOST} is still running for old ${BUSY_LOCK_FILE}. Sending SIGTERM."
                      # Not really caring if this is successful or not.
                      ssh -q ${BUSY_HOST} "kill -SIGTERM ${BUSY_PID}"
                  fi
              else
                  if [ ${BUSY_PID} == $$ ]
                  then
                      message notice "Removing old ${BUSY_LOCK_FILE} owned by current process ${BUSY_PID} from ${BUSY_DATE}"

                  elif [ ! -z "$( /bin/ps --no-headers -q ${BUSY_PID} )" ]
                  then
                      message notice "Process ${BUSY_PID} on ${BUSY_HOST} is still running for old ${BUSY_LOCK_FILE}. Sending SIGTERM."
                      # Not really caring if this is successful or not.
                      kill -SIGTERM $( pidtree ${BUSY_PID} | sort -r )
                  fi
              fi

              # Old, removing
              message notice "Removing old ${BUSY_LOCK_FILE} owned by ${BUSY_HOST} process ${BUSY_PID} from ${BUSY_DATE}"
              find -H "${BUSY_DIR}" -ignore_readdir_race -maxdepth 1 \
                   -name "${BUSY_BASE}" -mmin +$((BUSY_STALE_HOURS*60)) -delete
          else
              # Will just check for process presence if on the same host
              if [ "${BUSY_HOST}" != "${THIS_HOST}" ] || \
                 ( [ ! -z "$( /bin/ps --no-headers -q ${BUSY_PID} )" ] && [ ${BUSY_PID} != $$ ] )
              then
                  # Still busy
                  if tty -s
                  then
                      message info "Busy file ${BUSY_LOCK_FILE} present (owned by ${BUSY_HOST} process ${BUSY_PID} from ${BUSY_DATE})"
                  fi
                  exit 1
              else
                  # Busy file still exists, but no longer running. Removing.
                  message notice "Busy file ${BUSY_LOCK_FILE} present but no longer running from ${BUSY_DATE}. Rerunning"
                  # Potential for race condition here
                  rm -f "${BUSY_LOCK_FILE}"
              fi
          fi
      fi
      # Attempt to write busy file
      LOCK_CONTENTS="${THIS_HOST} $$ $( date -u +'%F %T' )"
      if ( set -o noclobber; echo "${LOCK_CONTENTS}" > ${BUSY_LOCK_FILE} )
      then
          SUCCESS=1
      else
          if tty -s
          then
              message info "Busy file ${BUSY_LOCK_FILE} just created by another process"
          fi
          exit 1
      fi
  }

