#!/bin/bash
###########################################################################
#
#  This script fetches hourly gzipped tar files of the HML directory
#  from OWP-MN systems in case of IDP downtime
#
#  History:
#  Anders Nilsson, UCAR, 2021-04-05, Created
#  Anders Nilsson, UCAR, 2021-07-08, More specific with array filling
#                                    Specifies bucket encryption
#  Anders Nilsson, RTI,  2022-05-20, Changed subdir from "qa" to "ops"
#
###########################################################################

# Parameters

  DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  DOWNLOAD_DIR="${DIR}/incoming/"
  DATA_DIR="${DIR}/data"
  LOG_DIR="${DIR}/logs/"
  SAVE_LOG_FILE="${LOG_DIR}/fetch_hml_data.log"
  LOCK_ENTRY="${LOG_DIR}/fetch_hml_data.lock"
  LAG_TIME="80 minutes"
  BACKFILL_MINIMUM_FILES=300
  BACKFILL_DAYS=2
  REMOTE_SITE="https://www.nohrsc.noaa.gov/pub/data/hml/"
  BACKUP_SITE="https://www.nohrsc2.noaa.gov/pub/data/hml/"
  SUBDIR="/common/data/products/UCAR/hydro/ops/"
  STALE_HOURS=6
  REMOVE_TMP_FLAG=0
  REMOVE_LOCK=0
  TEMP_FILE=
  ERROR=1

# Environment dependent
  if [ -z "${OBUCKET}" ] || [ -z "${CBUCKET}" ]
  then
     CHECK_BUCKET="s3://hydrovis-dev-hml-us-east-1"
     OUTPUT_BUCKET="s3://hydrovis-dev-hml-us-east-1-test"
  else
     CHECK_BUCKET="s3://${CBUCKET}"
     OUTPUT_BUCKET="s3://${OBUCKET}"
  fi

# Function includes #
. "${DIR}/message_function.sh"
. "${DIR}/manage_log_files.sh"
. "${DIR}/get_busy_file.sh"

# Set up cleanup functions #
function clean_up()
{
  # Stop signal/error handling
  trap - SIGHUP SIGINT SIGTERM ERR

  # Kill children?
  if [ -n "${CHILD}" ] && [ -n "$( ps --no-headers -q ${CHILD} )" ]
  then
    kill -s SIGTERM ${CHILD}
  fi
  CHILD=

  if [ ${REMOVE_TMP_FLAG} -ne 0 ]
  then
    rm -f ${TEMP_FILE}
  fi

  # Remove lock file
  if [ ${REMOVE_LOCK} -ne 0 ]
  then
    remove_busy_file "${LOCK_ENTRY}"
  fi

  exit ${ERROR}
}

# Get latest hour present in bucket

function get_latest_hour()
{
  local YMD
  local YEAR
  local MONTH
  local DAY
  local HOUR
  local BUCKET_ADDRESS=$1
  YMD=$( aws s3 ls "${BUCKET_ADDRESS}${SUBDIR}" | \
         grep "PRE [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]/" | sort | \
         tail -n 1 | tr -d -c "[0-9]" )
  if [ -z "${YMD}" ]; then return 1; fi

  YEAR=${YMD:0:4}
  MONTH=${YMD:4:2}
  DAY=${YMD:6:2}

  HOUR=$( aws s3 ls "${BUCKET_ADDRESS}${SUBDIR}${YEAR}${MONTH}${DAY}/" | \
          tr -s " " | cut -d " " -f 4 | cut -d "_" -f 3 | \
          grep "^[0-9][0-9][0-9][0-9][0-9][0-9]$" | sort | tail -n 1 | cut -b 3-4 )
  if [ -z "${HOUR}" ]
  then
    HOUR=0
  fi

  echo "${YEAR}-${MONTH}-${DAY} ${HOUR} UTC"
}

# Determine what files need to be fetched. This would be a list of
# datetimes to the hour between (and not including) the current hour, and
# the hour that the input stream stopped.
function get_hour_list()
{
  # Get modification time of LDM directory
  local BUCKET_ADDRESS=$1
  local DIR_TIME=$( get_latest_hour ${BUCKET_ADDRESS} )
  if [ -z "${DIR_TIME}" ]
  then
    message info "Unable to calculate directory time. Going back ${BACKFILL_DAYS} days"
    DIR_TIME=$( date -u -d "-${BACKFILL_DAYS} days" +"%Y-%m-%d %H UTC" )
  else
    message info "Latest time in ${BUCKET_ADDRESS} is ${DIR_TIME}"
  fi
  local EARLIEST_HOUR=$( date -u -d "+60 minutes ${DIR_TIME}" +"%s" )
  local LATEST_HOUR=$( date -u -d "-${LAG_TIME}" +"%s" )
  while [ ${EARLIEST_HOUR} -le ${LATEST_HOUR} ]
  do
    DATE_LIST[${#DATE_LIST[@]}]=$(date -u -d "@${EARLIEST_HOUR}" +"%Y%m%d%H")
    # Increment by an hour
    local FORMATTED_TIME=$( date -u -d "@${EARLIEST_HOUR}" +"%Y-%m-%d %H" )
    EARLIEST_HOUR=$( date -u -d "+1 hour ${FORMATTED_TIME}" +"%s" )
  done
}

# Determine if any previous hours need to be backfilled. 
# This adds onto DATE_LIST
function get_backfill_hour_list()
{
  # Function arguments
  local BUCKET_ADDRESS=$1
  local BUCKET_ADDRESS2=$2
  local BACKFILL_DAYS=$3
  local BACKFILL_MIN_HOUR_COUNT=$4

  # Other local variables
  local COUNT
  local DATE
  local HOUR_DIRS
  local LOG_ENTRY
  local SUBDIR_COUNT
  local YMD

  # Loop through potential hours
  local EARLIEST_HOUR=$( date -u -d "-${BACKFILL_DAYS} day" +"%s" )
  local LATEST_HOUR=$( date -u -d "-${LAG_TIME}" +"%s" )

  while [ ${EARLIEST_HOUR} -le ${LATEST_HOUR} ]
  do
    # Determine if hour needs to be fetched
    COUNT=0
    YMD=$( date -u -d "@${EARLIEST_HOUR}" +"%Y%m%d" )
    DH=$( date -u -d "@${EARLIEST_HOUR}" +"%d%H" )
    DATE_DIRS=$( date -u -d "@${EARLIEST_HOUR}" +"%Y/%m/%d/%H" )
    DATE=$( date -u -d "@${EARLIEST_HOUR}" +"%Y%m%d%H" )

    # First, check to see if already fetched this hour,
    # or, successfully counted.
    LOG_ENTRY="${DATE}.tar.gz"
    if ! find_in_log_contents "${LOG_ENTRY}"
    then

      # Get count of number of files placed
      COUNT=$( aws s3 cp --dryrun ${BUCKET_ADDRESS}${SUBDIR}${YMD}/ . \
               --exclude "*" --include "*_${DH}*" --recursive | wc -l )
      message info "Found ${COUNT} for ${DATE} in ${BUCKET_ADDRESS}"

      # Also check to see if already present in output
      if [ ${COUNT} -lt ${BACKFILL_MIN_HOUR_COUNT} ]
      then
        COUNT2=$( aws s3 cp --dryrun ${BUCKET_ADDRESS2}${SUBDIR}${YMD}/ . \
                  --exclude "*" --include "*_${DH}*" --recursive | wc -l )
        message info "Found ${COUNT2} for ${DATE} in ${BUCKET_ADDRESS2}"
      else
	COUNT2=0
      fi

      # Adding hour to list if total count is less than threshold
      if [ ${COUNT} -lt ${BACKFILL_MIN_HOUR_COUNT} ] && \
	 [ ${COUNT2} -lt ${BACKFILL_MIN_HOUR_COUNT} ]
      then
        DATE_LIST[${#DATE_LIST[@]}]="${DATE}"
      else
        # Good. We won't need to check this again.
        # Add entry to log file
        append_log_entry "${SAVE_LOG_FILE}" "${LOG_ENTRY}"
      fi

    fi

    # Increment by an hour
    local FORMATTED_TIME=$( date -u -d "@${EARLIEST_HOUR}" +"%Y-%m-%d %H" )
    EARLIEST_HOUR=$( date -u -d "+1 hour ${FORMATTED_TIME}" +"%s" )
  done
}

function fetch_file()
{
  local REMOTE_URL=$1
  local LOCAL_FILE=$2

  # First test for file existence
  if ! curl -skI "${REMOTE_URL}" | grep -q "HTTP/1.1 200 OK" 1>/dev/null 2>&1
  then
    message info "Remote file ${REMOTE_URL} not present"
    return 1
  fi

  # Now download
  REMOVE_TMP_FLAG=1
  curl -sSk "${REMOTE_URL}" -o "${LOCAL_FILE}"
  return $?
}

function extract_file()
{
  local SOURCE_FILE=$1
  local DATE=$2
  local YMD=${DATE:0:-2}

  # Clear out sync directory
  find "${DATA_DIR}${SUBDIR}" -mindepth 1 -delete

  # Make date directory. Currently to day
  mkdir -p "${DATA_DIR}${SUBDIR}${YMD}"

  # Extract into data directory
  tar -C "${DATA_DIR}${SUBDIR}${YMD}" -xzf "${SOURCE_FILE}" --strip-components 4

  # Sync contents into bucket
  aws s3 sync --only-show-errors --sse=aws:kms ${DATA_DIR}/ ${OUTPUT_BUCKET}

  # Clear out sync directory
  find "${DATA_DIR}${SUBDIR}" -mindepth 1 -delete
}

function process_date()
{
  local DATE=$1
  local LOG_ENTRY="$( echo "${DATE}.tar.gz" )"

  if ! find_in_log_contents "${LOG_ENTRY}"
  then
    message info "Fetching LDM data file for ${DATE}"

    # Construct paths
    local REMOTE_URL="${REMOTE_SITE}${DATE}.tar.gz"
    TEMP_FILE="${DOWNLOAD_DIR}/${DATE}.tar.gz.tmp$$"

    # Continue if unsuccessful
    if ! fetch_file "${REMOTE_URL}" "${TEMP_FILE}"
    then
      message info "Unable to download ${REMOTE_URL}"

      # Check backup site
      REMOTE_URL="${BACKUP_SITE}${DATE}.tar.gz"
      message info "Attempting to fetch ${REMOTE_URL}"

      # Continue if unsuccessful
      if ! fetch_file "${REMOTE_URL}" "${TEMP_FILE}"
      then
        message info "Unable to download ${REMOTE_URL}"
        return
      fi
    fi

    # Extract file
    message info "Extracting files from ${TEMP_FILE}"
    if extract_file "${TEMP_FILE}" "${DATE}"
    then

      # Add entry to log file
      append_log_entry "${SAVE_LOG_FILE}" "${LOG_ENTRY}"

      # Remove old entries from log file
      prune_log_file "${SAVE_LOG_FILE}" 20000

      message info "Finished extracting for ${DATE}"

    fi

    # Clean up
    rm -f "${TEMP_FILE}"
    REMOVE_TMP_FLAG=0

  fi
}

### Main ###
main()
{
# Call cleanup function on signal, as well as any error #
  trap clean_up SIGHUP SIGINT SIGTERM ERR

# Check directories
  if [ ! -d "${LOG_DIR}" ]
  then
    mkdir -p "${LOG_DIR}"
  fi

  if [ ! -d "${DOWNLOAD_DIR}" ]
  then 
    mkdir -p "${DOWNLOAD_DIR}"
  fi

  if [ ! -d "${DATA_DIR}${SUBDIR}" ]
  then
    mkdir -p "${DATA_DIR}${SUBDIR}"
  fi

# Check to see if busy
  get_busy_file "${LOCK_ENTRY}" ${STALE_HOURS}
  REMOVE_LOCK=1

# Get list of completed fetched files #
  get_log_file_contents "${SAVE_LOG_FILE}"

# Get list of prospective hours. This sets DATE_LIST
  message info "Getting list of hours from ${CHECK_BUCKET}"
  DATE_LIST=()
  get_hour_list "${CHECK_BUCKET}"

# Loop through hours
  for DATE in ${DATE_LIST[@]}
  do
    process_date ${DATE}
  done

# Get potential backfill list
  message info "Getting backfill list"
  DATE_LIST=()
  get_backfill_hour_list ${CHECK_BUCKET} ${OUTPUT_BUCKET} \
                         ${BACKFILL_DAYS} ${BACKFILL_MINIMUM_FILES}
  message info "Found ${#DATE_LIST[@]} backfill entries"
# Loop through hours
  for DATE in ${DATE_LIST[@]}
  do
    process_date ${DATE}
  done

  message info "Done processing"

# Success #
  ERROR=0

# Clean up
  clean_up

}

# Run main function
main

