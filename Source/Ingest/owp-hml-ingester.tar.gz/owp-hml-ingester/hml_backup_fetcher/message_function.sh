#!/bin/bash
#########################################################################################
#
#  Message function
#
#  This currently only formats a message to standard out. Later revisions
#  may add other destinations (like syslog)
#
#  History:
#  Anders Nilsson, UCAR, 07/27/16, Added get_lock_file
#  Anders Nilsson, UCAR, 08/03/16, Added logger support
#  Anders Nilsson, UCAR, 08/08/16, Checks tty status
#  Anders Nilsson, UCAR, 02/10/20, Renamed PP_LOG_FACILITY to NSA_LOG_FACILITY
#
#########################################################################################

message()
{
    local PROGNAME="$( basename -- $0 )[$$]"
    local UC_LEVEL=$( echo $1 | tr [:lower:] [:upper:] )
    local LC_LEVEL=$( echo $1 | tr [:upper:] [:lower:] )
    local MESSAGE=$2

    if [ -n "${NSA_LOG_FACILITY}" ] && ! tty -s
    then
        local LC_LOG_FACILITY=$( echo ${NSA_LOG_FACILITY} | cut -d '_' -f 2- | \
                                 tr [:upper:] [:lower:] )

        echo "${UC_LEVEL}: ${MESSAGE}" | \
             logger -p ${LC_LOG_FACILITY}.${LC_LEVEL} -t "${PROGNAME}"
    else
        local TIME=$( date -u '+%Y-%m-%d %H:%M:%S' )
        local HOST=$( hostname -s )

        printf '%s %s %s: %s: %s\n' "${TIME}" "${HOST}" "${PROGNAME}" "${UC_LEVEL}" "${MESSAGE}"
    fi
}

################################################################################
#
#  Launch function
#
#  This is a wrapper function that sets the CHILD variable to a spawned process
#  and clears it and ERR_MSG once it finishes
#
#  History:
#  Anders Nilsson, UCAR, 08/04/16, Created
#
################################################################################

launch()
{
    ERR_MSG="Unable to execute \"$@\""
    "$@" &
    CHILD=$!
    wait ${CHILD}
    local RETURN=$?
    unset CHILD

    # Unset error message if success
    if [ ${RETURN} -eq 0 ]
    then
        unset ERR_MSG
    fi

    return ${RETURN}
}

################################################################################
#
#  Get a lock file, and wait up to a certain number of seconds in attempts to 
#  fetch it. This is for short duration lock files, and was written as an 
#  alternative to file locking with flock, which current handles NFS badly.
#
#  History:
#  Anders Nilsson, UCAR, 09/08/16, Does not sleep if successfully removes old
#                                  lock file
#
################################################################################

get_lock_file()
{
    local LOCK_FILE_PATH=$1
    local COUNT=0
    local SUCCESS=0
    local START_DATE=$( date -u +%s )
    local STOP_DATE=$( date -u +%s )
    local HOST=$( hostname -s )
    local MAX_WAIT_SECONDS=30
    local MAX_AGE_SECONDS=60
    local LOCK_CONTENTS
    if [ -n "$2" ]
    then
        LOCK_CONTENTS="$2"
    else
        LOCK_CONTENTS="${HOST} $$ ${START_DATE}"
    fi
    while [ $(( STOP_DATE - START_DATE )) -lt ${MAX_WAIT_SECONDS} ]
    do
        if [ ! -f "${LOCK_FILE_PATH}" ]
        then
            # Lock file does not exist. Attempting to write lock file.
            if ( set -o noclobber; echo "${LOCK_CONTENTS}" > "${LOCK_FILE_PATH}" ) 2>/dev/null
            then
                #message info "Successfully got lock file ${LOCK_FILE_PATH} ${COUNT}"
                SUCCESS=1
                break;
            fi
            # Someone else was successful. Will wait
        else
            # Lock file exists. Will test age. Using pipe to prevent error trapping
            FILE_DATE=$( stat -c %Y "${LOCK_FILE_PATH}" 2>/dev/null | cat )
            if [ -n "${FILE_DATE}" ]
            then
                local AGE=$(( START_DATE - FILE_DATE ))
                if [ ${AGE} -gt ${MAX_AGE_SECONDS} ]
                then
                    message notice "Removing old lock file ${LOCK_FILE_PATH}"
                    rm -f "${LOCK_FILE_PATH}"
                    if [ $? -eq 0 ]
                    then
                        continue
                    fi
                fi
            fi
        fi
        # Wait a little
        COUNT=$(( COUNT + 1 ))
        usleep 1000
        STOP_DATE=$( date -u +%s )
    done
    if [ ${SUCCESS} -eq 0 ]
    then
        message error "Unable to acquire lock file ${LOCK_FILE_PATH}"
        exit 1
    fi
}

