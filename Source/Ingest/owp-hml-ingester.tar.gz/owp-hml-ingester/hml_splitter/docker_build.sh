# This is only used if docker-compose is not available
docker build -t wrds_hml_splitter:latest -f Dockerfile .
