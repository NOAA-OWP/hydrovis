#!/usr/bin/env python3
"""
This script is used to split an HML file into one or more XML documents and
publish each as a message to RabbitMQ. The RabbitMQ connection settings are
read from 'splitter.conf' configuration file. The configuration file can be
provided from command line or by default reads from the same directory where
this script is located.

This application is a RabbitMQ consumer. It binds itself to the HML queue of the
RabbitMQ. The name and details of the queue are provided in configuration file.

For details about usage or command line arguments please use -h option

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 01/05/2018
"""

# Import system libraries first
import sys
import os

import logging
from config.ConfigReader import ConfigReader
from optparse import OptionParser, OptionGroup

import pika
import json

from urllib.error import HTTPError
from urllib.parse import urlparse, urlunparse

import boto3
import botocore

from sqlalchemy.exc import SQLAlchemyError

# Module imports
from constants import app, conf, log, xml, hml_message, xml_message
from splitter.splitter import HML
from rabbitmq.rabbitmq import RabbitMQManager
from database.db_manager import DBManager
from database.db_model import HmlStatusEnum
from hmlexceptions import HMLEmptyException

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


def setup_logging(conf_log):
    """
    Configures logger

    This function sets up the application logger by setting its log level,
    target, log format, etc from the information provided in input tuple.

    Args:
        conf_log: a tuple representing values from log section of conf file

    Returns:
        This function doesn't return anything

    Raises:
        Exception in case log target is not specified in configuration file
    """

    conf_log_level, conf_log_target, conf_log_file = conf_log

    # set log level (don't allow any level higher than INFO)
    if conf_log_level == conf.LOG_DEBUG_LEVEL:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO

    logger.setLevel(log_level)

    # set log target to be a file or stdout
    if conf_log_target == conf.LOG_FILE:

        # default to file name in conf file if log file name is not provided
        if not conf_log_file:
            conf_log_file = log.DEFAULT_FILENAME

        log_handler = logging.FileHandler(conf_log_file)

    elif conf_log_target == conf.LOG_STREAM:
        log_handler = logging.StreamHandler(sys.stdout)

    else:
        raise Exception('Provided logging target is not valid. Check config.')

    # set log message format
    log_formatter = logging.Formatter(
        fmt=log.DEFAULT_FORMAT,
        datefmt=log.DEFAULT_DATE_FORMAT
        )
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)

    #logger.info("The logging mechanism has been created.")


def setup_options():
    """
    Configures command line arguments

    Returns:
        A tuple of program options and arguments in that order

    """

    usage_message = "Usage: %prog [option]"
    option_parser = OptionParser(
        usage=usage_message,
        version="%prog version " + app.VERSION,
        description="The application runs as a consumer to RabbitMQ HML queue. "\
            "The details about the RabbitMQ are provided in the splitter.conf "\
            "configuration file. It downloads the HML file from objectstore by "\
            "using the url from HML event message retrieved from HML queue."
        )

    # path to application configuration file
    dir_path = os.path.dirname(os.path.realpath(__file__)) + "/"
    option_parser.add_option(
        "-f", "--config-file",
        dest="config_file",
        default=dir_path + conf.DEFAULT_CONFIG_FILENAME,
        help="The path to the configuration file. default: ./" + \
             conf.DEFAULT_CONFIG_FILENAME
    )

    return option_parser.parse_args()


def get_options():
    """
    Get command line options

    Gets and validates command line options
    """

    # parse command line options, no arguments present
    options, _ = setup_options()

    return options


def get_configs(config_file):
    """
    Get configuration parameters from provided configuration file
    """

    try:
        config_reader = ConfigReader(config_file)
        configs = config_reader.read_configs()
    except BaseException as exception:

        # logging is not configured at this point
        print("Error: ", str(exception))
        raise

    return configs


def update_url_domain_port(url, domain, port):
    """
    Update domain name and port number in an existing url

    Args:
        url: a complete url with proto, domain, port, relative path
        domain: new domain name to replace existing one with
        port: new port number to replace existing one with

    Returns:
        Updated url string
    """

    parse_result = urlparse(url)
    modified_parse_result = parse_result._replace(
        netloc="{}:{}".format(
            domain if domain else parse_result.hostname,
            port if port else parse_result.port
        )
    )

    return urlunparse(modified_parse_result)


def process_hml_event(hml_db_entry_id, hml_file_path, arguments,
                      conf_objectstore):
    """
    Split HML using the HML event message

    This function breaks an HML file at provided url to individual XMLs and
    publishes them to RabbitMQ XML queue.

    Args:
        hml_db_entry_id: synthetic key of HML in database
        hml_file_path: complete URL for HML file in object store
        arguments: database session, xml queue related elemenets to publish xml
        conf_objectstore: tuple with objectstore information

    Returns:
        This method returns nothing. It raises exceptions if anything goes wrong

    Raises:
        KeyError: if hml_event is missing the desired field.  Aborts if so.
        SQLAlchemyError: if update to hml failed for some database error
        Exception: if hml with given id is not found in database.
    """

    ## exchange name, queue name and xml publish channel are needed to publish
    #  tiny xml files as messages.
    db_session, xml_queue_channel, rmq_exchange, rmq_xml_queue = arguments
    # access keys are potentially used to access stored HML files
    ohost, oport, access_key, secret_key = conf_objectstore

    # if hml is already processed, send ack back and return
    if DBManager.is_hml_processed(db_session, hml_db_entry_id):

        logger.info("Hml with id: {} is already processed".format(
            hml_db_entry_id))
        return True

    # update hml status to split
    DBManager.update_hml_status(db_session, hml_db_entry_id, HmlStatusEnum.split)
    logger.debug(
        "Updated status of hml with id: {0} and url: '{1}' to split".format(
            hml_db_entry_id,
            hml_file_path))

    # read hml and split xmls
    hml = HML(hml_file_path,
              credentials={'aws_access_key': access_key,
                           'aws_secret_access_key': secret_key})
    forecasts_read = 0
    for xml, lid, pedts in hml.forecasts():

        forecasts_read += 1

        # create an xml task entry in database
        DBManager.upsert_hml_xml_row(
            db_session,
            hml_db_entry_id,
            forecasts_read,
            lid,
            pedts
            )

        # publish xml message to the RabbitMQ xml queue
        xml_event_message = {
            xml_message.HML_ID_FIELD: hml_db_entry_id,
            xml_message.XML_INDEX_FIELD: forecasts_read,
            xml_message.XML_BODY_FIELD: xml
        }
        logger.debug(
            "Publishing forecast {0} with lid: {1}, and PEDTS: {2}".format(
                forecasts_read,
                lid,
                pedts
                )
            )
        xml_queue_channel.basic_publish(
            exchange=rmq_exchange,
            routing_key=rmq_xml_queue,
            body=json.dumps(xml_event_message),
            properties=pika.BasicProperties(
                delivery_mode=2
                )
            )

    logger.info(
        "Processed file: '{0}' - forecasts extracted: {1}".format(
            hml_file_path,
            forecasts_read
            )
        )

    # mark hml parsed if  no forecasts found
    if forecasts_read == 0:

        DBManager.update_hml_status(
            db_session,
            hml_db_entry_id,
            HmlStatusEnum.xml_parse_complete
        )


def hml_event_handler(
        channel, method, properties, event, arguments, conf_objectstore
    ):
    """
    Handles processing of an HML message

    An acknowlegemnt to RabbitMQ is sent if processing of HML went as expected.
    An no-ack message is sent with no requeue, in case of error downloading the
    file or any other exception. This will result in the message getting
    requeued in the HML dead letter exchange queue for reprocessing later.

    Args:
        channel: channel used for communication
        method: spec.Basic.Deliver
        properties: spec.BasicProperties
        event: A json message with url to HML file
        arguments: additional arguments to this function as tuple
        conf_objectstore: tuple with objectstore information

    Returns:
        This function returns nothing

    Raises:
        KeyError: if hml_event is missing the desired field.
        SQLAlchemyError: if update to hml failed for some database error
    """

    # convert hml json event message to python dict
    # Also confirming types
    hml_event = json.loads(event.decode('utf-8'))

    try:
        hml_db_entry_id = int(hml_event[hml_message.HML_ID_FIELD])
        hml_file_path = str(hml_event[hml_message.HML_URL_FIELD])
        logger.info(
            "Received an HML event message with id: {0} and url: '{1}'".format(
                hml_db_entry_id,
                hml_file_path
                )
            )

        # modify url if objectstore environment variables are provided
        #ohost, oport = conf_objectstore
        # Url should already be valid
        #modified_hml_url = update_url_domain_port(hml_file_path, ohost, oport)
        modified_hml_url = hml_file_path
        # For transition purposes
        modified_hml_url = hml_file_path.replace('http://', 'https://')

        process_hml_event(
            hml_db_entry_id,
            modified_hml_url,
            arguments,
            conf_objectstore
        )
        channel.basic_ack(delivery_tag=method.delivery_tag)

    except HTTPError as exception:

        # if we don't have permission to read file, display message and 
        # continue. Likely due to bad location in RabbitMQ.
        if exception.code == 403:
            logger.error(
                "file '{0}' forbidden. Likely due to bad bucket name. "
                "Moving on!".format(hml_file_path))
            channel.basic_ack(delivery_tag=method.delivery_tag)

        # if file not found, log it and send ack to RabbitMQ to treat it done
        if exception.code == 404:
            logger.warning(
                "file '{0}' not found. Moving on!".format(
                    hml_file_path
                    )
                )
            channel.basic_ack(delivery_tag=method.delivery_tag)

    except botocore.exceptions.ClientError as exception:
        # if file not found, log it and send ack to RabbitMQ to treat it done
        # Also, if file is not accessible, log it and send ack to RabbitMQ to 
        # treat it done. This could be caused typically by one of two
        # situations of which the former is more likely and should be tolerated:
        # 1) The location is very bad, referring to some bad bucket, or 2)
        # the source bucket is not readable.
        if exception.response['ResponseMetadata']['HTTPStatusCode'] == 404:
            logger.warning(
                "file '{0}' not found. Moving on!".format(
                    hml_file_path
                    )
                )
            channel.basic_ack(delivery_tag=method.delivery_tag)
        elif exception.response['ResponseMetadata']['HTTPStatusCode'] == 403:
            logger.error(
                "file '{0}' forbidden. Likely due to bad bucket name. "
                "Moving on!".format(hml_file_path))
            channel.basic_ack(delivery_tag=method.delivery_tag)
        else:
            raise exception

    except TypeError as exception:
        # Corrupted data, skipping
        logger.error(str(exception))
        channel.basic_ack(delivery_tag=method.delivery_tag)
    except IOError as exception:

        logger.error(str(exception))
        channel.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

    except BaseException as exception:

        logger.exception(str(exception))
        channel.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

    logger.info("Waiting for hml events from RabbitMQ. To exit press CTRL+C.")

def main():
    """
    This is the application entry point

    It parses config file and command line arguments and binds to the
    RabbitMQ HML queue to listen for any incoming HML event messages. Upon
    arrival of an HML message, it parses the contents of the HML message and
    uses the URL provided to download the file from objectstore and split it
    into individual XML documents and push them back to RabbitMQ XML queue.
    """

    try:

        # get command line options
        options = get_options()

        # get configs
        configs = get_configs(options.config_file)
        conf_rabbitmq, conf_db, conf_log, conf_objectstore = configs

        # setup logging
        setup_logging(conf_log)
        logger.debug("Using config file: {0}".format(options.config_file))

        rmq_url, rmq_exchange, conf_hml, conf_xml = conf_rabbitmq
        db_connection_string, = conf_db

        # create channel to hml event queue and start listening for HML message
        hml_queue, hml_prefetch_count, hml_message_ttl = conf_hml
        xml_queue, xml_prefetch_count, xml_message_ttl = conf_xml

        rmq_manager = RabbitMQManager(rmq_url)
        rmq_manager.setup(rmq_exchange, hml_queue, hml_message_ttl, xml_queue, xml_message_ttl)
        with DBManager(db_connection_string) as db_session:

            with rmq_manager.get_channel(hml_prefetch_count) as hml_queue_channel, \
                rmq_manager.get_channel(xml_prefetch_count) as xml_queue_channel:

                # turn on delivery confirmations for xmls split from hml
                #xml_queue_channel.confirm_delivery()

                arguments = (db_session, xml_queue_channel, rmq_exchange, xml_queue)
                hml_queue_channel.basic_consume(queue=hml_queue, on_message_callback=
                                                (lambda channel, method,
                                                        properties, body: hml_event_handler(
                                                            channel, method,
                                                            properties, body,
                                                            arguments,
                                                            conf_objectstore)))
                logger.info("Waiting for hml events from RabbitMQ. To exit press CTRL+C.")
                hml_queue_channel.start_consuming()

    except BaseException as exception:
        logger.exception(str(exception))
        sys.exit(1)

    sys.exit(0)

if __name__ == '__main__':
    main()
