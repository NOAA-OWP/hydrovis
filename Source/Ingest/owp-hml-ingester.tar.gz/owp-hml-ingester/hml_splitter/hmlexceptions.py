"""
This file defines some exceptions that will be used by HML splitter

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 06/01/2018
"""

class HMLException(Exception):
    """
    Basic exception for this application
    """
    pass


## XML split exceptions
class HMLSplitException(HMLException):
    """
    Basic HML split exception
    """
    pass

class HMLEmptyException(HMLSplitException):
    """
    Basic HML split exception
    """
    pass
