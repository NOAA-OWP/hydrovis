# HML Splitter

HML splitter, as the name suggests, is designed to split an HML file into 
multiple XML documents. It assumes that you have an object store, RabbitMQ, and
a Postgres database running. The connection strings for these resources needs to
be provided in the configuration file with the exception of object store. HML
Ingester is developed under the assumption that the message from RabbitMQ will
contain the complete URL to the HML file in the object store and HML bucket on
object store will have public read ACL on it so object store credentials are not
needed to read an HML file. 

### Prerequisites

The HML Splitter requires at least Python 3 to be able to use context manager for
fileinput module. You can check the version of python using:
```
python --version
```

You will also need to install following pip packages:
| Package          | Needed for                        |
| -----------------|:----------------------------------|
| configreader     | (for reading config file)         |
| pika             | (for communicating with RabbitMQ) |
| psycopg2         | (underlying DB API)               |
| python-date-util | (for date manipulation)           |
| SQLAlchemy       | (for ORM operations)              |

You can install them using:
```
pip install -r requirements.txt
```

The other important thing is that you need to either install and run RabbitMQ
instance and provide a url in `splitter.conf` file for an existing instance. The
environment variables in the url must be defined in the `.env.prod` file. 
You can install [RabbitMQ](https://packagecloud.io/rabbitmq/rabbitmq-server/) 
server for RPM based linux. The RabbitMQ depends on erlang and a minimal erlang
installation can be done by fllowing instructions on this [link]( https://packagecloud.io/install/repositories/rabbitmq/erlang/script.rpm.sh).

## Getting Started

Populate the `.env.prod` file located in splitter directory with values of the
environment variables provided and run following command to import all environment
variables defined in that file:

```
set -a; source .env.prod; set +a
```

Assuming that you have an instance of RabbitMQ running, and you have provided
all the environment variables listed in `.env.prod` correctly, you can run the
HML Splitter as following:

```
./hml_splitter.py
```
If everything goes well, you should see a prompt indicating that HML Splitter is
listening for any incomding HML events from RabbitMQ or see it splitting HMLs
into XMLs if RabbitMQ already had HML events.

## Deployment

The HML Splitter is a scalable application so you can run multiple instances of
it on a VM or as docker services. The application provided a `Dockerfile` in its
root directory that can be used to build a docker image and run multiple
containers off of it or it can be used in the `docker-compose.yml` file provided
in the root directory of HML Ingester repository.

It is recomended that you use the docker-compose to build and image and run this
application becuase that makes it easy to scale the HML Splitter containers. You
can change directory to one-level up and run following command:
```
docker-compose up -d
docker ps
```