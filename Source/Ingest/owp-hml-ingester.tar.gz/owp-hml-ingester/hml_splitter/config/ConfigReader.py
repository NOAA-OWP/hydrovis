"""
This class is used to parse the configuration file contents


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/31/2017
"""

import logging
import os
from configparser import SafeConfigParser, NoOptionError, NoSectionError

# local modules
from constants import conf


class ConfigReader(object):
    """
    Class that handles reading and parsing the configuration file
    """

    def __init__(self, config_file):

        # path to the config file
        self.config_file = config_file

    def get_config_value(self, section, parameter_name):
        """
        Get value of a configuration parameter in specified section

        Args:
            section: The section to search from in configuration file
            parameter_name: The name of the parameter we are searching for
        Returns:
            String value of the parameter or None if not found
        """

        try:

            configuration = SafeConfigParser(os.environ)
            configuration.read(self.config_file)
            value = configuration.get(section, parameter_name)
        except (NoSectionError, NoOptionError) as err:

            logging.warning(err)
            return None

        return value

    def read_conf_rabbitmq(self):
        '''
        Parse the rabbitmq section of configuration file

        Args:
            config_file: The configuration file
        Returns:
            A tuple with connection url to rabbitmq node. Keeping tuple for
            ease of extensibility.
        Raises:
            Exception: if url is missing
        '''

        # make sure user specified url parameter
        rabbitmq_url = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_URL
            )

        if rabbitmq_url is None:
            raise Exception(
                "You must provide url to RabbitMQ node/cluster. Aborting!"
                )

        # get exchange name specified
        rabbitmq_exchange = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_EXCHANGE
            )

        if rabbitmq_exchange is None:
            raise Exception(
                "You must provide a name for RabbitMQ exchange. Aborting!"
                )


        ## HML QUEUE

        # required: hml event queue if splitter is used in consumer mode
        rabbitmq_hml_event_queue = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_EVENT_QUEUE
        )

        # prefetch count for consumer channel
        rabbitmq_hml_prefetch_count = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_PREFETCH_COUNT
        )

        try:
            rabbitmq_hml_prefetch_count = int(rabbitmq_hml_prefetch_count)
        except ValueError:
            raise Exception(
                "You must provide an integer prefetch count for "\
                "hml queue. Aborting!"
                )

        # dead letter hml queue message ttl
        rabbitmq_dl_hml_message_ttl = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_DL_HML_TTL
        )

        try:
            rabbitmq_dl_hml_message_ttl = int(rabbitmq_dl_hml_message_ttl)
        except ValueError:
            raise Exception(
                "You must provide an integer message time to live for "\
                "dead letter hml queue. Aborting!"
                )

        ## XML QUEUE

        # get xml queue anme specified
        rabbitmq_xml_queue = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_XML_QUEUE
            )

        if rabbitmq_xml_queue is None:
            raise Exception(
                "You must provide queue name to send XML messages to. Aborting!"
                )

        # prefetch count for xml queue consumers
        rabbitmq_xml_prefetch_count = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_XML_PREFETCH_COUNT
        )

        try:
            rabbitmq_xml_prefetch_count = int(rabbitmq_xml_prefetch_count)
        except ValueError:
            raise Exception(
                "You must provide an integer prefetch count for "\
                "xml queue. Aborting!"
                )

        # dead letter xml queue message ttl
        rabbitmq_dl_xml_message_ttl = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_DL_XML_TTL
        )

        try:
            rabbitmq_dl_xml_message_ttl = int(rabbitmq_dl_xml_message_ttl)
        except ValueError:
            raise Exception(
                "You must provide an integer message time to live for "\
                "dead letter xml queue. Aborting!"
                )

        return (
            rabbitmq_url,
            rabbitmq_exchange,
            (
                rabbitmq_hml_event_queue,
                rabbitmq_hml_prefetch_count,
                rabbitmq_dl_hml_message_ttl
                ),
            (
                rabbitmq_xml_queue,
                rabbitmq_xml_prefetch_count,
                rabbitmq_dl_xml_message_ttl
                )
            )

    def read_conf_db(self):
        '''
        Parse the database section of configuration file

        Args:
            Ther are no arguments

        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get database connection string
        conf_connection_string = self.get_config_value(
            conf.DATABASE_SECTION,
            conf.DATABASE_CONNECTION_STRING
        )

        return (conf_connection_string,)

    def read_conf_log(self):
        '''
        Parse the log section of configuration file

        Args:
            config_file: The configuration file
        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get log debug level
        conf_log_level = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_LEVEL
        )

        # log to file|stream
        log_output_to = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_TARGET
        )

        # log file, if applicable
        log_file = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_FILE_PATH
        )

        return (conf_log_level, log_output_to, log_file)

    def read_conf_objectstore(self):
        '''
        Parse the object store section of configuration file

        Args:
            Ther are no arguments

        Returns:
            A tuple containing the host name, and port
        '''

        # get object store host name
        conf_objectstore_host = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_HOST
        )

        conf_objectstore_port = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_PORT
        )

        # access key
        access_key = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_ACCESSKEY
        )
        access_key.strip()
        if not access_key :
            access_key = None

        # secret key
        secret_key = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_SECRETKEY
        )
        secret_key.strip()
        if not secret_key :
            secret_key = None

        return (conf_objectstore_host, conf_objectstore_port,
                access_key, secret_key)

    def read_configs(self):
        '''
        This function parses all configuration parameters

        The function reads all sections of the configuration file and return a tuple
        containing the tuples one for each section.

        Returns:
            A tuple of tuples each corresponding to a configuration section
        Raises:
            Exception: if any of the section parser raises exception
        '''

        # rabbitmq section
        conf_rabbitmq = self.read_conf_rabbitmq()

        # database section
        conf_database = self.read_conf_db()

        # log section
        conf_log = self.read_conf_log()

        # object store section
        conf_objectstore = self.read_conf_objectstore()

        return (conf_rabbitmq, conf_database, conf_log, conf_objectstore)
