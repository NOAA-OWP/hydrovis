"""
This file contains constants for xml extraction

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 01/06/2018
"""


## @var XML_START_TAG
# Starting tag of XML
XML_START_TAG = "<?xml"

## @var XML_SITE_END_TAG
# End tag of site is end tag og XML
XML_SITE_END_TAG = "</site>"

## @var FORECAST_START_TAG
# Starting tag for forecast
FORECAST_START_TAG = "<forecast"

## @var FORECAST_END_TAG
# End tag of forecast tag
FORECAST_END_TAG = "</forecast>"

# Regex to parse each XML document from an HML file. The regex looks for the
# xml start tag and keeps accumulating the charaters in target string till it
# reaches the closing site tag. While doing so, it saves the location id of the
# gage which this XML is for and the PEDTS value of observations or forecasts
# contained in the XML document. The entire xml is saved in as the group 0 of
# regex match, whereas the lid and pedts are saved in group 1 and 2 respectively.
# Note: id name is changed from strictly 5 characters to one or more to account
# for id='BDY' found in some hmls. April 27, 2018
XML_PATTERN = r'<\?xml[\s\S]*?'\
    r'id="([a-zA-Z0-9]+)"[\s\S]*?'\
    r'pedts="([a-zA-Z0-9]{5})"[\s\S]*?<\/site>'
