"""
Constants for hml_xml table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 03/22/2018
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_HML_XML
# Name of the hml xml analytics table
TABLE_HML_XML = "hml_xml"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_HML_ID
# Name of foreign key to hml table
COLUMN_HML_ID = "hml_id"

## @COLUMN_XML_INDEX
# The index number of XML in parent HML file starting from 1
COLUMN_XML_INDEX = "xml_index"

## @COLUMN_LID
# The location identifier of the xml from HML file
COLUMN_LID = "lid"

## @COLUMN_PEDTS
# The physical-element duration and type-source information of xml from HML file
COLUMN_PEDTS = "pedts"

## @COLUMN_XML_STATUS
# The current xml processing stage
COLUMN_XML_STATUS = "xml_status"

## @COLUMN_XML_STATUS_TS
# The time when current xml processing stage was updated
COLUMN_XML_STATUS_TS = "xml_status_ts"

###############################################################################
### SUPPLEMENTAL
###############################################################################
