"""
Constants for hml table

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 12/19/2017
"""

###############################################################################
### TABLE NAMES
###############################################################################

## @TABLE_HML
# Name of the hml analytics table
TABLE_HML = "hml"

###############################################################################
### COLUMN NAMES
###############################################################################

## @COLUMN_HML_ID
# Name of synthetic key
COLUMN_HML_ID = "hml_id"

## @COLUMN_URL
# The URL of hml file in object store
COLUMN_URL = "url"

## @COLUMN_HML_STATUS
# The processing stage the HML file is currently in
COLUMN_HML_STATUS = "hml_status"

## @COLUMN_HML_STATUS_TS
# The time last processing stage changed for HML status
COLUMN_HML_STATUS_TS = "hml_status_ts"

###############################################################################
### SUPPLEMENTAL
###############################################################################
