'''
@package This file contains constants definitions related to logging
'''

## This file contains constants definitions related to logging
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#  @author Shafiq Rahman
#  @version 1.0
#  @date 10/05/2017

## @var DEFAULT_FORMAT
# Determines the default format for logged messages
DEFAULT_FORMAT = "%(asctime)s.%(msecs)03d, "\
    "logger: %(name)s, "\
    "file: %(filename)s, " \
    "function: %(funcName)s, "\
    "line: %(lineno)s, "\
    "level: %(levelname)s - "\
    "%(message)s"

## @var DEFAULT_DATE_FORMAT
# Determines the default format for the dates used in logged messages
DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

## @var DEFAULT_LEVEL
#  Determines the level of messages that are written to the log
DEFAULT_LEVEL = "DEBUG"

## @var DEFAULT_FILENAME
# Determines the path and name of the output log file
DEFAULT_FILENAME = "hml_ingester.log"

