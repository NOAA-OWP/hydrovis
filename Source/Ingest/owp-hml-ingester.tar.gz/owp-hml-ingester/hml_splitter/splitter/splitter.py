"""
This class is used to hold the hml file object. It also provides the methods to
parse XML documents from HML using an iterator.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 01/05/2018
"""

# Import system libraries
import io
import logging

import re
import ssl
from urllib.request import urlopen
from urllib.parse import urlparse
from http.client import HTTPResponse

import boto3
import botocore

# module imports
from constants import app, xml

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class HML(object):
    """
    This class stores and splits an HML file into XML documents
    """

    # number of bytes per KiB
    BYTES_PER_KiB = 1024

    def __init__(self, hml_url, credentials=None):
        """

        Args:
            hml_url: (string) The URL of the HML file
            credentials: (dict) A list containing scheme-specific
                authentication credentials. Currently used just for
                object store auth.
        Raises:
            Exception: if hml url is empty or whitespace
        """

        stripped_hml_url = hml_url.strip()
        if not stripped_hml_url:
            raise Exception(
                "Provided HML url '{}' is empty/whitespace".format(hml_url)
                )

        self.hml_file_url = stripped_hml_url
        self.credentials = credentials


    def _get_file_obj(self):
        """
        Get a file object for HML file based on the url provided in constructor

        This function will handle HTTPS:// or s3:// URLs.

        Args:
            This function takes no arguments

        Returns:
            A file-like object

        Raises:
            Exception: if a valid file doesn't exist at specified path
        """

        try:
            # Different behavior for different URL schemes
            parser = urlparse(self.hml_file_url)
            scheme = parser.scheme

            if scheme == 's3':
                bucket = parser.netloc
                key = parser.path.lstrip('/')

                # Initialize object store connection
                resource = boto3.resource('s3',
                                          aws_access_key_id=
                                          self.credentials['aws_access_key'],
                                          aws_secret_access_key=
                                          self.credentials['aws_secret_access_key'])
                # Initialize object
                oobject = resource.Object(bucket, key)

                # Download into memory and return the created in-memory object
                inmemory_file = io.BytesIO()
                oobject.download_fileobj(inmemory_file)
                # Have to rewind file
                inmemory_file.seek(0)

                return inmemory_file

            else:

                return urlopen(url=self.hml_file_url,
                               context=ssl._create_unverified_context())

        except ValueError:
            raise Exception(
                "'{0}' is not a valid accessible url".format(
                    self.hml_file_url
                    )
                )

    def _read_chunk(self, chunksize_kib=512):
        """
        Read a chunk of size chunksize KiB at a time from the file

        Args:
            chunksize: size of the chunk in KiB, default 512 KiB

        Returns:
            A chunk of HML file in utf-8 format ignoring any non-utf-8 chars

        Raises:
            Exception: if input HML file is not read over HTTP
        """

        # bytes in chunk
        chunksize = chunksize_kib * HML.BYTES_PER_KiB

        with self._get_file_obj() as file_object:

            # empty byte string is sentinel value indicating all file is read
            for chunk in iter(lambda: file_object.read(chunksize), b''):

                yield chunk.decode('utf-8', "ignore")

    def _extract_xml(self, regex_pattern):
        """
        Use a regular expression to extract one xml document from HML

        This function works on one chunk at a time and applies a multiline
        regular expression to extract an XML from the chunk. When chunk is
        exhausted, it appends any leftover chunk to the new chunk and repeats
        the process until whole HML file is processed.

        Args:
            regex_pattern: regular expression to extract an XML

        Returns:
            An tuple of xml document string, lid, and pedts

        """

        # regex that starts matching when it sees '<?xml' and ends matching
        # when it finds </site> tag.
        pattern = re.compile(
            regex_pattern,
            re.MULTILINE
            )

        leftover_chunk = ''
        for hml_chunk in self._read_chunk():

            # if leftover from previous chunk, prefix current chunk with that
            # find an xml document and return it as a string
            complete_chunk = ''.join([leftover_chunk, hml_chunk])
            for xml_match in pattern.finditer(complete_chunk):
                yield xml_match.group(), xml_match.group(1), xml_match.group(2)

            # partial chunk after the last match, if any. If  file has no xml
            # present, xml_match may not be defined. It is highly unlikely but
            # possible
            try:
                leftover_chunk = hml_chunk[xml_match.end(0) + 1 :]
            except NameError:
                logger.warning(" File at '{}' has no XMLs".format(self.hml_file_url))

    def forecasts(self):
        """
        Get one XML forecast at a time from an HML file, skip observation XMLs
        """

        forecast_tags = [xml.FORECAST_START_TAG, xml.FORECAST_END_TAG]

        for parsed_regex_groups in self._extract_xml(xml.XML_PATTERN):

            parsed_xml, _, _ = parsed_regex_groups

            if all(forecast_tag in parsed_xml for forecast_tag in forecast_tags):
                yield parsed_regex_groups
