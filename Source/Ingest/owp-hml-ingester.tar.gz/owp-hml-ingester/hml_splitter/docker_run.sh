# This is only used if docker-compose is not available
sudo docker run -d --restart=always --name wrds_hml_splitter \
                --env-file=".env.prod" wrds_hml_splitter
