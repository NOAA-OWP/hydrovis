"""
This class is used to manage database related operations

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

#  Import System libraries
import logging

# ORM
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.sql.expression import update, select

from sqlalchemy.exc import DatabaseError, OperationalError, IntegrityError
from sqlalchemy.orm.exc import NoResultFound

from sqlalchemy.pool import QueuePool

# module imports
from database.db_model import utcnow, Hml, HmlXml
from database.db_model import HmlStatusEnum, HmlXmlStatusEnum
from constants import app
from constants.database import const_hml, const_hml_xml

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class DBManager(object):
    """
    This class is used to manage database related operations
    """

    def __init__(self, connection_string):
        """
        Initialize sqlalchemy engine and create a session

        The session scope is application wide and transaction scopes are limited
        to the functions. The session is closed in class destructor.

        Args:
            connection_string: The connection string to database of interest
        Returns:
            nothing
        Raises:
            NoSuchModuleError: If database doesn't exist
            OperationalError: if connection string is invalid like domain name,
            username, email etc.
        """

        ## @var engine
        # connection string to database
        # Note that setting isolation level to AUTOCOMMIT means that all of the
        # sql transactions will commit automatically, if more than one
        # sql queries need to be committed/rolledback together, we need to do
        # something special as mentioned in the following article:
        # http://oddbird.net/2014/06/14/sqlalchemy-postgres-autocommit/
        try:
            self.engine = create_engine(
                connection_string,
                pool_size=1,
                max_overflow=0,
                poolclass=QueuePool,
                isolation_level='AUTOCOMMIT'
                )
        except DatabaseError as db_error:
            logger.error(str(db_error))
            raise

        ## @var sessionmaker
        # settings for database sessions factory method
        self.session_maker = sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            autocommit=True
            )

        # Initializing for now
        self.session = None

    def __enter__(self):
        """
        Get a db session

        Args:
             nothing
        Returns:
            an instance of Session bound to the sqlalchemy engine
        """

        logger.debug("Opening the database session")
        self.session = self.session_maker()
        return self.session

    def __exit__(self, *args):
        """
        Close the db session
        """

        logger.debug("Closing the database session")
        self.session.close()

    @staticmethod
    def upsert_rows(
            session,
            model_name,
            rows,
            index_elements,
            no_update_cols=[]
    ):
        """
        Upsert rows in the given table

        This function performs the upsert operation on the rows of the table
        deduced from the model_name. The upsert operation determines the unique
        -ness of the rows based of the index_elements which can be either a
        string with name of the constrain or a list of unique columns. The
        columns specified in no_update_cols list are not among the columns
        mentioned in the upsert query

        Args:
            session: a sqlalchemy session object for this transaction
            model_name: The name of class representing the db relation
            rows: A list of the rows with values to insert
            index_elements: The uniqueness constraint
            no_update_cols: A list of the columns not to be updated
        Returns:
            True if upsert was successful, False otherwise
        """

        # get table object from model name
        try:
            table = model_name.__table__
        except NameError as name_error:
            logger.exception(str(name_error))
            return False
        except AttributeError as attrib_error:
            logger.exception(str(attrib_error))
            return False

        upsert_status = False

        try:
            stmt = pg_insert(table).values(rows)
            update_cols = [
                c.name for c in table.c
                if c not in list(table.primary_key.columns) and
                c.name not in no_update_cols
            ]

            on_conflict_stmt = stmt.on_conflict_do_update(
                index_elements=index_elements,
                set_=dict((k, getattr(stmt.excluded, k)) for k in update_cols)
                )

            session.execute(on_conflict_stmt)
            upsert_status = True
        except OperationalError as oper_error:
            logger.exception(str(oper_error))
            raise
        except DatabaseError as err:
            logger.exception(str(err))
            raise

        return upsert_status

    @staticmethod
    def update_hml_status(session, hml_entry_id, status):
        """
        Update the hml entry for given id with status

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: the id of the hml row in database
            status: an enum for hml_status column of HML table

        Returns:
            True if update was successful

        Raises:
            Exception: if there is no key
        """

        # update the status and status timestamp to current utc time
        update_values = {
            const_hml.COLUMN_HML_STATUS: status,
            const_hml.COLUMN_HML_STATUS_TS: utcnow()
        }

        update_statement = update(Hml).where(Hml.hml_id == hml_entry_id).\
            values(update_values)
        session.execute(update_statement)

        return True

    @staticmethod
    def is_hml_processed(session, hml_entry_id):
        """
        Check if HML has already been processed

        If the hml status is set to xml_parse_complete or not.

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: The foreign key to the hml table

        Returns:
            True if hml is already processed else false

        Raises:
            Exception: if there is no HML row with given id
        """

        # statement to get the hml_status of hml with given id
        select_hml_status_query = select([Hml.hml_status])\
            .where(Hml.hml_id == hml_entry_id)

        # get hml status of given hml
        result_proxy = session.execute(select_hml_status_query)
        if not result_proxy:
            raise Exception(
                "HML with id: {} not found in database".format(hml_entry_id)
                )

        hml_status, = result_proxy.fetchone()

        return hml_status == HmlStatusEnum.xml_parse_complete


    @staticmethod
    def upsert_hml_xml_row(session, hml_entry_id, xml_index, lid, pedts):
        """
        Upsert an entry in HML XML table

        Create an entry in the hml_xml analytics table with details provided for
        XML from the HML. If the row is already present, update with new values.

        Args:
            session: current sqlalchemy session to execute this transaction
            hml_entry_id: The foreign key to the hml table
            xml_index: the position of xml in parent hml file. It can be used to
                track down a malformed XML along with lid and pedts below
            lid: location identifier of the observation or forecast
            pedts: physical-element, duration and type-source value for
                observation or forecast

        Returns:
            The synthetic key id of the row just inserted

        Raises:
            IntegrityError:
                * if missing non-null field while inserting or
                * violating unique key constraint
        """

        # default status is inserted as task created
        hml_xml_row = {
            const_hml_xml.COLUMN_HML_ID: hml_entry_id,
            const_hml_xml.COLUMN_XML_INDEX: xml_index,
            const_hml_xml.COLUMN_LID: lid,
            const_hml_xml.COLUMN_PEDTS: pedts,
            const_hml_xml.COLUMN_XML_STATUS: HmlXmlStatusEnum.parse_task_created,
            const_hml_xml.COLUMN_XML_STATUS_TS: utcnow()
        }

        return DBManager.upsert_rows(
            session=session,
            model_name=HmlXml,
            rows=[hml_xml_row],
            index_elements=[
                const_hml_xml.COLUMN_HML_ID,
                const_hml_xml.COLUMN_XML_INDEX
            ]
        )
