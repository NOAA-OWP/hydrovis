#!/bin/bash

# This script can be used to read all hml files from a directory and run the
# HML receiver script that will upload the files to object store, create an
# entry in database, and push an event to hml event queue with instruction on
# how to download those files from object store. They will be downloaded by
# HML splitter application and split into individual XML documents and put back
# into object store for XML ingester to parse and save in database.
# This script just cats the HML file to HML receiver and is completely unaware
# of any environment variables that receiver may need to process the file.
#
# NOTE: HML Receiver requires Python 3 to run.
#
# arguments:
#    -d|--hml-dir: REQUIRED - The path to a directory containing hml files
#    -m|--mode: dev/prod to source .env.dev or .env.prod
#    -h|--help: OPTIONAL - To see the help on how to use this script
#
# Example Usage:
#    <script> -d /tmp/hml/exmaples
#    <script> --hml-dir /tmp/hml/examples

echo "Run time: $(date)"

# function: show formatted error message and exit
error() {
    printf "%b\n" "$@"
    exit 1
}

mode=dev

# get command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case "$key" in
        -d|--hml-dir)
            hml_dir="$2"
            shift # get past the argument
            ;;
        -m|--mode)
            mode="$2"
            shift
            ;;
        -h|--help)
            sed -n 3,18p "$0" | sed 's/#//'
            exit 0
            ;;
        *)
            error "Error: Unrecognized arguments. Please use -h to see help."
    esac
    shift # get past argument value or flag
done

# make sure that user has provided at least a directory containing hml files
if [[ -z "$hml_dir" ]]; then
    error "You must provide a directory containing hml files to continue. "\
        "Please see help using -h."
fi

if [[ ! -d "$hml_dir" ]]; then
    error "HML dir: '$hml_dir' is not a valid directory. Aborting!"
fi

echo "HML files' directory provided: ${hml_dir}"

script_dir="$( echo "$( dirname "$( readlink -f -- "$0" )" )" )"

# make sure that environment variables are sourced from .env file
# This is a way to avoid having export in front of every env variable defined.
env_file=.env.dev
if [[ $mode == 'prod' ]]; then
    env_file=.env.prod
fi
echo "Sourcing environment variable file: ${script_dir}/${env_file}"
set -a; source "${script_dir}/${env_file}"; set +a

# process files (assuming they are hml) from the directory specified and remove
# them if the processing was successful
NCPUS=$( nproc )

# This is an estimate
NUMBER_FILES=$( find "${hml_dir}" -ignore_readdir_race -type f | wc -l )
date +"%Y-%m-%d %H:%M:%S Found ${NUMBER_FILES} HML files to process"
if [ ${NUMBER_FILES} -gt 0 ]
then
    # Clear log files
    for slot in $( seq ${NCPUS} )
    do
        LOG_FILE="/tmp/hml_receiver_retry-$slot.log"
        if [ -f "${LOG_FILE}" ]
        then
            rm -f "${LOG_FILE}"
        fi
    done

    # Utilize all available CPUs to catch up.
    find "${hml_dir}" -ignore_readdir_race -type f \
        -printf "%T@ date +\"%%Y-%%m-%%d %%H:%%M:%%S Processing %p\"; \
        python3 ${script_dir}/hml_receiver.py -n %f < %p && \
        rm -f %p && date +\"%%Y-%%m-%%d %%H:%%M:%%S Completed %p\"\n" | \
        sort -n -r | cut -d " " -f 2- | \
        xargs -I {} -d "\n" -P ${NCPUS} --process-slot-var=slot \
            sh -c '({}) >> /tmp/hml_receiver_retry-$slot.log'

    date +"%Y-%m-%d %H:%M:%S Done processing"
fi

# Delete empty directories
find "$hml_dir" -mindepth 1 -type d -empty -delete

exit 0

