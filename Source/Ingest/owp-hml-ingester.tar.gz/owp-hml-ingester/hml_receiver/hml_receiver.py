#!/usr/bin/env python3
"""
This script is meant to receive an HML file from a unix pipe. It will store the
file to object store, save an entry for it in database, and publish an event to
hml queue in RabbitMQ with info about how to get the file. This will trigger any
HML consumers like HML splitters listening on that queue to download that file
from object store and process it.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/23/2018
"""

# Import system libraries first
from datetime import datetime
import json
import sys
import os
import logging
from optparse import OptionParser
import urllib

import pika

import boto3
from boto3.exceptions import S3UploadFailedError
from botocore.vendored.requests.exceptions import ConnectTimeout
from botocore.exceptions import ClientError

# Module imports
from config.ConfigReader import ConfigReader
from constants import app, conf, log, hml_message
from rabbitmq.rabbitmq import RabbitMQManager
from database.db_manager import DBManager

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


def setup_logging(conf_log):
    """
    Configures logger

    This function sets up the application logger by setting its log level,
    target, log format, etc from the information provided in input tuple.

    Args:
        conf_log: a tuple representing values from log section of conf file

    Returns:
        This function doesn't return anything

    Raises:
        Exception in case log target is not specified in configuration file
    """

    conf_log_level, conf_log_target, conf_log_file, conf_log_format = conf_log

    # set log level (don't allow any level higher than INFO)
    if conf_log_level == conf.LOG_DEBUG_LEVEL:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO

    logger.setLevel(log_level)

    # Mark existing default handler to be removed if another handler
    # is specified
    if logger.handlers:
        default_handler = logger.handlers[0]
        logger.removeHandler(default_handler)
        default_handler = None
    else:
        default_handler = None

    logger.propagate = 0

    # set log target to be a file or stdout
    if conf_log_target == conf.LOG_FILE:

        # default to file name in conf file if log file name is not provided
        if not conf_log_file:
            conf_log_file = log.DEFAULT_FILENAME

        log_handler = logging.FileHandler(conf_log_file)

    elif conf_log_target == conf.LOG_STREAM:
        log_handler = logging.StreamHandler(sys.stdout)

    else:
        raise Exception('Provided logging target is not valid. Check config.')

    # set log message format
    if not conf_log_format:
        conf_log_format = log.DEFAULT_FORMAT

    log_formatter = logging.Formatter(
        fmt=conf_log_format,
        datefmt=log.DEFAULT_DATE_FORMAT
        )

    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)

    #logger.info("The logging mechanism has been created.")


def setup_options():
    """
    Configures command line arguments

    Returns:
        A tuple of program options and arguments in that order

    """

    usage_message = app.NAME + " [Options] --file-name or --provided-path <filename>"
    option_parser = OptionParser(
        usage=usage_message,
        version=app.NAME + " " + app.VERSION,
        description="HML receiver is designed to receive an HML file contents "\
            "from stdin. In other words it needs to be at the receiving end of "\
            "the unix pipe. It will store the file to either an object store "\
            "or a filesystem, save an entry in a database, and publish an "\
            "event to hml queue indicating that a new hml file has arrived "\
            "and ready to be processed from either the object store or the "\
            "filesystem."
    )

    # path to application configuration file
    dir_path = os.path.dirname(os.path.realpath(__file__)) + "/"
    option_parser.add_option(
        "-f", "--config-file",
        dest="config_file",
        default=dir_path + conf.DEFAULT_CONFIG_FILENAME,
        help="Optional: The path to the configuration file. default: ./" + \
             conf.DEFAULT_CONFIG_FILENAME
    )

    # optional: if we want to save files to disk that failed processing
    option_parser.add_option(
        "-d", "--write-dir",
        dest="hmls_path",
        default=None,
        help="Optional: The directory path to save HMLs when processing fails"
    )

    # Either --file-name or --provided-path needs to be specified

    # name of file hml file from stdin
    option_parser.add_option(
        "-n", "--file-name",
        dest="file_name",
        help="The name of file to be processed"
    )

    # Full path of existing hml file to reference
    option_parser.add_option(
        "-p", "--provided-path",
        dest="provided_path",
        default=None,
        help="Optional: The path of an existing file to use instead of stdin."
    )

    return option_parser.parse_args()


def get_options():
    """
    Get command line options and config parameters
    """

    # parse command line options and arguments
    options, _ = setup_options()

    # make sure that file name or provided file is specified
    if not options.file_name and not options.provided_path:
        raise Exception("Error: You must specify a filename or provided file path to continue.")

    return options


def get_configs(config_file, provided_path):
    """
    Get configuration parameters from a config file
    """

    # parse config params
    try:
        config_reader = ConfigReader(config_file)
        configs = config_reader.read_configs(provided_path)
    except Exception as exception:
        print("Error: ", str(exception))
        raise

    return configs


def get_hml_contents():
    """
    Returns the byte contents of HML file coming over standard in

    We expect the input file in ASCII format. It needs to make sure that the
    user is not providing the hml file over stdin rather piping its contents.

    Returns:
        A byte array of contents of an HML file

    Raises:
        Exception: if hml contents are entered manually on standard in
    """

    # make sure that hml contents are piped in
    if sys.stdin.isatty():
        raise Exception(
            "HML file contents must be piped and not manually entered."
            )

    # Using straight binary read
    return sys.stdin.buffer.read()

def save_hml(path, hml_name, hml_contents):
    """
    Write hml contents to a file on disk at specified path

    Args:
        path: full path to the write directory
        hml_name: name of hml file
        hml_contents: the byte string of hml contents

    Raises:
        IOError: an error opening file
    """

    # Combine path
    complete_hml_path = os.path.join(path, hml_name)

    # make sure that the parent directory exists
    # This is done in case the hml_name has parent subdirectories
    os.makedirs(os.path.dirname(complete_hml_path), exist_ok=True)

    logger.debug("Writing HML to {0}".format(complete_hml_path))

    # save hml file on disk
    with open(complete_hml_path, 'wb') as hml_file_object:

        hml_file_object.write(hml_contents)

    logger.debug("Finished writing HML to {0}".format(complete_hml_path))

def prepend_datetime(filename):
    """
    Prepend datetime to the filename and return modified filename

    It modifies hml file name by prepending yyyy/mm/dd/hh/ to the name so that
    when we put object in the object store, it appears to be stored inside the
    logical hierarchy of folders inside the bucket. The HML files received over
    LDM has this information stored in filename after the last '.' but if it is
    not there then we can get the above information from current date and time.

    Args:
        filename: name of the HML file

    Returns:
        Modified file name with date time prepended to it
    """

    current_time = None

    period_index = filename.rfind('.')

    if period_index > -1:

        datehour = filename[period_index + 1:]

        try:
            current_time = datetime.strptime(datehour, '%Y%m%d%H')
        except ValueError:
            pass

    if not current_time:
        current_time = datetime.utcnow()

    year = current_time.year
    month = "{:02d}".format(current_time.month)
    day = "{:02d}".format(current_time.day)
    hour = "{:02d}".format(current_time.hour)

    return "{0}/{1}/{2}/{3}/{4}".format(year, month, day, hour, filename)

def place_hml_file(conf_file_output, hml_name, hml_contents):
    """
    Place an HML file to a configured directory path.

    This function creates a parent directory tree based on a configured
    directory path plus the HML file's datestamp suffix.

    Args:
        conf_file_output: Output directory file configation like
            local directory path and remote directory path

    Returns:
        A path to the placed HML file. This can be a URL.

    Exceptions:
        None
    """
    # Get configuration
    output_directory, output_host = conf_file_output

    # Prepend timestamp directory tree
    timestamped_path = prepend_datetime(hml_name)
    remote_hml_file = output_host + '/' + timestamped_path

    # Write out file
    save_hml(output_directory, timestamped_path, hml_contents)

    return remote_hml_file

def upload_to_objectstore(conf_objectstore, hml_name, hml_contents):
    """
    Upload an HML file to the object store


    Args:
        conf_objectstore: Object store configuration like hostname, port,
            credentials etc.
        hml_name: The name of HML file passed in from command line
        hml_contents: the byte string of hml contents from standard in

    Returns:
        The complete object key of newly uploaded HML file

    Raises:
        ClientError: if trouble finding the bucket listed in configuration file
        S3UploadFailedError: if s3 fails to upload the file for some reason
        ConnectTimeout: if connection timed out while trying to upload file
    """

    # read hml files and save hml file in object store
    ohost, oport, obucket, oaccess_key, osecret_key = conf_objectstore

    # Endpoint URL is only present if host and port is defined
    if ohost and oport:
        oendpoint_url = "{0}:{1}".format(ohost, oport)
    else:
        oendpoint_url = None

    object_store_client = boto3.client(
        's3',
        endpoint_url=oendpoint_url,
        aws_access_key_id=oaccess_key,
        aws_secret_access_key=osecret_key,
        config=boto3.session.Config(signature_version='s3v4')
    )

    # put hml file in the yyyy/mm/dd/hh logical sub-directory in object store
    object_key = prepend_datetime(hml_name)

    # test if bucket exists
    try:
        object_store_client.head_bucket(Bucket=obucket)
    except ClientError as exception:
        error_code = int(exception.response["Error"]["Code"])
        if error_code == 404:
            logger.error(
                "You MUST have a write accessible bucket defined with name: "\
                "'{0}'".format(obucket)
            )
        raise

    logger.debug("Uploading hml file: {0}".format(hml_name))
    try:

        object_store_client.put_object(
            Body=hml_contents,
            Bucket=obucket,
            Key=object_key
        )
    except (S3UploadFailedError, ConnectTimeout):
        raise

    logger.info("Uploaded hml file: {0}".format(hml_name))

    # Behavior dependant on whether or not host is specified
    if ohost and oport:
        return "{0}:{1}/{2}/{3}".format(ohost, oport, obucket, object_key)
    else:
        return "s3://{2}/{3}".format(obucket, object_key)


def publish_to_rabbitmq(conf_rabbitmq, hml_info_message):
    """
    Send an event notification to RabbitMQ about new HML file arrival

    This function publishes an event to RabbitMQ HML queue with the name as
    provided in the configuration file. The event is a JSON with a url of the
    HML file in object store. By this time the HML file is already uploaded to
    the Object store so HML consumers can download and process HML as soon as
    this function publishes the HML event.

    Args:
        conf_rabbitmq: RabbitMQ exchange, HML queue, etc
        hml_info_message: A python dictionary with detail about HML file in
            object store

    Returns:
        None

    Raises:
        Exception: if message is not delivered

    """

    # get RabbitMQ configurations
    rmq_url, rmq_exchange, rmq_hml_event_queue, \
        rmq_hml_prefetch_count, rmq_dl_hml_message_ttl = conf_rabbitmq

    # we need a channel to RabbitMQ XML queue in both producer/consumer mode
    rmq_manager = RabbitMQManager(rmq_url)
    rmq_manager.setup(rmq_exchange, rmq_hml_event_queue, rmq_dl_hml_message_ttl)

    with rmq_manager.get_channel(rmq_hml_prefetch_count) as hml_queue_channel:

        # turn on delivery confirmations
        hml_queue_channel.confirm_delivery()

        try:
            hml_queue_channel.basic_publish(exchange=rmq_exchange,
                                            routing_key=rmq_hml_event_queue,
                                            body=json.dumps(hml_info_message),
                                            properties=pika.BasicProperties(delivery_mode=2),
                                            mandatory=True)
        except pika.exceptions.NackError:
            raise Exception("Failed to deliver hml message with url: '{}' and "\
                            "db_entry_id: {}".format(hml_info_message[hml_message.HML_URL_FIELD],
                                                     hml_info_message[hml_message.HML_ID_FIELD]))


def main(options=None):
    """
    This is the entry point for HML splitter.

    Args:
        options: An object containing options for when this is being called
            called by another function instead of the command line. Otherwise,
            this default to None, and is filled by command line arguments

    """

    try:

        # setup options
        if not options:
            options = get_options()

        hml_name = options.file_name
        hmls_path = options.hmls_path
        provided_path = options.provided_path

        # get configs
        configs = get_configs(options.config_file, provided_path)
        conf_rabbitmq, conf_db, conf_log, conf_file_output, conf_objectstore = configs

        # setup logging
        setup_logging(conf_log)

        # HML name is typically not specified along with provided path
        if provided_path:
            logger.debug("Using config file: {0} for {1}".format(options.config_file,
                                                                 provided_path))
        else:
            logger.debug("Using config file: {0} for {1}".format(options.config_file,
                                                                 hml_name))

        # No need to read stdin and place file if file has already been placed.
        if provided_path:
            uploaded_object_key = provided_path
        else:

            # get hml contents from standard in
            hml_contents = get_hml_contents()

            logger.debug("Fetched contents of {0}".format(hml_name))

            # Behavior dependent on whether or not file output was configured
            if all(conf_file_output):
                # Place the HML file in a file directory structure
                uploaded_object_key = place_hml_file(conf_file_output, hml_name,
                                                     hml_contents)
            else:
                # upload the HML file to object store
                uploaded_object_key = upload_to_objectstore(
                    conf_objectstore,
                    hml_name,
                    hml_contents
                    )

        ## save an entry in database with the name of file and upload time
        ## If the database connection string is empty, do not insert a record
        ## in the database or the RabbitMQ exchange
        hml_entry_id = None
        db_connection_string, = conf_db
        if db_connection_string:
            with DBManager(db_connection_string) as db_session:
                hml_entry_id = DBManager.insert_hml(db_session, uploaded_object_key)

            logger.info(
                "Added an entry in database with id: {0} for object key: '{1}'".format(
                    hml_entry_id,
                    uploaded_object_key
                )
            )

            # Create a task in RabbitMQ if the database connection string was
            # supplied. The template for HML queue message is defined below.
            # The HML consumers need to know the fields available to perform
            # any action on them. CAUTION: Any change to this message entails
            # a change in HML consumers.
            hml_info_message = {
                hml_message.HML_URL_FIELD: uploaded_object_key,
                hml_message.HML_ID_FIELD: hml_entry_id
            }
            publish_to_rabbitmq(conf_rabbitmq, hml_info_message)

            logger.info(
                "Delivered hml event to RabbitMQ with url:'{}' and "\
                "db entry id: {}".format(
                    hml_info_message[hml_message.HML_URL_FIELD],
                    hml_info_message[hml_message.HML_ID_FIELD]
                )
            )
        else:
            logger.info("Not using a database. Saved file to {0}".format(uploaded_object_key))

    except BaseException as exception:
        logger.exception(str(exception))

        # optionally: save hml file on disk to be reprocessed later
        if hmls_path is not None and provided_path is None:
            save_hml(hmls_path, hml_name, hml_contents)

        # return exit code 1 to indicate error
        sys.exit(1)

    # if everything went fine, return exit code 0
    # This is the default, and can be skipped for additional compatibility 
    # sys.exit(0)


# Lambda function
def lambda_function(event, context):
    """
    A callable function entry into the HML receiver.

    This method is used for calling the HML receiver from a python environment,
    in this case as an AWS Lambda function.

    Args:
        event (dictionary): A dict that contains the parameters sent when the
            function is invoked.
        context: The context in which the function is called.

    """

    for record in event['Records']:

        # Get the object from the event and show its content type
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'], encoding='utf-8')
        object_path = urllib.parse.urlunparse(['s3', bucket, key, None, None, None])

        # Create replacement for command line options for main
        class options_class():
            """
            A class to contain command line options
            """
            pass

        custom_options = options_class()

        # Will use default config location
        custom_options.config_file = conf.DEFAULT_CONFIG_FILENAME
        custom_options.hmls_path = None
        custom_options.file_name = None
        custom_options.provided_path = object_path

        # Call main.
        main(options=custom_options)

# Is this main?
if __name__ == "__main__":
    main()
