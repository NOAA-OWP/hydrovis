#!/usr/bin/bash

# Primarily meant to be used for LDM PIPE action.

# The script expects the name of HML file received as first argument and its
# contents over starndard input. It sources the environment variables for python
# sub-process and passes HML contents to python process's standard it for
# further processing.

# get the hml receiver root directory
script_dir="$( echo "$( dirname "$( readlink -f -- "$0" )" )" )"

# source and export environment variables for python sub-process
set -a; source "${script_dir}/.env.prod"; set +a;

# pipe the HML file coming over stdin to the hml_receiver.py
"${script_dir}/hml_receiver.py" -n "$1" <&0
