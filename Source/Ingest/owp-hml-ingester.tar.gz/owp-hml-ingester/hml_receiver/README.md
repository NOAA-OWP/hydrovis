# HML Receiver

HML receiver is designed to receive an HML file contents from stdin. In other
words it needs to be at the receiving end of a unix pipe. It will store the file
to object store, save an entry in database, and publish an event to hml queue
indicating that a new hml file has arrived and is ready to be processed from the
object store.

## Prerequisites

The application expects to be run using Python 3.4 so either install this 
version of Python or use virtual environment to run Python 3.4. This Python
version is available via yum on CentOS 7.

Once you have the right version, you will need to install the python packages 
dependencies using:
```bash
pip install -r requirements.txt
```

Next populate the environment variables defined in `.env.dev` for development
or `.env.prod` file for production environment. It has three sections: 
object store, database, and RabbitMQ. 

Each section needs all the environment variables listed. Using these
application decides how to connect to the above resuources each of which is
essential to the operation of the application. Once you do that, then issue
following command on the terminal:

```bash
set -a; source .env.prod; set +a;
``` 
It is a neat way to avoid having export with each environment variable in the
`.env.*` files. It will export all the envirobment variables in the file to your
environment. This means any of these environment variables will be accessible to
any sub-process in that shell including our application. Some environment
variables that contain sensitive information, may be ommitted but then you must
define them in your environment before proceeding.

Finally, have a look at the `receiver.conf` configuration file. It defines how
the environment variables in `.env.*` files are used. In addition, it provide you
control over log message level, names of exchanges and queue names in RabbitMQ
etc. You can override any environment variable by hardcoding it in the 
configuration file. Please read instructions and precautions mentioned before
RabbitMQ related environment variables as a change in their value pertains to
change in configuration of other elements of HML Ingester like HML Splitter, 
XML Ingester and HML Sweeper.

## Getting Started

Here is how you can run HML Receiver for an example HML file:

```bash
cat test/SRCA52_TJSJ_201354_44559049.2018022013 | \
   ./hml_receiver.py -n SRCA52_TJSJ_201354_44559049.2018022013
```
It is important to have a date-hour appended to the name of the HML file passed
to the HML Receiver preceded with a '.' in `YYYYMMDDHH` format. HML Receiver
does't care about the actual name of the file. The date-hour information is used
to compute the object-key by which the HML file will be stored in the object
store. The format of the object-key is `bucket-name/YYYY/MM/DD/HH/hml-name`. If
date-hour information is not found in the format expected, current UTC date-hour
will be used to construct the key. This may work well with the current HML files
received over SBN LDM but won't work with historical files. So special care
needs to be taken in the later case.

Please note that it is required to have a bucket with the name provided in
`receiver.conf` file that has public read permissions set on it so that the
splitter can read the HML file from object store without the credentials. This
is helpful because then only HML Reciver needs to have object store credentials.

You should see the log message indicating upload process of the file. If you see
that message then application has worked as expected, else most probably
something is wrong with the environment variables.

## Deployment

This script is meant to process one HML file at a time from a unix pipe so it
can be run manually or against the PIPE action in Unidata's LDM.
If you want to process the HML files from a directory, you should instead use
`dir_hml_receiver.bash`. 

If used in LDM, you can used the following rule in pqact.conf file to subscribe
to HML products and process them using HML Receiver:
```
IDS|DDPLUS  ^(....[0-9][0-9]) (....) (..)(..)(..) (/p)(HML...)
    PIPE    -close   path-to-hml-receiver/hml_receiver.py -n \1_\2_\3\4\5_\7_(seq).%Y%m%d%H
```

A version of dockerized-LDM that clones HML Receiver from Virual LAB git repo is
provided [here](https://vlab.ncep.noaa.gov/redmine/projects/sbn-ldm).
