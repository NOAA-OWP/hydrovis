sed -i "" -e "s/^target=file/target=stream/g" receiver.conf && \
zip -r HML_receiver_lambda.zip config constants database hml_receiver.py rabbitmq receiver.conf && \
sed -i "" -e "s/^target=stream/target=file/g" receiver.conf
