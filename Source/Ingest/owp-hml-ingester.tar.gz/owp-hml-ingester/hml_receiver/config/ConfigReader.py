"""
This class is used to parse the configuration file contents


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/31/2017
"""

import logging
from configparser import SafeConfigParser, NoOptionError, NoSectionError
import os

# local modules
from constants import app, conf


# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class ConfigReader(object):

    def __init__(self, config_file):

        # path to the config file
        self.config_file = config_file

    def get_config_value(self, section, parameter_name):
        """
        Get value of a configuration parameter in specified section

        Args:
            section: The section to search from in configuration file
            parameter_name: The name of the parameter we are searching for
        Returns:
            String value of the parameter or None if not found
        """

        try:

            configuration = SafeConfigParser(os.environ)
            configuration.read(self.config_file)
            # Will skip warning if option not found
            if configuration.has_option(section, parameter_name):
                value = configuration.get(section, parameter_name )
            else:
                return None
        except (NoSectionError, NoOptionError) as err:

            logger.warning(err)
            return None

        return value

    def read_conf_rabbitmq( self ):
        '''
        Parse the rabbitmq section of configuration file

        Args:
            There are no arguments
        Returns:
            A tuple with connection url to rabbitmq node. Keeping tuple for
            ease of extensibility.
        Raises:
            Exception: if url is missing
        '''

        # make sure user specified url parameter
        rabbitmq_url = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_URL
            )

        if rabbitmq_url is None:
            raise Exception(
                "You must provide url to RabbitMQ node/cluster. Aborting!"
                )

        # get exchange name specified
        rabbitmq_exchange = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_EXCHANGE
            )

        if rabbitmq_exchange is None:
            raise Exception(
                "You must provide a name of RabbitMQ exchange. Aborting!"
                )

        # hml event queue if splitter is used in consumer mode
        rabbitmq_hml_event_queue = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_EVENT_QUEUE
        )

        if rabbitmq_hml_event_queue is None:
            raise Exception(
                "You must provide a name of hml queue. Aborting!"
                )

        # hml prefetch count
        rabbitmq_hml_prefetch_count = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_PREFETCH_COUNT
        )

        try:
            rabbitmq_hml_prefetch_count = int(rabbitmq_hml_prefetch_count)
        except ValueError:
            raise Exception(
                "You must provide an integer prefetch count for "\
                "hml queue. Aborting!"
                )

        # dead letter hml queue message ttl
        rabbitmq_dl_hml_message_ttl = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_DL_HML_TTL
        )

        try:
            rabbitmq_dl_hml_message_ttl = int(rabbitmq_dl_hml_message_ttl)
        except ValueError:
            raise Exception(
                "You must provide an integer message time to live for "\
                "dead letter hml queue. Aborting!"
                )

        return ( 
            rabbitmq_url, 
            rabbitmq_exchange, 
            rabbitmq_hml_event_queue,
            rabbitmq_hml_prefetch_count,
            rabbitmq_dl_hml_message_ttl
            )

    def read_conf_db( self ):
        '''
        Parse the database section of configuration file

        Args:
            There are no arguments

        Returns:
            A tuple containing the database connection string if applicable
        '''

        # get database connection string
        conf_connection_string = self.get_config_value(
            conf.DATABASE_SECTION,
            conf.DATABASE_CONNECTION_STRING
        )

        return (conf_connection_string, )

    def read_conf_log( self ):
        '''
        Parse the log section of configuration file

        Args:
            There are no arguments
        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get log debug level
        conf_log_level = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_LEVEL
        )

        # log to file|stream
        log_output_to = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_TARGET
        )

        # log file, if applicable
        log_file = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_FILE_PATH
        )

        # log format
        log_format = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_FORMAT
        )

        return (conf_log_level, log_output_to, log_file, log_format)

    def read_conf_file_output( self ):
        '''
        Parse the file output section of the configutation file

        Args:
            There are no arguments
        Returns:
            A tuple containing an output directory path to contain files
            instead of writing to an object store
        '''

        # get file output directory path
        conf_file_output_directory = self.get_config_value(
            conf.FILE_OUTPUT_SECTION,
            conf.FILE_OUTPUT_DIRECTORY
        )

        # get file remote host
        conf_file_output_host = self.get_config_value(
            conf.FILE_OUTPUT_SECTION,
            conf.FILE_OUTPUT_HOST
        )

        return (conf_file_output_directory, conf_file_output_host )


    def read_conf_objectstore(self):
        """
        Parse the objectstore section of configuration file

        Args:
            There are no arguments
        Returns:
            A tuple containing the object store host, port, bucket, access and
            secret key that are defined by environment variables
        Raises:
            Exception: f missing the bucket, access or secret key to object store
        """

        # host
        host = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_HOST
        )

        # port
        port = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_PORT
        )

        # hml bucket
        bucket = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_BUCKET
        )
        bucket.strip()

        # access key
        access_key = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_ACCESSKEY
        )
        access_key.strip()
        if not access_key:
            access_key = None

        # secret key
        secret_key = self.get_config_value(
            conf.OBJECTSTORE_SECTION,
            conf.OBJECTSTORE_SECRETKEY
        )
        secret_key.strip()
        if not secret_key:
            secret_key = None

        return (host, port, bucket, access_key, secret_key)

    def check_conf_objectstore( self, conf_objectstore ):
        '''
        This function checks object store-related configuration options.

        This function makes sure that the bucket name and the keys are
        specified in the returned tuple from the configuration file reader.

        Args:
            A tuple containing the object store host, port, bucket, access, and
            secret key that are defined by environment variables.
        Raises:
            Exception: if missing the bucket, access or secret key to object
            store
        '''

        host, port, bucket, access_key, secret_key = conf_objectstore

        if not bucket:
            raise Exception(
                "You must provide object store bucket to upload hmls. Aborting!"
                )
        if not access_key:
            raise Exception(
                "You must provide the access key to object store. Aborting!"
                )
        if not secret_key:
            raise Exception(
                "You must provide the secret key to object store. Aborting!"
                )

    def read_configs( self, provided_path=None ):
        '''
        This function parses all configuration parameters

        The function reads all sections of the configuration file and return a
        tuple containing the tuples one for each section.

        Args:
            provided_path: A optional flag specifying that a HML path has
                already been provided, and object store configuration does not
                need to be confirmed.

        Returns:
            A tuple of tuples each corresponding to a configuration section
        Raises:
            Exception: if any of the section parser raises exception
        '''

        # rabbitmq section
        conf_rabbitmq = self.read_conf_rabbitmq()

        # db section
        conf_database = self.read_conf_db()

        # file output section
        conf_file_output = self.read_conf_file_output()

        # log section
        conf_log = self.read_conf_log()

        # object store section
        conf_objectstore = self.read_conf_objectstore()

        # Check object store contents if file output is not fully specified
        if not all(conf_file_output) and not provided_path:
            self.check_conf_objectstore(conf_objectstore)

        return (conf_rabbitmq, conf_database, conf_log, conf_file_output,
                conf_objectstore)
