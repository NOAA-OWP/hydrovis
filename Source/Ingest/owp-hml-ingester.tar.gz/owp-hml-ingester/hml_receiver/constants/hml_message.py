""" 
This file contains the constants that are associated with an HML message. A copy
of this file is required in the HML Splitter as well. Any change here should be
reproduced in the constant file for HML message in HML splitter.
  
United States Department of Commerce 
NOAA (National Oceanic and Atmospheric Administration) 
National Weather Service 
Office of Water Prediction 
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

## @var HML_URL_FIELD
# The url field for HML file in the object store
HML_URL_FIELD = "url"

## @var HML_ID_FIELD
# The synthetic key id field for HML entry in database 
HML_ID_FIELD = "id"
