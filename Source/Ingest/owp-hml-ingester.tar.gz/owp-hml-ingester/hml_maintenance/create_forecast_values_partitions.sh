#!/bin/bash
###############################################################################
#
#  create forecast_values table partitions
#
#  This script creates monthly (and yearly partitions) for the forecast_values
#  table.
#
#  History:
#  Anders Nilsson, UCAR, 2019-10-18, Created
#  Anders Nilsson, UCAR, 2019-11-18, Added use of latest triggers
#  Anders Nilsson, UCAR, 2020-04-09, Removed use of latest triggers
#  Anders Nilsson, UCAR, 2020-05-20, Uses declarative partitioning
#  Anders Nilsson, UCAR, 2020-07-02, Moves data from default partition
#                                    before attaching
#
###############################################################################

### Constants ###

    DATABASE="rfcfcst_dev"
    SCHEMA="public"
    PARENT_TABLE="forecast_values"
    PARTITION_COLUMN="product_time"
    USER_OWNER="rfc_fcst"
    USER_GUEST="rfc_fcst_ro"

    SCRIPTS_DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

### Get from environment, if present ###

    if [ -n "${DB}" ]
    then
      DATABASE="${DB}"
    fi
    if [ -n "${DBHOST}" ]
    then
      export PGHOST="${DBHOST}"
    fi
    if [ -n "${DBUSER}" ]
    then
      export PGUSER="${DBUSER}"
    fi
    if [ -n "${DBPORT}" ]
    then
      export PGPORT="${DBPORT}"
    fi
    if [ -n "${DBPASSWORD}" ]
    then
      export PGPASSWORD="${DBPASSWORD}"
    fi

### Includes ###

    . ${SCRIPTS_DIR}/message_function.sh    

### Usage ###
function usage()
{
    echo "USAGE:"
    echo "  $0 {-help}"
    echo "  $0 <year> <month>"
    echo ""
    echo "ARGUMENTS"
    echo "   -h    - (optional) Display help"
    echo "   year  - Year of partition start date"
    echo "   month - Month of partition start date"
}

### Cleanup function ###
function cleanup()
{
    ### Right now does nothing ###
    true
}

### Determine if a table already exists ###

function table_exists()
{
    EXISTS=$( psql -d ${DATABASE} -tAc "SET search_path TO ${SCHEMA};
                                        SELECT COUNT ( * ) FROM pg_class
                                        WHERE relname = '$1' AND
					( relkind = 'r' OR relkind = 'p' ) AND
                                        pg_table_is_visible(oid)" )
    if [ ${EXISTS} -eq 1 ]
    then
        return 0
    else
        return 1
    fi
}

### Duplicate foreign key constraints ###
function duplicate_foreign_keys()
{
    local SOURCE_TABLE=$1
    local DESTINATION_TABLE=$2

    local CONSTRAINT_NAME
    local DEFINITION

    IFS="
"
    CONSTRAINTS=$( psql -d ${DATABASE} -tAc "SET search_path TO ${SCHEMA};
                                             SELECT t1.conname, pg_get_constraintdef(t1.oid)
                                             FROM pg_constraint AS t1,
                                                  pg_class AS t2
                                             WHERE t1.contype = 'f' AND
                                                   t1.conrelid = t2.oid AND
                                                   t2.relname = '${SOURCE_TABLE}' AND
                                                   pg_table_is_visible(t2.oid)" )
    for LINE in ${CONSTRAINTS}
    do
        CONSTRAINT_NAME=$( echo "${LINE}" | cut -d \| -f 1 )
        DEFINITION=$( echo "${LINE}" | cut -d \| -f 2 )

        ### Change constraint name ###
        CONSTRAINT_NAME="${CONSTRAINT_NAME/${SOURCE_TABLE}/${DESTINATION_TABLE}}"
       
        ### Add constraint ###
        psql -d ${DATABASE} -c "ALTER TABLE ${DESTINATION_TABLE} ADD CONSTRAINT
                                ${CONSTRAINT_NAME} ${DEFINITION}" 

    done

}

### Create default partition ###
function create_default_partition()
{
    local TABLE=$1

    psql -d ${DATABASE} -c "SET search_path TO ${SCHEMA};
                            CREATE TABLE ${TABLE}_default
                            ( LIKE ${TABLE} INCLUDING ALL )"
}

### Attach default partition ###
function attach_default_partition()
{
    local TABLE=$1
    psql -d ${DATABASE} -c "SET search_path TO ${SCHEMA};
                            ALTER TABLE ${TABLE}
                            ATTACH PARTITION ${TABLE}_default DEFAULT"
}

### Attach partition
function attach_partition()
{
    local TABLE=$1
    local DEFAULT_TABLE=$2
    local PARTITION_TABLE=$3
    local START_DATE=$4
    local STOP_DATE=$5

    # This also has to transfer any data from the default partition that would
    # reside in the new partition

    psql -d ${DATABASE} -c "SET search_path TO ${SCHEMA};
                            BEGIN WORK;
                            LOCK ${DEFAULT_TABLE} IN EXCLUSIVE MODE;
                            INSERT INTO ${PARTITION_TABLE}
                               SELECT * FROM ${DEFAULT_TABLE}
                               WHERE ${PARTITION_COLUMN} >= '${START_DATE}' AND
                                     ${PARTITION_COLUMN} < '${STOP_DATE}';
                            DELETE FROM ${DEFAULT_TABLE}
                            WHERE ${PARTITION_COLUMN} >= '${START_DATE}' AND
                                     ${PARTITION_COLUMN} < '${STOP_DATE}';
                            ALTER TABLE ${TABLE}
                            ATTACH PARTITION ${PARTITION_TABLE}
                            FOR VALUES FROM ( '${START_DATE}' ) TO ( '${STOP_DATE}' );
                            COMMIT;"
}

### Set permissions ###
function set_permissions()
{
    local TABLE=$1

    psql -d ${DATABASE} -c "SET search_path TO ${SCHEMA};
                            ALTER TABLE ${TABLE} OWNER TO ${USER_OWNER};
                            GRANT ALL ON TABLE ${TABLE} to ${USER_OWNER} ;
                            GRANT SELECT ON TABLE ${TABLE} to ${USER_GUEST} ;"
}


### Main ###

function main()
{

    ### From arguments ###

    local YEAR_START=$1
    local MONTH_START=$2

    ### Other local variables ###

    local MONTH_DATE_START
    local MONTH_DATE_STOP
    local MONTH_STOP
    local MONTH_SUFFIX
    local YEAR_DATE_START
    local YEAR_DATE_STOP
    local YEAR_NEXT
    local YEAR_STOP
    local YEAR_SUFFIX

    ### Determine first of next month ###

    YEAR_STOP=${YEAR_START}
    MONTH_STOP=$(( MONTH_START + 1 ))
    if [ ${MONTH_STOP} -eq 13 ]
    then
       MONTH_STOP=1
       ((YEAR_STOP=YEAR_START + 1))
    fi
    YEAR_NEXT=$(( YEAR_START + 1 ))

    MONTH_SUFFIX="$( printf "%04d%02d" ${YEAR_START} ${MONTH_START} )"
    MONTH_DATE_START="$( printf "%04d-%02d-01 00:00:00" ${YEAR_START} ${MONTH_START} )"
    MONTH_DATE_STOP="$( printf "%04d-%02d-01 00:00:00" ${YEAR_STOP} ${MONTH_STOP} )"

    YEAR_SUFFIX="$( printf "%04d" ${YEAR_START} )"
    YEAR_DATE_START="$( printf "%04d-01-01 00:00:00" ${YEAR_START} )"
    YEAR_DATE_STOP="$( printf "%04d-01-01 00:00:00" ${YEAR_NEXT} )"

    ### Write out commands ###

    COMMAND_YEAR1="SET search_path TO ${SCHEMA};
                   CREATE TABLE ${PARENT_TABLE}_${YEAR_SUFFIX}
                   ( LIKE ${PARENT_TABLE} INCLUDING ALL,
                     CHECK ( ${PARTITION_COLUMN} >= '${YEAR_DATE_START}' AND
                           ${PARTITION_COLUMN} < '${YEAR_DATE_STOP}' AND
                           extract( 'year' from ${PARTITION_COLUMN} ) = ${YEAR_START} ) )
                   PARTITION BY RANGE ( ${PARTITION_COLUMN} )"

    COMMAND_MONTH1="CREATE TABLE ${PARENT_TABLE}_${MONTH_SUFFIX}
                    ( LIKE ${PARENT_TABLE}_${YEAR_SUFFIX} INCLUDING ALL,
                      CHECK ( ${PARTITION_COLUMN} >= '${MONTH_DATE_START}' AND
                              ${PARTITION_COLUMN} < '${MONTH_DATE_STOP}' AND
                              extract( 'month' from ${PARTITION_COLUMN} ) = ${MONTH_START} ) )"

    ### Check for table existence before creating default table ###

    if ! table_exists ${PARENT_TABLE}_default
    then
        message info "Creating table ${PARENT_TABLE}_default"
        create_default_partition ${PARENT_TABLE}
        set_permissions ${PARENT_TABLE}_default
        attach_default_partition ${PARENT_TABLE}
    else
        message info "Default table ${PARENT_TABLE}_default already exists"
    fi    

    ### Check for table existence before creating yearly table ###

    if ! table_exists ${PARENT_TABLE}_${YEAR_SUFFIX}
    then
        message info "Creating table ${PARENT_TABLE}_${YEAR_SUFFIX}"
        psql -d ${DATABASE} -c "${COMMAND_YEAR1}"
        set_permissions ${PARENT_TABLE}_${YEAR_SUFFIX}
        attach_partition ${PARENT_TABLE} ${PARENT_TABLE}_default ${PARENT_TABLE}_${YEAR_SUFFIX} "${YEAR_DATE_START}" "${YEAR_DATE_STOP}"
    else
        message info "Parent table ${PARENT_TABLE}_${YEAR_SUFFIX} already exists"
    fi

    ### Check for yearly default table ###

    if ! table_exists ${PARENT_TABLE}_${YEAR_SUFFIX}_default
    then
        message info "Creating table ${PARENT_TABLE}_${YEAR_SUFFIX}_default"
        create_default_partition ${PARENT_TABLE}_${YEAR_SUFFIX}
        set_permissions ${PARENT_TABLE}_${YEAR_SUFFIX}_default
        attach_default_partition ${PARENT_TABLE}_${YEAR_SUFFIX}
    else
        message info "Default table ${PARENT_TABLE}_${YEAR_SUFFIX}_default already exists"
    fi

    ### Check for table existence before creating monthly table ###

    if ! table_exists ${PARENT_TABLE}_${MONTH_SUFFIX}
    then
        message info "Creating table ${PARENT_TABLE}_${MONTH_SUFFIX}"
        psql -d ${DATABASE} -c "${COMMAND_MONTH1}"
        set_permissions ${PARENT_TABLE}_${MONTH_SUFFIX}
        attach_partition ${PARENT_TABLE}_${YEAR_SUFFIX} ${PARENT_TABLE}_default ${PARENT_TABLE}_${MONTH_SUFFIX} "${MONTH_DATE_START}" "${MONTH_DATE_STOP}"
    else
        message info "Table ${PARENT_TABLE}_${MONTH_SUFFIX} already exists"
    fi
}

### Get arguments ###

    if [ $# -ne 2 ] || [ $1 = "-h" ]
    then
        usage
        exit 
    fi

### Initialize variables from arguments ###

    YEAR=$1
    MONTH=$2

### Check inputs ###

    if [ -z "${YEAR##*[!0-9]*}" ] || [ -z "${MONTH##*[!0-9]*}" ]
    then
        usage
        exit
    fi

### Strip lead zeroes

    YEAR=$( echo "${YEAR}" | sed -e "s/^[0 ]*//g" )
    MONTH=$( echo "${MONTH}" | sed -e "s/^[0 ]*//g" )

    if [ ${MONTH} -lt 1 ] || [ ${MONTH} -gt 12 ] || [ ${YEAR} -lt 1000 ]
    then
        usage
        exit
    fi

### Main ###

    main ${YEAR} ${MONTH}
