#!/bin/bash
###############################################################################
#
#  clean forecast_values table partitions
#
#  This script makes sure that the parent and yearly partitions of are empty
#  by moving any found rows into their intended partitions, creating them if
#  necessary.
#
#  History:
#  Anders Nilsson, UCAR, 2019-10-21, Created
#
###############################################################################

### Constants ###

    DATABASE="rfcfcst_dev"
    PARENT_TABLE="forecast_values"
    PARTITION_COLUMN="product_time"
    SCRIPTS_DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    CREATE_SCRIPT="${SCRIPTS_DIR}/create_forecast_values_partitions.sh"
    REMOVE_LOCK=0
    LOCK_FILE=$0.lock
    STALE_HOURS=24

### Get from environment, if present ###

    if [ -n "${DB}" ]
    then
      DATABASE="${DB}"
    fi
    if [ -n "${DBHOST}" ]
    then
      export PGHOST="${DBHOST}"
    fi
    if [ -n "${DBUSER}" ]
    then
      export PGUSER="${DBUSER}"
    fi
    if [ -n "${DBPORT}" ]
    then
      export PGPORT="${DBPORT}"
    fi
    if [ -n "${DBPASSWORD}" ]
    then
      export PGPASSWORD="${DBPASSWORD}"
    fi

### Includes ###

    . ${SCRIPTS_DIR}/message_function.sh
    . ${SCRIPTS_DIR}/get_busy_file.sh

### Usage ###
function usage()
{
    echo "USAGE:"
    echo "  $0 {-help}"
    echo ""
    echo "ARGUMENTS"
    echo "   -h    - (optional) Display help"
}

### Cleanup function ###
function cleanup()
{
    if [ "${REMOVE_LOCK}" -eq 1 ] && [ -f "${LOCK_FILE}" ]
    then
        rm -f "${LOCK_FILE}"
        REMOVE_LOCK=0
    fi

    exit
}

### Determine if a table already exists ###

function table_exists()
{
    EXISTS=$( psql -d ${DATABASE} -tAc "SELECT COUNT ( * ) FROM pg_class
                                        WHERE relname = '$1' AND
                                        relkind = 'r' or relkind = 'p'" )
    if [ ${EXISTS} -eq 1 ]
    then
        return 0
    else
        return 1
    fi
}

### Get list of child partitions ###
### This still works for declarative partitioning ###

function get_child_partitions()
{
    local PARENT_TABLE=$1

    psql -d ${DATABASE} -tAc "SELECT t2.relname
                              FROM pg_inherits AS t1,
                                   pg_class AS t2,
                                   pg_class AS t3
                              WHERE t1.inhrelid = t2.oid AND
                                    t1.inhparent = t3.oid AND
                                    t3.relname = '${PARENT_TABLE}'
                              ORDER BY t2.relname"
}

### Get default partition, if any ###

function get_default_partition()
{
    local PARENT_TABLE=$1
    psql -d ${DATABASE} -tAc "SELECT t2.relname
                              FROM pg_partitioned_table AS t1,
                                   pg_class AS t2,
                                   pg_class AS t3
                              WHERE t1.partdefid != 0 AND
                                    t1.partdefid = t2.oid AND
                                    t1.partrelid = t3.oid AND
                                    t3.relname = '${PARENT_TABLE}'"
}

### Find stray records ###

function find_stray_records()
{
    local PARENT_TABLE=$1
    psql -d ${DATABASE} -tAc "SELECT MIN ( ${PARTITION_COLUMN} )
                              FROM ${PARENT_TABLE}"
}

### Move records ###

function move_records()
{
    local SOURCE_TABLE=$1
    local DESTINATION_TABLE=$2
    local PARTITION_START=$3
    local PARTITION_STOP=$4

    message info "Moving records from ${SOURCE_TABLE} to ${DESTINATION_TABLE}"

    psql -d ${DATABASE} -c "WITH moved_rows AS ( DELETE FROM ONLY ${SOURCE_TABLE}
                                        WHERE ${PARTITION_COLUMN} >= '${PARTITION_START}' AND
                                              ${PARTITION_COLUMN} < '${PARTITION_STOP}'
                                        RETURNING ${SOURCE_TABLE}.* )
                   INSERT INTO ${DESTINATION_TABLE}
                   SELECT * FROM moved_rows ;"
}

### Compress no longer used space ###
function vacuum_full()
{
    local TABLE=$1

    psql -d ${DATABASE} -c "VACUUM FULL ${TABLE}"
}

### Main ###

function main()
{

    ### Local variables ###
    local DEFAULT_TABLE
    local LAST_DATE
    local MONTH_DATE_START
    local MONTH_DATE_STOP
    local MONTH_START
    local MONTH_STOP
    local MONTH_SUFFIX
    local MOVED=
    local YEAR_START
    local YEAR_SUFFIX

    message info "Starting"

    # Catch errors
    trap "cleanup" SIGHUP SIGINT SIGTERM ERR EXIT

    # Busy?
    get_busy_file "${LOCK_FILE}" ${STALE_HOURS}
    REMOVE_LOCK=1

    ### Look through parent, and then yearly child tables ###
    message info "Getting list of child partitions in ${PARENT_TABLE}"

    for TABLE in ${PARENT_TABLE} $( get_child_partitions "${PARENT_TABLE}" )
    do
        ### Reinitialize ###
        LAST_DATE=
        MOVED=

        # Look for a default partition
        DEFAULT_TABLE=$( get_default_partition ${TABLE} )
        if [ -z "${DEFAULT_TABLE}" ]
        then
            continue
        fi

        # Find stray records in table
        message info "Looking for stray records in ${DEFAULT_TABLE}"
        MONTH_DATE=$( find_stray_records ${DEFAULT_TABLE} )

        while [ -n "${MONTH_DATE}" ] && [ "${LAST_DATE}" != "${MONTH_DATE}" ]
        do
            message info "Found ${PARTITION_COLUMN} value of ${MONTH_DATE} in ${DEFAULT_TABLE}"

            ### Reformat date ###
            YEAR_START=$( date -ud "${MONTH_DATE}" +%Y )
            MONTH_START=$( date -ud "${MONTH_DATE}" +%_m )
            MONTH_SUFFIX="$( printf "%04d%02d" ${YEAR_START} ${MONTH_START} )"
            if [ ${MONTH_START} -eq 12 ]
            then
                MONTH_STOP=1
                YEAR_STOP=$(( YEAR_START + 1 ))
            else
                MONTH_STOP=$(( MONTH_START + 1 ))
                YEAR_STOP=${YEAR_START}
            fi

            MONTH_DATE_START="$( printf "%04d-%02d-01 00:00:00" ${YEAR_START} ${MONTH_START} )"
            MONTH_DATE_STOP="$( printf "%04d-%02d-01 00:00:00" ${YEAR_STOP} ${MONTH_STOP} )"

            ### Check to see if monthly table exists
            if ! table_exists ${PARENT_TABLE}_${MONTH_SUFFIX}
            then
                message info "Table ${PARENT_TABLE}_${MONTH_SUFFIX} missing"
                ${CREATE_SCRIPT} ${YEAR_START} ${MONTH_START}
            fi

            ### Move records
            move_records "${DEFAULT_TABLE}" "${PARENT_TABLE}_${MONTH_SUFFIX}" \
                         "${MONTH_DATE_START}" "${MONTH_DATE_STOP}"
            MOVED=1

            message info "Done moving records into ${PARENT_TABLE}_${MONTH_SUFFIX}"

            ### Look for next stray value
            LAST_DATE="${MONTH_DATE}"
            MONTH_DATE=$( find_stray_records ${DEFAULT_TABLE} )

        done

        ### Compress size ###
        if [ -n "${MOVED}" ]
        then
            vacuum_full ${DEFAULT_TABLE}
        fi

    done

    message info "Completed"
}

### Get arguments ###

    if [ $# -ne 0 ] || [ "$1" = "-h" ]
    then
        usage
        exit
    fi

### Main ###

    main
