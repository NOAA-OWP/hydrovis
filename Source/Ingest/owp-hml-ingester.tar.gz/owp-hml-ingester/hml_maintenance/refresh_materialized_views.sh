#!/bin/bash
#######################################################
#
#  This script refreshes materialized views
#
#######################################################

# Constants

SCRIPTS_DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCK_DIR=${SCRIPTS_DIR}
PROGRAM=${0##*/}
LOCK_FILE="${LOCK_DIR}/${PROGRAM}.lock"

### Get from environment, if present ###

  if [ -n "${DBHOST}" ]
  then
    export PGHOST="${DBHOST}"
  fi
  if [ -n "${DBUSER}" ]
  then
    export PGUSER="${DBUSER}"
  fi
  if [ -n "${DBPORT}" ]
  then
    export PGPORT="${DBPORT}"
  fi
  if [ -n "${DBPASSWORD}" ]
  then
    export PGPASSWORD="${DBPASSWORD}"
  fi

### Views to refresh
### Database|Schema.Table|Concurrently? ###

#VIEWS="rfcfcst_dev|public.last_forecast_view2|"
#VIEWS="rfcfcst_dev|public.distinct_forecast_stage_lids2|CONCURRENTLY
#       rfcfcst_dev|public.distinct_forecast_streamflow_lids2|CONCURRENTLY"
VIEWS=""

IFS="
"

# Include files
. ${SCRIPTS_DIR}/message_function.sh
. ${SCRIPTS_DIR}/get_busy_file.sh


### Refresh view function

refresh_materialized_view()
{
  DATABASE=$1
  VIEW=$2
  CONCURRENTLY=$3

  message info "Refreshing view ${DATABASE}.${VIEW}"

  psql -qd ${DATABASE} -c "REFRESH MATERIALIZED VIEW ${CONCURRENTLY} ${VIEW}"
  psql -qd ${DATABASE} -c "ANALYZE ${VIEW}"

  message info "Finished refreshing and reanalyzing view ${DATABASE}.${VIEW}"
}

### Main logic

for LINE in ${VIEWS}
do
  DATABASE=$( echo $LINE | cut -d \| -f 1 | sed -e "s/^  *//g" -e "s/  *$//g" )
  VIEW=$( echo $LINE | cut -d \| -f 2 | sed -e "s/^  *//g" -e "s/  *$//g" )
  CONCURRENTLY=$( echo $LINE | cut -d \| -f 3 | sed -e "s/^  *//g" -e "s/  *$//g" )

  refresh_materialized_view ${DATABASE} ${VIEW} ${CONCURRENTLY} 

done
