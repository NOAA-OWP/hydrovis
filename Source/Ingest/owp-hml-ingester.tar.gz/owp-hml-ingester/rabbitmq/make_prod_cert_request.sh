KEYHOST="nwcal-wrds-prod1"
openssl req -new -sha256 -nodes -out ${KEYHOST}.csr -newkey rsa:2048 -keyout ${KEYHOST}.key -config <( cat csr_form.txt )
openssl req -text -noout -verify -in ${KEYHOST}.csr

