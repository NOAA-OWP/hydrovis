"""
This class is used to parse the configuration file contents


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/31/2017
"""

import logging
from configparser import SafeConfigParser, NoOptionError, NoSectionError
import os

# local modules
from constants import app, conf


# Define logger specific to this application
logger = logging.getLogger(app.NAME)


class ConfigReader(object):

    def __init__(self, config_file):

        # path to the config file
        self.config_file = config_file

    def get_config_value(self, section, parameter_name):
        """
        Get value of a configuration parameter in specified section

        Args:
            section: The section to search from in configuration file
            parameter_name: The name of the parameter we are searching for
        Returns:
            String value of the parameter or None if not found
        """

        try:

            configuration = SafeConfigParser(os.environ)
            configuration.read(self.config_file)
            value = configuration.get(section, parameter_name )
        except (NoSectionError, NoOptionError) as err:

            logger.warning(err)
            return None

        return value

    def read_conf_app( self ):
        """
        Parse the app section of the configuration file

        Args:
            There are no arguments

        Returns:
            A tuple with minutes old value

        Raises:
            ValueError: if the minutes_old is not an integer
            Exception: if the max minute parameter is missing
        """

        # make sure user specified url parameter
        app_max_mintues_old = self.get_config_value(
            conf.APP_SECTION,
            conf.APP_MAX_MINUTES_OLD
            )

        if app_max_mintues_old is None:
            raise Exception(
                "You must provide max minutes old parameter to determine"\
                "if a task is old enough to reschedule. Aborting!"
                )

        app_max_mintues_old_int = int(app_max_mintues_old)

        return ( app_max_mintues_old_int, )

    def read_conf_rabbitmq( self ):
        '''
        Parse the rabbitmq section of configuration file

        Args:
            There are no arguments
        Returns:
            A tuple with connection url to rabbitmq node. Keeping tuple for
            ease of extensibility.
        Raises:
            Exception: if url is missing
        '''

        # make sure user specified url parameter
        rabbitmq_url = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_URL
            )

        if rabbitmq_url is None:
            raise Exception(
                "You must provide url to RabbitMQ node/cluster. Aborting!"
                )

        # get exchange name specified
        rabbitmq_exchange = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_EXCHANGE
            )

        if rabbitmq_exchange is None:
            raise Exception(
                "You must provide a name of RabbitMQ exchange. Aborting!"
                )

        # hml event queue if splitter is used in consumer mode
        rabbitmq_hml_event_queue = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_EVENT_QUEUE
        )

        if rabbitmq_hml_event_queue is None:
            raise Exception(
                "You must provide a name of hml queue. Aborting!"
                )

        # hml prefetch count
        rabbitmq_hml_prefetch_count = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_HML_PREFETCH_COUNT
        )

        try:
            rabbitmq_hml_prefetch_count = int(rabbitmq_hml_prefetch_count)
        except ValueError:
            raise Exception(
                "You must provide an integer prefetch count for "\
                "hml queue. Aborting!"
                )

        # dead letter hml queue message ttl
        rabbitmq_dl_hml_message_ttl = self.get_config_value(
            conf.RABBITMQ_SECTION,
            conf.RABBITMQ_DL_HML_TTL
        )

        try:
            rabbitmq_dl_hml_message_ttl = int(rabbitmq_dl_hml_message_ttl)
        except ValueError:
            raise Exception(
                "You must provide an integer message time to live for "\
                "dead letter hml queue. Aborting!"
                )

        return (
            rabbitmq_url,
            rabbitmq_exchange,
            rabbitmq_hml_event_queue,
            rabbitmq_hml_prefetch_count,
            rabbitmq_dl_hml_message_ttl
            )

    def read_conf_db( self ):
        '''
        Parse the database section of configuration file

        Args:
            There are no arguments

        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get database connection string
        conf_connection_string = self.get_config_value(
            conf.DATABASE_SECTION,
            conf.DATABASE_CONNECTION_STRING
        )

        return (conf_connection_string, )

    def read_conf_log( self ):
        '''
        Parse the log section of configuration file

        Args:
            There are no arguments
        Returns:
            A tuple containing the log level, target, and filename if applicable
        '''

        # get log debug level
        conf_log_level = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_LEVEL
        )

        # log to file|stream
        log_output_to = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_TARGET
        )

        # log file, if applicable
        log_file = self.get_config_value(
            conf.LOG_SECTION,
            conf.LOG_FILE_PATH
        )

        return (conf_log_level, log_output_to, log_file)

    def read_configs( self ):
        '''
        This function parses all configuration parameters

        The function reads all sections of the configuration file and return a tuple
        containing the tuples one for each section.

        Returns:
            A tuple of tuples each corresponding to a configuration section
        Raises:
            Exception: if any of the section parser raises exception
        '''

        # object store section
        conf_app = self.read_conf_app()

        # rabbitmq section
        conf_rabbitmq = self.read_conf_rabbitmq()

        # db section
        conf_database = self.read_conf_db()

        # log section
        conf_log = self.read_conf_log()

        return ( conf_app, conf_rabbitmq, conf_database, conf_log )
