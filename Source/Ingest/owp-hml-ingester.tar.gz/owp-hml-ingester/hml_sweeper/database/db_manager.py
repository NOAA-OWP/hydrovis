"""
This class is used to manage database related operations

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 10/03/2017
"""

#  Import System libraries
import logging

# ORM
from sqlalchemy import create_engine, and_, or_, extract, func, text
from sqlalchemy.sql.expression import select, join, outerjoin, except_, update
from sqlalchemy.orm import sessionmaker

from sqlalchemy.dialects.postgresql import insert as pg_insert

from sqlalchemy.exc import DatabaseError, OperationalError, IntegrityError
from sqlalchemy.orm.exc import NoResultFound

from sqlalchemy.pool import QueuePool

# module imports
from database.db_model import utcnow, Hml, HmlXml
from database.db_model import HmlStatusEnum, HmlXmlStatusEnum

from constants import app
from constants.database import const_hml

# get logger (its properties will be set in entry script)
logger = logging.getLogger(app.NAME)


class DBManager(object):
    """
    This class is used to manage database related operations
    """

    def __init__(self, connection_string):
        """
        Initialize sqlalchemy engine and create a session

        The session scope is application wide and transaction scopes are limited
        to the functions. The session is closed in class destructor.

        Args:
            connection_string: The connection string to database of interest
        Returns:
            nothing
        Raises:
            NoSuchModuleError: If database doesn't exist
            OperationalError: if connection string is invalid like domain name,
            username, email etc.
        """

        ## @var engine
        # connection string to database
        # Note that setting isolation level to AUTOCOMMIT means that all of the
        # sql transactions will commit automatically, if more than one
        # sql queries need to be committed/rolledback together, we need to do
        # something special as mentioned in the following article:
        # http://oddbird.net/2014/06/14/sqlalchemy-postgres-autocommit/
        try:
            self.engine = create_engine(
                connection_string,
                pool_size=1,
                max_overflow=0,
                poolclass=QueuePool,
                isolation_level='AUTOCOMMIT',
                echo=True
                )
        except DatabaseError as db_error:
            logger.error(str(db_error))
            raise

        ## @var sessionmaker
        # settings for database sessions factory method
        self.session_maker = sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            autocommit=True
            )

    def __enter__(self):
        """
        Get a db session

        Args:
             nothing
        Returns:
            an instance of Session bound to the sqlalchemy engine
        """

        self.session = self.session_maker()
        return self.session

    def __exit__(self, *args):
        """
        Close the db session
        """

        self.session.close()

    @staticmethod
    def get_unprocessed_hmls(session):
        """
        Get HML files's info that failed to process within provided duration 

        The function finds the information about HML files that failed to
        process. This is determined by finding HMLs that are not marked aborted
        i.e. they are not empty files but still their XML status in HmlXml table
        is null or if their XMLs' status is none of the following: parse_complete,
        parse_failure, or aborted. XMLs may be marked parse_failure if either
        the XML received from RabbitMQ is malformed or there was a problem
        parsing HML specific XMLs like the one that have multiple time-steps in
        forecast.

        Args:
            session: current sqlalchemy session to execute this transaction
            max_minutes_old: the number of minutes in past to mark a task as old

        Returns:
            A list of tuples each with hml_id and url of the unprocessed hml
            file. 
        """

        return session.query( Hml.hml_id, Hml.url )\
            .select_from( Hml )\
            .outerjoin( HmlXml )\
            .filter( 
                or_(
                    and_(
                        Hml.hml_status != HmlStatusEnum.aborted,
                        HmlXml.xml_status == None
                    ),
                    ~HmlXml.xml_status.in_(
                        [
                            HmlXmlStatusEnum.parse_complete,
                            HmlXmlStatusEnum.parse_failure,
                            HmlXmlStatusEnum.aborted
                        ]
                    )
                )
            )\
            .group_by( Hml.hml_id, Hml.url )\
            .order_by( Hml.hml_id )\
            .all()

