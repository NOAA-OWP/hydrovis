"""
This file gets tables from database provided in connection string using
reflection.


United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 26/03/2018
"""

# ORM imports
from sqlalchemy import Column, DateTime, ForeignKey
from sqlalchemy import Integer, SmallInteger, Float, String, Text

from sqlalchemy.schema import UniqueConstraint, Table

from sqlalchemy.orm import relationship

from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy.ext.compiler import compiles

from sqlalchemy.sql import expression, text

from sqlalchemy.types import Enum as DBEnum
from enum import Enum


# local imports
from constants.database import const_hml, const_hml_xml

Base = declarative_base()
metadata = Base.metadata


# used to populate db columns with current UTC timestamp
class utcnow(expression.FunctionElement):
    """
    Generic date time server side string replacement

    This class defines the current data and time in python and can be used to
    compile time according to specfic SQL dialect as shown below.


    nes the current UTC time
    """

    type = DateTime()


@compiles(utcnow, 'postgresql')
def pg_utcnow(element, compiler, **kw):
    """
    This function computes the UTC timestamp for postgresql dialect
    """

    return "TIMEZONE('utc', CURRENT_TIMESTAMP)"


class AutoNumber(Enum):
    """
    Number the enum member values automatically

    Python 3.4 lacks the auto() method to automatically number the enum member
    values so here is the hack provided on following link:
    docs.python.org/3.4/library/enum.html#enum.Enum
    """

    def __new__(cls):
        value = len(cls.__members__)
        obj = object.__new__(cls)
        obj._value_ = value
        return obj


class HmlStatusEnum(AutoNumber):
    """
    The enums for the status column of HML table

    SQLAlchemy persists the enum class variable names by default as strings in
    the database enum columns not the value of enum variables. Strange? Read at
    following link:
    docs.sqlalchemy.org/en/latest/core/type_basics.html?#sqlalchemy.types.Enum
    """

    # using auto here as enum member value to reinforce the point that enum
    # member names will be used by SQLAlchemy not their values hence auto
    received = ()
    split = ()
    xml_parse_complete = ()
    xml_parse_failure = ()
    aborted = ()


class HmlXmlStatusEnum(AutoNumber):
    """
    The enums for the status column of hml_xml table

    SQLAlchemy persists the enum class variable names by default as strings in
    the database enum columns not the value of enum variables. Strange? Read at
    following link:
    docs.sqlalchemy.org/en/latest/core/type_basics.html?#sqlalchemy.types.Enum
    """

    # using auto here as enum member value to reinforce the point that enum
    # member names will be used by SQLAlchemy not their values hence auto
    parse_task_created = ()
    parse_begin = ()
    parse_complete = ()
    parse_failure = ()
    post_parse_failure = ()
    db_load_failure = ()
    aborted = ()


###############################################################################
# HML Monitoring Tables
###############################################################################


class Hml(Base):
    """
    This class models the HML relation in database
    """

    __tablename__ = const_hml.TABLE_HML

    hml_id = Column(
        Integer, 
        primary_key=True, 
        server_default=text("nextval('hml_hml_id_seq'::regclass)")
    )
    url = Column(Text, nullable=False, unique=True)
    hml_status = Column(
        DBEnum(HmlStatusEnum), 
        nullable=False
    )
    hml_status_ts = Column(DateTime(True), nullable=False)


class HmlXml(Base):
    """
    This class models the hml_xml relation in database
    """

    __tablename__ = const_hml_xml.TABLE_HML_XML

    hml_id = Column(
        ForeignKey(
            'hml.hml_id', 
            ondelete='RESTRICT', 
            onupdate='RESTRICT', 
            deferrable=True, 
            initially='DEFERRED'
        ), 
        primary_key=True, 
        nullable=False
    )
    xml_index = Column(SmallInteger, primary_key=True, nullable=False)
    lid = Column(Text, nullable=False)
    pedts = Column(Text, nullable=False)
    xml_status = Column(
        DBEnum( HmlXmlStatusEnum ), 
        nullable=False
    )
    xml_status_ts = Column(DateTime(True))

    hml = relationship('Hml')
