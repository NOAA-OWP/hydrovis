#!/usr/bin/env python3
"""
This script is meant to receive an HML file from a unix pipe. It will store the 
file to object store, save an entry for it in database, and publish an event to
hml queue in RabbitMQ with info about how to get the file. This will trigger any
HML consumers like HML splitters listening on that queue to download that file
from object store and process it.

United States Department of Commerce
NOAA (National Oceanic and Atmospheric Administration)
National Weather Service
Office of Water Prediction
@author Shafiq Rahman
@version 1.0
@date 02/23/2018
"""

# Import system libraries first
import sys
import os
import logging
from config.config_reader import ConfigReader
from optparse import OptionParser, OptionGroup

import fileinput

import pika
import json

from datetime import datetime

# Module imports
from constants import app, conf, log, hml_message
from rabbitmq.rabbitmq import RabbitMQManager
from database.db_manager import DBManager

# Define logger specific to this application
logger = logging.getLogger(app.NAME)


def setup_logging(conf_log):
    """
    Configures logger

    This function sets up the application logger by setting its log level,
    target, log format, etc from the information provided in input tuple.

    Args:
        conf_log: a tuple representing values from log section of conf file

    Returns:
        This function doesn't return anything

    Raises:
        Exception in case log target is not specified in configuration file
    """

    conf_log_level, conf_log_target, conf_log_file = conf_log

    # set log level (don't allow any level higher than INFO)
    if conf_log_level == conf.LOG_DEBUG_LEVEL:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO

    logger.setLevel(log_level)

    # set log target to be a file or stdout
    if conf_log_target == conf.LOG_FILE:

        # default to file name in conf file if log file name is not provided
        if not conf_log_file:
            conf_log_file = log.DEFAULT_FILENAME

        log_handler = logging.FileHandler(conf_log_file)

    elif conf_log_target == conf.LOG_STREAM:
        log_handler = logging.StreamHandler(sys.stdout)

    else:
        raise Exception('Provided logging target is not valid. Check config.')

    # set log message format
    log_formatter = logging.Formatter(
        fmt=log.DEFAULT_FORMAT,
        datefmt=log.DEFAULT_DATE_FORMAT
        )
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)

    #logger.info("The logging mechanism has been created.")


def setup_options():
    """
    Configures command line arguments

    Returns:
        A tuple of program options and arguments in that order

    """

    usage_message = __file__ + " [Options]"
    option_parser = OptionParser(
        usage=usage_message,
        version=app.NAME + " " + app.VERSION,
        description="HML Sweeper is meant to requeue the information about "\
            "an HML file as an event in RabbitMQ that is supposed to be picked "\
            "up and processed by HML Splitter. HML processing can fail for a "\
            "variety of reasons like during parsing XML, loading it into "\
            "database etc."
    )

    # path to application configuration file
    dir_path = os.path.dirname(os.path.realpath(__file__)) + "/"
    option_parser.add_option(
        "-f", "--config-file",
        dest="config_file",
        default=dir_path + conf.DEFAULT_CONFIG_FILENAME,
        help="The path to the configuration file. default: ./" + \
             conf.DEFAULT_CONFIG_FILENAME
    )

    return option_parser.parse_args()


def publish_hml_events(conf_rabbitmq, unprocessed_hmls):
    """
    Send an event notification to RabbitMQ about new HML file arrival

    This function publishes an event to RabbitMQ HML queue with the name as
    provided in the configuration file. The event is a JSON with a url of the
    HML file in object store. By this time the HML file is already uploaded to
    the Object store so HML consumers can download and process HML as soon as
    this function publishes the HML event.

    Args:
        conf_rabbitmq: RabbitMQ exchange, HML queue, etc
        unprocessed_hmls: A list of tuples each containing hml database id and
            hml URL in database.

    Returns:
        True if all hmls events were published else False
    """

    # get rabbitmq configurations
    rmq_url, rmq_exchange, rmq_hml_event_queue, \
        rmq_hml_prefetch_count, rmq_dl_hml_message_ttl = conf_rabbitmq

    rmq_manager = RabbitMQManager(rmq_url)
    rmq_manager.setup(rmq_exchange, rmq_hml_event_queue, rmq_dl_hml_message_ttl)
    with rmq_manager.get_connection():

        with rmq_manager.get_channel(rmq_hml_prefetch_count) as hml_queue_channel:

            for index, unprocessed_hml in enumerate(unprocessed_hmls, start=1):

                hml_id = unprocessed_hml.hml_id
                hml_url = unprocessed_hml.url

                hml_event = RabbitMQManager.create_hml_event( hml_id, hml_url )

                hml_queue_channel.basic_publish(
                    exchange=rmq_exchange,
                    routing_key=rmq_hml_event_queue,
                    body=hml_event,
                    properties=pika.BasicProperties(
                        delivery_mode=2
                    )
                )

                logger.debug(
                    "Requeued hml with id: {}, url: '{}'".format( 
                        hml_id, 
                        hml_url
                    )
                )

            logger.info(
                "Requeued {} hmls to RabbitMQ HML queue".format( index ) 
            )
    
    return True


def enqueue_failed_hmls():
    """
    Create HML events in RabbitMQ for files that failed to process

    This function identifies the HML files in database whose processing failed
    for some reason and requeue them into the RabbitMQ hml queue identified in
    the configuration file.

    Raises:
        Exception:
            * if error reading config file
            * if error setting up log
    """

    # parse command line options and arguments
    options, _ = setup_options()

    # parse config params
    try:
        config_reader = ConfigReader(options.config_file)
        conf_app, conf_rabbitmq, conf_db, conf_log = config_reader.read_configs()
    except Exception as e:
        print("Error: ", str(e))
        raise

    # setup logging
    try:
        setup_logging(conf_log)
    except Exception as e:
        print("Error: ", str(e))
        raise

    logger.debug( "Using config file: {0}".format(options.config_file) )

    # app configuration (keeping this in case it may be used in future)
    max_minutes_old, = conf_app

    # get the unprocessed HML files
    db_connection_string, = conf_db
    with DBManager(db_connection_string) as db_session:

        # get hml files that haven't been processed
        unprocessed_hmls = DBManager.get_unprocessed_hmls(
            session=db_session
        )

    if not unprocessed_hmls:

        logger.info("There are no unprocessed hmls at the moment")
        return True

    # enqueue hml event messages for unprocessed hmls
    publish_hml_events(conf_rabbitmq, unprocessed_hmls)


if __name__ == '__main__':
    """
    This is the entry point for HML splitter.
    """

    try:
        enqueue_failed_hmls()
    except Exception as e:
        logger.exception(str(e))
        sys.exit(1)

    sys.exit(0)

