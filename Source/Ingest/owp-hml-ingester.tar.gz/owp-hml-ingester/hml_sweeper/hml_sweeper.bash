#!/usr/bin/env bash

# This script is meant to source the environment variables from .env.dev file
# and run the python entry script for HML Sweeper. Also it makes sure that we
# are using the required python version. If user is using a virtual environment
# then path to the activate script of virtual environment must be provided.
#
# Arguments:
#    -e|--env-file: path to the environment variable file, defaults to
#        '.env.dev' in current directory
#    -p|--python-venv-path: path to the python virtual environment activate
#        script. defaults to system python installation
#    -h|--help: get the comments at the start of this file
#
# Example Usage:
#    hml_sweeper.bash -e .env.prod -p /opt/venv/3.4/bin/activate

# script constants
required_python_major_version="3"
required_python_minor_version="4"
default_env_file=".env.dev"

# get the command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -e|--env-file)
            env_file="$2"
            shift;
            ;;
        -p|--python-venv-path)
            python_venv_path="$2"
            shift
            ;;
        -h|--help)
            sed -n 3,16p "$0" | sed 's/#//g'
            exit 0
            ;;
        *)
            echo "Unknown option $1. Use -h to see help. Aborting!"
            exit 1
            ;;
    esac
    shift
done

# activate virtual environment if applicable
if [[ -f "$python_venv_path" ]]; then
    source "$python_venv_path"
    echo "Activated the virtual environment at path: '$python_venv_path'"
else
    echo "Using system-wide python install to run the application"
fi

# is python installed on this system?
python_path="$( which python )"
if [[ -z "$python_path" ]]; then
    echo "You need to install python to run the application"
    exit 1
fi

## make sure that right version of python is installed
installed_python_major_version=$( \
    python -V 2>&1 | grep -Po '(?<=Python )(\d)(?<=\.\d)*'\
)
installed_python_minor_version=$( \
    python -V 2>&1 | grep -Po '(?<=Python \d\.)(\d)(?<=\.\d)*'\
)

if [[ \
    $installed_python_major_version < $required_python_major_version ||\
    $installed_python_minor_version < $required_python_minor_version  \
    ]]; then
    echo "This application needs python:"\
        "${required_python_major_version}.${required_python_minor_version}"\
        "but available version is:"\
        "${installed_python_major_version}.${installed_python_minor_version}."\
        "Aborting!"
    exit 1
fi

## install python packages in requirements.txt
pip install -r requirements.txt >/dev/null

## source the environment variable file
[[ -f "$env_file" ]] || env_file="$default_env_file"
set -a; source "$env_file"; set +a;

echo "Using environment file: '$env_file'"

## run HML sweeper
./hml_sweeper.py

exit $?

