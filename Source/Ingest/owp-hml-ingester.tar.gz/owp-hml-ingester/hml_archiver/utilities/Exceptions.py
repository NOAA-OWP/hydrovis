#!/usr/bin/python
#######################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
#######################################################################
""" This module contains methods that support exception handling.
"""
# System imports
from os.path import basename
import re
import sys
import traceback

#######################################################################
#
#  format_current_exception
#
#######################################################################

def format_current_exception():
    """ Reformat the current exception into a suitable log message

    This method reformats the current exception message including the
    stack trace into a one-line message suitable for log files.

    Args:
        None

    Exceptions:
        None
    """
    # Get current exception information
    (exception_type, exception_value, exception_traceback) = sys.exc_info()

    # Get traceback entries
    traceback_entries = traceback.extract_tb(exception_traceback)

    # Construct one-line message
    message = ''
    for entry in traceback_entries:
        message += '%s[%s[line %ld]]: ' % (basename(entry[0]),
                                           entry[2], entry[1])

    # Replace any newlines in the exception text
    single_line = re.sub(' *\r?\n *', ' : ', str(exception_value))

    # Return created message
    return message + single_line
