#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################
""" This contains a class to that uses locked files to control the unique
    execution of scripts
"""
# Global imports
import fcntl
import os

##############################################################################
#
#  Busy_file
#
##############################################################################

class Busy_file(object):
    """ Busy file class

    This class represents the existence of a unique file with the current PID
    as its contents. It can be used to prevent multiple instances of the same
    script from running concurrently.

    """

    ##########################################################################
    #
    #  __init__
    #
    ##########################################################################
    def __init__(self,
                 filepath):
        """ Busy file class constructor

        Args:
            filepath (str): The name of the busy file to use

        Exceptions:
           None

        """
        # Set member constants
        self.cleanup = False
        self.filepath = filepath

        self.pid = os.getpid()

        # Attempt to get lock
        if self.filepath:
            self.lock()

    ##########################################################################
    #
    #  __del__
    #
    ##########################################################################
    def __del__(self):
        """ Busy file class destructor

        Args:
            None

        Exceptions:
            None
        """

        # Release lock
        if self.cleanup:
            self.release()

    ##########################################################################
    #
    #  lock
    #
    ##########################################################################
    def lock(self):
        """ Attempt to create busy file if it does not exist

        Args:
            None

        Returns:
            None

        Exception:
            None
        """

        # Test to see if file exists
        self.validate_any_existing_lockfile()

        # Attempt to create
        self.write_lockfile()


    ###########################################################################
    #
    #  validate_any_existing_lockfile
    #
    ###########################################################################
    def validate_any_existing_lockfile(self):
        """ Attempt to check any existing file's contents

        Args:
            None

        Returns:
            Whether or not the lockfile contains a pid of a currently running
            process

        Exception:
            None
        """

        # Get lock file contents if it exists
        lock_pid = self.read_lockfile()

        if lock_pid:
            # Handle odd case where lock file pid is current pid
            # This could also happen if two instances of the class are
            # created in the same program with the same file path
            if lock_pid == self.pid:
                # Remove file to recreate
                os.remove(self.filepath)
            else:
                # Now determine if process is currently running
                try:
                    os.kill(lock_pid, 0)
                    # No exception, process exists
                    raise ValueError('Process %d from %s is currently running' %
                                     (lock_pid, self.filepath))

                except OSError:
                    # Exception thrown, process does not exist
                    os.remove(self.filepath)

    ###########################################################################
    #
    #  read_lockfile
    #
    ###########################################################################
    def read_lockfile(self):
        """ Attempts to read a lockfile's contents

        Args:
            None

        Returns:
            The process id in the lockfile if it exists, otherwise None

        Exception:
            None
        """

        # Initialize output string in the case of error/nonexistence
        pid = None

        # In case there is trouble reading the file
        close_flag = False
        bad_value = False

        try:

            # Check for file existence
            if os.path.exists(self.filepath):

                # Open file and get lock
                file_descriptor = os.open(self.filepath, os.O_RDONLY)
                close_flag = True

                # Get shared lock
                fcntl.flock(file_descriptor, fcntl.LOCK_SH)

                # Determine length
                length = os.lseek(file_descriptor, 0, os.SEEK_END)

                # Read contents
                try:
                    os.lseek(file_descriptor, 0, os.SEEK_SET)
                    pid = abs(int(os.read(file_descriptor, length)))

                except ValueError:
                    bad_value = True

                # Drop lock and close file
                fcntl.flock(file_descriptor, fcntl.LOCK_UN)
                os.close(file_descriptor)
                close_flag = False

                # Bad value, removing file
                if bad_value:
                    os.remove(self.filepath)

            else:
                # File does not exist
                pid = None

        except ValueError:
            # Unable to parse pid value. Bad value
            fcntl.flock(file_descriptor, fcntl.LOCK_UN)
            os.close(file_descriptor)

            # Bad contents, removing
            os.remove(self.filepath)

        except IOError:
            # Some sort of file reading error
            if close_flag:
                fcntl.flock(file_descriptor, fcntl.LOCK_UN)
                os.close(file_descriptor)

        return pid

    ###########################################################################
    #
    #  write_lockfile
    #
    ###########################################################################
    def write_lockfile(self):
        """ Attempts to write the process id to a file

        Args:
            None

        Returns:
            None

        Exception:
            None
        """
        close_flag = False

        try:
            # Open file
            file_descriptor = os.open(self.filepath, os.O_CREAT | os.O_WRONLY |
                                      os.O_EXCL)
            close_flag = True

            # Lock file
            fcntl.flock(file_descriptor, fcntl.LOCK_EX)

            # Write pid
            content = str(self.pid)
            os.write(file_descriptor, content)

            # Flush to disk before unlocking
            os.fsync(file_descriptor)
            fcntl.flock(file_descriptor, fcntl.LOCK_UN)
            os.close(file_descriptor)
            close_flag = False

            # Now can cleanup
            self.cleanup = True
        except:
            # Clean up
            if close_flag:
                os.close(file_descriptor)
            raise

    ###########################################################################
    #
    #  release
    #
    ###########################################################################
    def release(self):
        """ Remove previously created lock file

        Args:
            None

        Returns:
            None

        Exception:
            None
        """

        # Should really notify if this file has disappeared
        if os.path.exists(self.filepath):
            os.remove(self.filepath)

        self.cleanup = False
