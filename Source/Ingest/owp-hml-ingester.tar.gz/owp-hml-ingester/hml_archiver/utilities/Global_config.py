#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################
""" This contains a class for reading the global configuration file
"""
# Global imports
import ConfigParser
from datetime import timedelta

###############################################################################
#
#  Global_config
#
###############################################################################
class Global_config(object):
    """ Read global config file class

    This class read high level program configuration paramters from a
    configuration file
    """

    ###########################################################################
    #
    #  __init__
    #
    ###########################################################################

    def __init__(self,
                 config_pathname):
        """ Global_config class constructor

        This creates a Global_config object. This exists just to read and store
        global parameters.

        Args:
            config_pathname (str): The file path to a config file

        Exceptions:
            None

        """

        self.hml_repository_path = ''
        self.archive_interval = 'day'
        self.archive_prefix = ''
        self.archive_time = None
        self.destination_path = None
        self.remove_instead = False

        # Populate internal values with data from config file
        self.read_config_file(config_pathname)

    ###########################################################################
    #
    #  read_string_parameters
    #
    ###########################################################################
    def read_string_parameters(self,
                               config,
                               section):
        """ Read the string type parameters from the configuration file

        This method reads the various string parameters from an earlier
        specified parameter file.

        Args:
            config (namespace ConfigParser ConfigParser obj): An already created
                configuration file parsing object
            section (str): The section name in the configuration file

        Returns:
            None

        Exceptions:
            ValueError if the archive_interval is not valid
        """
        if config.has_option(section, 'hml_repository_path'):
            self.hml_repository_path = config.get(section,
                                           'hml_repository_path').strip('"\'')

        if config.has_option(section, 'archive_interval'):
            self.archive_interval = config.get(section,
                                           'archive_interval').strip('"\'')

        # Confirm value
        allowed_values = [ 'year', 'month', 'day', 'hour' ]
        if self.archive_interval not in allowed_values:
            raise ValueError('Unknown archive_interval "%s" encountered in config'
                             ' file', self.archive_interval)

        if config.has_option(section, 'archive_prefix'):
            self.archive_prefix = config.get(section,
                                             'archive_prefix').strip('"\'')

        if config.has_option(section, 'destination_path'):
            self.destination_path = config.get(section,
                                               'destination_path').strip('"\'')

        if config.has_option(section, 'remove_instead'):
            self.remove_instead = config.get(section,
                                             'remove_instead').strip('"\'').lower() in \
                                  ['true', 'yes', 't', 1 ]

    ###########################################################################
    #
    #  read_integer_parameters
    #
    ###########################################################################
    def read_integer_parameters(self,
                                config,
                                section):
        """ Read the integer type parameters from the configuration file

        This method reads the various integer parameters from an earlier
        specified parameter file.

        Args:
            config (namespace ConfigParser ConfigParser obj): An already created
                configuration file parsing object
            section (str): The section name in the configuration file

        Returns:
            None

        Exceptions:
            None
        """

        # Make sure that config line is present and set to something
        if config.has_option(section, 'archive_days') and \
            config.get(section, 'archive_days'):
            self.archive_time = timedelta(days=config.getint(section,
                                                             'archive_days'))

    ###########################################################################
    #
    #  read_config_file
    #
    ###########################################################################
    def read_config_file(self,
                         config_pathname):
        """ Read the configuration file

        This method reads the configuration file, and populates class values.

        Args:
            config_pathname (str): The file path to a config file.

        Exceptions:
            ValueError if unable to read config file
        """

        config = ConfigParser.ConfigParser()

        if config.read(config_pathname) != [config_pathname]:
            raise ValueError('Unable to read config file "' +
                             config_pathname + '"')

        # Get list of sections
        sections = config.sections()

        for section in sections:

            # Get string configuration parameters
            self.read_string_parameters(config, section)

            # Get integer configuration parameters
            self.read_integer_parameters(config, section)
