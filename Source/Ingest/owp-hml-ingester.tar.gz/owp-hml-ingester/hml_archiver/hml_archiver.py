#!/usr/bin/python
##############################################################################
#
#  United States Department of Commerce
#  NOAA (National Oceanic and Atmospheric Administration)
#  National Weather Service
#  Office of Water Prediction
#
#  Author:
#      Anders Nilsson, UCAR (created)
#
##############################################################################
""" This archives configured subdirectories within a parent directory tree
"""

# Global imports
from datetime import datetime
from datetime import timedelta
import gzip
from tarfile import TarFile
import logging
import os
import shutil
import sys

# Local imports
from utilities.Busy_file import Busy_file
from utilities import Exceptions
from utilities.Global_config import Global_config
from utilities.setup import init_logging
from utilities.setup import set_logging_options
from utilities.setup import setup_arguments

# Global logger instance
logger = logging.getLogger()

########################################################################
#
#  Parse directory date component
#
########################################################################
def parse_component(directory_type,
                    directory,
                    parent_date):
    """ Parse a directory component into a start and stop date

    This method validates the directory component as a date, and
    calculates date bounds.

    Arguments:
        directory_type (str): The name of the date component to test,
            i.e. "hour, "day", "month", etc...
        directory (str): The directory component to test. This should
            be a string representation of an integer.
        parent_date (datetime datetime obj): The parent date component

    Returns:
        A dictionary with start_date and stop_date entries. None if
        unable to parse.
    """

    # Initialize output
    output = {'start_date': None,
              'stop_date': None}

    # Test valid date component
    try:
        component = int(directory)
        if directory_type == 'second':
            output['start_date'] = datetime(parent_date.year, parent_date.month,
                                            parent_date.day, parent_date.hour,
                                            parent_date.minute, component)
            output['stop_date'] = output['start_date'] + timedelta(seconds=1)
        elif directory_type == 'minute':
            output['start_date'] = datetime(parent_date.year, parent_date.month,
                                            parent_date.day, parent_date.hour,
                                            component)
            output['stop_date'] = output['start_date'] + timedelta(minutes=1)
        elif directory_type == 'hour':
            output['start_date'] = datetime(parent_date.year, parent_date.month,
                                            parent_date.day, component)
            output['stop_date'] = output['start_date'] + timedelta(hours=1)
        elif directory_type == 'day':
            output['start_date'] = datetime(parent_date.year, parent_date.month,
                                            component)
            output['stop_date'] = output['start_date'] + timedelta(days=1)
        elif directory_type == 'month':
            output['start_date'] = datetime(parent_date.year, component, 1)
            if component != 12:
                output['stop_date'] = datetime(parent_date.year, component+1, 1)
            else:
                output['stop_date'] = datetime(parent_date.year+1, 1, 1)
        elif directory_type == 'year':
            output['start_date'] = datetime(component, 1, 1)
            output['stop_date'] = datetime(component+1, 1, 1)
        else:
            # Shouldn't get here
            return None

    except ValueError:
        return None
    except TypeError:
        return None

    return output

################################################################
#
#  Parse date directory listing
#
################################################################
def get_date_listing(parent_directory,
                     parent_date,
                     directory_type,
                     stop_type):
    """ Search through directory tree and find subdirectories to archive

    This method descends somewhat recursively through a directory consisting
    of numerical date components, and depending on the stop_type, adds the
    existing subdirectory to the list.

    Args:
        parent_directory (str): The parent directory to traverse
        parent_date (namespace datetime datetime obj): A datetime corresponding
            to the parent directory if the following directory type is anything
            but 'year'
        directory_type (str): The datetime compment that describes the current
            directory's entries
        stop_type (str): The datetime component where no further directory
            traversal is required.

    Returns:
        (list) A list of directories

    Exceptions:
        ValueError if directory_type or stop_type does not match an expected
        value

    """
    # Initialize variables
    returned_list = []
    components = ['year', 'month', 'day', 'hour', 'minute', 'second']

    # Check inputs
    if directory_type not in components:
        raise ValueError('Unknown directory type "%s"', directory_type)
    if stop_type not in components:
        raise ValueError('Unknown stop type "%s""', stop_type)
    # This shouldn't happen
    if components.index(directory_type) > components.index(stop_type):
        return returned_list

    potential_dirs = os.listdir(parent_directory)

    for potential_dir in potential_dirs:

        component_path = os.path.join(parent_directory, potential_dir)

        # Test name
        if not potential_dir.isdigit():
            continue

        # Test valid date component
        component_limits = parse_component(directory_type, potential_dir,
                                           parent_date)

        # Confirm is directory
        if not os.path.isdir(component_path):
            continue

        # Get modification date
        modification_date = datetime.utcfromtimestamp(os.path.getmtime(component_path))

        # Descend further?
        if directory_type == stop_type:
            # Add to list
            returned_list.append({'start_date': component_limits['start_date'],
                                  'stop_date': component_limits['stop_date'],
                                  'path': component_path,
                                  'modification_date': modification_date})
        else:
            # Descend further?
            current_index = components.index(directory_type)

            # Add results from further down the tree
            returned_list.extend(get_date_listing(component_path,
                                                  component_limits['start_date'],
                                                  components[current_index+1],
                                                  stop_type))

    return returned_list

##############################################################################
#
#  Get list of tasks (directories) to process
#
##############################################################################
def tasks_from_directory(config):
    """ Search through directory tree and find subdirectories to archive

    This method descends through a directory tree consisting of datetime
    components YYYY/MM/DD/HH, and depending on the level of archive, adds
    the existing subdirectory to the list. This filters by directory name
    and modification time.

    Args:
        config (namespace Global_config Global_config obj): A Global_config
            object from an already read config file

    Returns:
         (list) A list of directories containing dictionaries to archive and
         their associated dates

    Exceptions:
        ValueError if repository path does not exist
    """

    # Check to make sure root directory path exists
    if not os.path.exists(config.hml_repository_path):
        raise ValueError('hml_repository_path "%s" not found',
                         config.hml_repository_path)

    # Get the listing of directories at the level of interest
    logger.info('Getting directory listing from %s', config.hml_repository_path)
    full_listing = get_date_listing(config.hml_repository_path, 0, 'year',
                                    config.archive_interval)
    logger.info('Found %d potential directories', len(full_listing))
    full_listing.sort()

    # Now filter by date
    filter_datetime = datetime.utcnow() - config.archive_time
    return [listing['path'] for listing in full_listing
            if listing['stop_date'] < filter_datetime and
            listing['modification_date'] < filter_datetime]

###############################################################################
#
#  Uncompress a zipped file
#
###############################################################################
def uncompress_file(input_filename,
                    output_filename):
    """ Uncompress a gzipped file

    This method reads the compressed contents of a gzipped file, and writes
    that to another output file. This does not do any file cleanup if an
    error occurs.

    Args:
        input_filename (str): The gzip file to uncompress
        output_filename (str): The name of the file to write uncompressed data

    Returns:
        None

    Exceptions:
        None
    """

    with gzip.open(input_filename, 'rb') as read_file:
        with open(output_filename, 'wb') as write_file:
            write_file.write(read_file.read())

###############################################################################
#
#  Compress a zipped file
#
###############################################################################
def compress_file(input_filename,
                  output_filename):
    """ Compress a gzipped file

    This method reads the contents of a file, and writes the compressed
    contents to another output file. This does not do any file cleanup if an
    error occurs.

    Args:
        input_filename (str): The uncompressed file to read
        output_filename (str): The name of the gzipped file to write

    Returns:
        None

    Exceptions:
        None
    """

    with open(input_filename, 'rb') as read_file:
        with gzip.open(output_filename, 'wb') as write_file:
            write_file.write(read_file.read())

###############################################################################
#
#  Archive a directory
#
###############################################################################
def archive_directory(config,
                      directory):
    """ Create a tar file of a directory and then remove it

    This method creates a tar file of a directory in its parent directory,
    and subsequently removes the directory tree.

    Args:
        config (namespace Global_config Global_config obj): A Global_config
            object from an already read config file
        directory (str): The directory to be archived

    Returns:
        None

    Exceptions:
        None
    """

    # Initialize
    remove_temp = False
    remove_uncompressed = False

    try:
        # Construct paths
        # Archive file path is the concatenation of the dated subdirectories
        # inside the hml_repository_path
        archive_filename = os.path.basename(directory)
        subdirectory = os.path.dirname(directory)

        while(subdirectory.startswith(config.hml_repository_path) and
              subdirectory != config.hml_repository_path):
            archive_filename = os.path.basename(subdirectory) + archive_filename
            subdirectory = os.path.dirname(subdirectory)

        archive_filename = config.archive_prefix + archive_filename + '.tar.gz'
        uncompressed_filename = config.archive_prefix + archive_filename + '.tar'

        if not config.remove_instead:

            if config.destination_path:
                # Place file into optional destination directory
                temp_archive_filename = os.path.join(config.destination_path,
                                                     '.' + archive_filename +
                                                     '.tmp{0}'.format(os.getpid()))
                uncompressed_filename = os.path.join(config.destination_path,
                                                     '.' + uncompressed_filename +
                                                     '.tmp{0}'.format(os.getpid()))
                archive_filename = os.path.join(config.destination_path,
                                                archive_filename)
            else:
                # Place file in parent directory
                temp_archive_filename = os.path.join(os.path.dirname(directory),
                                                     '.' + archive_filename +
                                                     '.tmp{0}'.format(os.getpid()))
                uncompressed_filename = os.path.join(os.path.dirname(directory),
                                                     '.' + uncompressed_filename +
                                                     '.tmp{0}'.format(os.getpid()))
                archive_filename = os.path.join(os.path.dirname(directory),
                                                archive_filename)

            # Check to see if archive file exists
            if os.path.isfile(archive_filename):
                logger.warning('Updating existing archive file %s', archive_filename)

                # Will need to uncompress to append files
                uncompress_file(archive_filename, uncompressed_filename)
                remove_uncompressed = True

                tar = TarFile.open(uncompressed_filename, mode='a')
                tar.add(directory, arcname=os.path.basename(directory))
                tar.close()

                # Recompress
                compress_file(uncompressed_filename, temp_archive_filename)
                remove_temp = True
                os.remove(uncompressed_filename)
                remove_uncompressed = False
            else:
                logger.info('Creating archive file %s', archive_filename)

                # Create tar file
                tar = TarFile.open(temp_archive_filename, mode='w:gz')
                remove_temp = True
                tar.add(directory, arcname=os.path.basename(directory))
                tar.close()

            os.rename(temp_archive_filename, archive_filename)
            remove_temp = False
            logger.info('Successfully created %s', archive_filename)

        # Now recursively remove directory
        logger.info('Removing directory %s', directory)
        shutil.rmtree(directory)
        logger.info('Successfully removed %s', directory)

    except BaseException:
        if remove_temp:
            os.remove(temp_archive_filename)
        if remove_uncompressed:
            os.remove(uncompressed_filename)
        raise

##############################################################################
#
#  "Main"
#
##############################################################################
def main():
    """ Main

    This program goes through a directory tree and archives old directories
    into tar files.

    Args:
        None (see utilities.setup.setup_arguments for command line arguments)

    Returns:
        None

    Exceptions:
        None
    """

    try:
        program_description = ('This archiving script traverses a directory '
                               'tree and archives old directories ' "\n"
                               'into tar files.')

        epilogue = ('The global configuration file has the following fields:'
                    "\n\n"
                    'hml_repository_path = <root location of directory tree to'
                    ' archive. This must' "\n"
                    '                       contain datestamp directories '
                    'in the form of ' "\n"
                    '                       YYYY/MM/DD/...' "\n"
                    'archive_interval =    <the date type interval of archives,'
                    ' such as "year",' "\n"
                    '                       "month", "day", etc...' "\n"
                    'archive_prefix   =    <a string that will preprend the '
                    'date component to the' "\n"
                    '                      archive file.' "\n"
                    'archive_days     =    <the number of days that must elapse'
                    ' before a directory' "\n"
                    '                       is archived.' "\n"
                    'destination_path =    <an optional separate directory '
                    'where archive ' "\n"
                    '                       files are placed instead of in '
                    'situ' "\n")

        # Set up logging
        init_logging()

        # Get command line arguments
        # This can raise SystemExit if the help option is requested
        options = setup_arguments(program_description, epilogue)

        # Further configure logging
        set_logging_options(options)

        # Hardcoded constants from config file
        constants = Global_config(options.config_pathname)

        # Check to see if other processes are running
        # If not specified by command line arguments, this will do nothing
        busy = Busy_file(options.pidfile)

        # Get lists of tasks to archive
        process_list = tasks_from_directory(constants)

        # Process
        logger.info('Archiving %d directories', len(process_list))
        for directory in process_list:
            # Will allow errors and continue
            try:
                archive_directory(constants, directory)
            except KeyboardInterrupt:
                logger.warning('KeyboardInterrupt encountered')
                return
            except BaseException:
                # Log any exception message
                logger.error(Exceptions.format_current_exception())

            # Continue to next directory

        # Success
        return

    except SystemExit:
        return
    except KeyboardInterrupt:
        logger.warning('KeyboardInterrupt encountered')
        return
    except BaseException:
        # Log any exception message
        logger.error(Exceptions.format_current_exception())

        # Busy lock file should destruct normally

        # Failure
        sys.exit(1)

# Is this main?
if __name__ == "__main__":
    main()
