#!/bin/bash
#######################################################################
#
#  This script updates configuration files with customized content
#  like passwords, hostnames, etc..
#
#  Usage:
#      update_configs.sh <config suffix>
#
#  History:
#  Anders Nilsson, UCAR, 08/03/2021, Created
#  Anders Nilsson, UCAR, 09/01/2021, Added config file updating
#  Anders Nilsson, UCAR, 09/30/2021, Also copies files
#
#######################################################################

# Constants
  VARIABLES=(RHOST RPASSWORD DBHOST DBPASSWORD)
  VALUES=()

  IDX_LIST=$(seq 0 $(( ${#VARIABLES[@]} - 1 )) )

# Get current directory
  DIR="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Get arguments
  SUFFIX=$1
  shift
  if [ -z "${SUFFIX}" ]
  then
    echo "A configuration file suffix needs to be specified" 1>&2
    exit 1
  fi

# Loop through and get values
  for IDX in ${IDX_LIST}
  do
    read -p "${IDX}/${#VARIABLES[@]}: Enter value for ${VARIABLES[${IDX}]}:" VALUE
    VALUES[${IDX}]="${VALUE}"
  done

  for IDX in ${IDX_LIST}
  do
    echo "Using ${VARIABLES[${IDX}]}=${VALUES[${IDX}]}"
  done

# Get list of files
  ENVIRONMENT_FILES=$( find ${DIR} -mindepth 2 -maxdepth 2 \
                                   -name ".env.${SUFFIX}.orig" )

# Loop through files
  for ORIG_FILE in ${ENVIRONMENT_FILES}
  do
    FILE="${ORIG_FILE/.orig}"
    if [ ! -f "${FILE}" ]
    then
      echo "Copying ${ORIG_FILE} to ${FILE}"
      cp ${ORIG_FILE} ${FILE}
    fi
    echo "Checking ${FILE}"

    # Loop through variables
    for IDX in ${IDX_LIST}
    do
      VARIABLE="${VARIABLES[${IDX}]}"
      # Escape value
      VALUE="${VALUES[${IDX}]}"
      EVALUE="$( echo "${VALUES[${IDX}]}" | sed -e 's/[\/&]/\\&/g')"

      # Check to see if variable is present
      if grep -q "^${VARIABLE}=" ${FILE}
      then
        if [ -z "${VALUE}" ]
        then
          echo "Ignoring ${VARIABLE} in ${FILE}"
        else
          echo "Setting ${VARIABLE}=${VALUE} in ${FILE}"
          sed -i -e "s/^${VARIABLE}=.*$/${VARIABLE}=${EVALUE}/g" ${FILE}
        fi
      fi
    done
  done
                     
# Also correct .pgpass files
  PGPASS_FILES=$( find ${DIR} -mindepth 2 -maxdepth 2 -name ".pgpass.orig" )
  for ORIG_FILE in ${PGPASS_FILES}
  do
    FILE="${ORIG_FILE/.orig}"
    if [ ! -f "${FILE}" ]
    then
      echo "Copying ${ORIG_FILE} to ${FILE}"
      cp ${ORIG_FILE} ${FILE}
    fi

    for IDX in ${IDX_LIST}
    do 
      VARIABLE="${VARIABLES[${IDX}]}"
      VALUE="${VALUES[${IDX}]}"
      EVALUE="$( echo "${VALUES[${IDX}]}" | sed -e 's/[\/&]/\\&/g')"

      if [ "${VARIABLE}" = "DBPASSWORD" ]
      then
        echo "Updating database password in ${FILE}"
        # Set last value to password
        sed -i -e "s/: *$/:${EVALUE}/g" ${FILE}
        # No need to loop through other variables
        break
      fi

    done

  done

# Also correct other config file
# In this particular case, we are replacing the key with the value,
# instead of setting a key to a value.
  CONFIG_FILES="${DIR}/hml_cleaner/hml_cleaner_${SUFFIX}.conf"
  for FILE in ${CONFIG_FILES}
  do
    # Initialize config file if not present
    if [ ! -f "${FILE}" ] && [ -f "${FILE}.orig" ]
    then
      echo "Copying ${FILE}.orig to ${FILE}"
      cp "${FILE}.orig" "${FILE}"
    elif [ ! -f "${FILE}" ]
    then
      echo "Configuration file ${FILE} is missing" 1>&2
      exit 1
    fi
    for IDX in ${IDX_LIST}
    do
      VARIABLE="${VARIABLES[${IDX}]}"
      # Escape value
      VALUE="${VALUES[${IDX}]}"
      EVALUE="$( echo "${VALUES[${IDX}]}" | sed -e 's/[\/&]/\\&/g')"

      # Check to see if variable is present
      if grep -q "${VARIABLE}" ${FILE}
      then
        if [ -z "${VALUE}" ]
        then
          echo "Ignoring ${VARIABLE} in ${FILE}"
        else
          echo "Setting ${VARIABLE} to ${VALUE} in ${FILE}"
          sed -i -e "s/${VARIABLE}/${EVALUE}/g" ${FILE}
        fi
      fi
    done
  done

