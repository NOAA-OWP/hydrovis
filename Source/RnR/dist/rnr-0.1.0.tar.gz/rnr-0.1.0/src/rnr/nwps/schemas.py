from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class GaugeLocation(BaseModel):
    latitude: float
    longitude: float

class GaugeData(BaseModel):
    identifier: str = Field(..., description="The gauge's unique identifier (LID)")
    latitude: float
    longitude: float
    # Add other fields as necessary based on the actual response

class ForecastEntry(BaseModel):
    validTime: str
    primary: float
    secondary: float

class GaugeForecast(BaseModel):
    data: List[ForecastEntry]
    primaryName: str
    primaryUnits: str
    secondaryName: str
    secondaryUnits: str

class GaugeProductParams(BaseModel):
    identifier: str = Field(..., description="The gauge's unique identifier (LID)")
    product: str = Field(..., description="The product type (e.g., 'forecast')")

    class Config:
        schema_extra = {
            "example": {
                "identifier": "AMAI4",
                "product": "forecast"
            }
        }

# If you need to represent the full output of your get_rfc_forecasts function
class RFCForecast(BaseModel):
    times: List[str]
    primary_name: str
    primary_forecast: List[float]
    primary_unit: str
    secondary_name: str
    secondary_forecast: List[float]
    secondary_unit: str
    latitude: float
    longitude: float

# If you need to represent the domain file output
class DomainFileEntry(BaseModel):
    feature_id: str
    timestamp: float  # Assuming this is the flow value for a specific timestamp

class DomainFile(BaseModel):
    entries: List[DomainFileEntry]
    timestamp: datetime  # The timestamp for this specific domain file