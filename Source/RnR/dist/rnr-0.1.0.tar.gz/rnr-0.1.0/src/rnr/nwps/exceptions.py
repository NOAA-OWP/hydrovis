class NWPSAPIError(Exception):
    """
    Exception raised for errors in the NWPS API response.

    Parameters
    ----------
    status_code : int
        HTTP status code of the failed request.
    endpoint : str
        The API endpoint that was called.

    Attributes
    ----------
    status_code : int
        HTTP status code of the failed request.
    endpoint : str
        The API endpoint that was called.
    message : str
        Explanation of the error.
    """

    def __init__(self, status_code: int, endpoint: str):
        self.status_code = status_code
        self.endpoint = endpoint
        self.message = f"Request failed. Status Code: {status_code}. Endpoint: {endpoint}"
        super().__init__(self.message)

    def __str__(self):
        return f'NWPSAPIError: {self.message}'