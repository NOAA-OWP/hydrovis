from fastapi import FastAPI
from src.nwps.router import router as nwps_router
# from src.domain_generator.router import router as domain_generator_router

app = FastAPI()

app.include_router(nwps_router, prefix="/nwps", tags=["NWPS"])
# app.include_router(domain_generator_router, prefix="/domain-generator", tags=["Domain Generator"])