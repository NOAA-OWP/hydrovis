import pytest
from fastapi.testclient import TestClient
from src.rnr.main import app
from src.rnr.nwps.service import NWPSService
from src.rnr.nwps.schemas import GaugeParams, GaugeData, GaugeForecast

client = TestClient(app)

def test_get_gauges(gauge_data):
    response = client.get("/nwps/gauges", params=gauge_data)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for gauge in response.json():
        assert isinstance(gauge, dict)
        assert "identifier" in gauge

def test_get_gauge_data(identifier):
    response = client.get(f"/nwps/gauges/{identifier}")
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert response.json()["identifier"] == identifier

def test_get_gauge_forecast(identifier):
    response = client.get(f"/nwps/gauges/{identifier}/forecast")
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "data" in response.json()
    assert isinstance(response.json()["data"], list)

@pytest.mark.asyncio
async def test_nwps_service_get_gauges(gauge_data):
    params = GaugeParams(**gauge_data)
    result = await NWPSService.get_gauges(params)
    
    assert isinstance(result, list)
    for gauge in result:
        assert isinstance(gauge, GaugeData)

@pytest.mark.asyncio
async def test_nwps_service_get_gauge_data(identifier):
    result = await NWPSService.get_gauge_data(identifier)
    
    assert isinstance(result, GaugeData)
    assert result.identifier == identifier

@pytest.mark.asyncio
async def test_nwps_service_get_gauge_forecast(identifier):
    result = await NWPSService.get_gauge_forecast(identifier)
    
    assert isinstance(result, GaugeForecast)
    assert isinstance(result.data, list)

def test_reach_endpoint(client, reach_id):
    response = client.get(f"/nwps/reaches/{reach_id}")
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert response.json()["id"] == reach_id

def test_reach_streamflow_endpoint(client, reach_id):
    response = client.get(f"/nwps/reaches/{reach_id}/streamflow")
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "series" in response.json()

def test_stageflow_endpoint(client, identifier, pedts):
    response = client.get(f"/nwps/products/stageflow/{identifier}/{pedts}")
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

def test_convert_to_m3_per_sec(kcfs_data):
    from src.nwps.utils import convert_to_m3_per_sec
    
    result, unit = convert_to_m3_per_sec(kcfs_data, "kcfs")
    
    assert unit == "m3 s-1"
    assert len(result) == len(kcfs_data)
    assert result[0] == pytest.approx(566.33693, rel=1e-5)  # 20 kcfs in m3/s
