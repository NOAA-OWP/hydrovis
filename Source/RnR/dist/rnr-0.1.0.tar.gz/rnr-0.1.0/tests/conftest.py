from typing import Dict, Union

import pytest


@pytest.fixture
def base_url() -> str:
    return  "https://api.weather.gov/nwps/v1"


@pytest.fixture
def gauge_data() -> Dict[str, Union[float, str]]:
    """Reading a single gage from New Jersey
    """
    params = {
        "bbox.xmin": -74.68816690895136,
        "bbox.ymin": 40.56164600908951, 
        "bbox.xmax": -74.67016709104864,
        "bbox.ymax": 40.57946599091049,
    }
    return params


@pytest.fixture
def reach_id() -> str:
    """Reading the sample reach
    """
    return "23021904"


@pytest.fixture
def identifier() -> str:
    """Reading the sample identifier
    """
    return "ANAW1"


@pytest.fixture
def product() -> str:
    """Reading the sample reach
    """
    return "forecast"


@pytest.fixture
def pedts() -> str:
    """Reading the sample reach
    """
    return "HGIRG"

@pytest.fixture
def kcfs_data() -> str:
    """Reading the sample reach
    """
    return [20.0, 40.0, 60.0]
