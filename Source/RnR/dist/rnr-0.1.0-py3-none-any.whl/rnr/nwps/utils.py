from typing import List, Tuple

def convert_to_m3_per_sec(forecast: List[float], unit: str) -> Tuple[List[float], str]:
    """Convert forecast units to m3/s."""
    if unit == "kcfs":
        forecast = [flow * 1000 * 0.028316846592 for flow in forecast]
        return forecast, "m3 s-1"
    else:
        raise ValueError(f"Unit conversion not supported for {unit}")