from typing import List

from .client import gauge_data, gauge_product, gauges
from .schemas import GaugeData, GaugeForecast, GaugeParams

class NWPSService:
    @staticmethod
    async def get_gauge_data(identifier: str) -> GaugeData:
        data = gauge_data(identifier)
        return GaugeData(**data)

    @staticmethod
    async def get_gauge_forecast(identifier: str) -> GaugeForecast:
        data = gauge_product(identifier, "forecast")
        return GaugeForecast(**data)

    @staticmethod
    async def get_gauges(params: GaugeParams) -> List[GaugeData]:
        data = gauges(params.x_min, params.y_min, params.x_max, params.y_max, params.srid)
        return [GaugeData(**gauge) for gauge in data.get("gauges", [])]