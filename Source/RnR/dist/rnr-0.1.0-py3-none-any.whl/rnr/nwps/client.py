from typing import Any, Dict, Optional, Union
import requests
from .exceptions import NWPSAPIError
from .constants import BASE_URL


def _get(endpoint: str, params: Optional[Union[Dict[str, Any], None]] = None) -> Dict[str, Any]:
    """A GET request using requests
    Parameters
    ----------
    endpoint
        the URL we're hitting 

    params
        The parameters passed to the API endpoint
    """
    if params is None:
        response = requests.get(endpoint)
    else:
        response = requests.get(endpoint, params=params)
    if response.status_code == 200:
        data = response.json()
        return data
    else:
        msg = f"Request failed. Status Code: {response.status_code}. Endpoint: {endpoint}"
        raise NWPSAPIError(msg)


def gauges(x_min: float, y_min: float, x_max: float, y_max: float, srid: str = "EPSG_4326") -> Dict[str, Any]:
    """Reads the gauges API from api.water.noaa.gov
    Parameters
    ----------
    x_min
        Bottom-left X coordinate of a bounding box geometry.
    y_min
        Bottom-left Y coordinate of a bounding box geometry.
    x_max
        Top-right X coordinate of a bounding box geometry.
    y_max
        Top-right Y coordinate of a bounding box geometry.
    sid
        Spatial reference system ID for input geometry. When unspecified, the server will use EPSG3857.
    """
    endpoint = f"{BASE_URL}/gauges"
    params = {
        "bbox.xmin": x_min,
        "bbox.ymin": y_min,
        "bbox.xmax": x_max,
        "bbox.ymax": y_max,
        "srid": srid,

    }
    return _get(endpoint, params)


def gauge_data(identifier: str) -> Dict[str, Any]:
    """Get Stage/Flow for a specific gauge
    Parameters
    ----------
    identifier
        The gauge's unique identifier, LID, or USGS ID
    """
    endpoint = f"{BASE_URL}/gauges/{identifier}"
    return _get(endpoint)


def gauge_ratings(identifier: str, limit: Optional[str] = "10000", sort: Optional[str] = "ASC", only_tenths: Optional[bool] = False) -> Dict[str, Any]:
    """Get ratings based off of STAGE Data
    Parameters
    ----------
    identifier
        The gauge's unique identifier, LID, or USGS ID
    limit
        Limit the number of results
    sort
        Sorts results by ascending (ASC) or descending (DSC)
    only_tenths
        Limits ratings to only tenths of a foot increments
    """
    endpoint = f"{BASE_URL}/gauges/{identifier}/ratings"
    params = {
        "limit": limit,
        "onlyTenths": only_tenths,
    }
    if sort.upper() in [
        "ASC",
        "DSC",
    ]:
        params["sort"] = sort
    else:
        raise NWPSAPIError("Incorrect sort provided")
    return _get(endpoint, params)


def gauge_stageflow(identifier: str) -> Dict[str, Any]:
    """Gets stageflow based on gauge
    Parameters
    ----------
    identifier
        The gauge's unique identifier, LID, or USGS ID
    """
    endpoint = f"{BASE_URL}/gauges/{identifier}/stageflow"
    return _get(endpoint)


def gauge_product(identifier: str, product: str) -> Dict[str, Any]:
    """Gets stageflow based on gauge
    Parameters
    ----------
    identifier
        The gauge's unique identifier, LID, or USGS ID
    product
        The product you're looking for 
    """
    endpoint = f"{BASE_URL}/gauges/{identifier}/stageflow/{product}"
    if product.lower() in [
        "observed",
        "forecast",
    ]:
        return _get(endpoint)
    else:
        raise NWPSAPIError("Incorrect product provided")


def reaches(reach_id: str) -> Dict[str, Any]:
    """Reads the gauges API from api.water.noaa.gov
    Parameters
    ----------
    reach_id
        The reach's unique Reach ID.
    """
    endpoint = f"{BASE_URL}/reaches/{reach_id}"
    return _get(endpoint)


def reach_streamflow(reach_id: str, series: Optional[str] = "analysis_assimilation") -> Dict[str, Any]:
    """Reads the gauges API from api.water.noaa.gov
    Parameters
    ----------
    reach_id
        The reach's unique Reach ID.
    
    series
        The specific forecast requested
    """
    endpoint = f"{BASE_URL}/reaches/{reach_id}"
    if series.lower() in [
        "analysis_assimilation",
        "short_range",
        "medium_range",
        "long_range",
        "medium_range_blend",
    ]:
        params = {
            "series": series,
        }
        return _get(endpoint, params)
    else:
        raise NWPSAPIError("Incorrect series provided")


def stageflow(identifier: str, pedts: str) -> Dict[str, Any]:
    """Get Stage/Flow for a specific gauge
    Parameters
    ----------
    identifier
        The gauge's unique identifier
    pedts
        The standard hydrometeorological exchange format parameter codes
    """
    endpoint = f"{BASE_URL}/products/stageflow/{identifier}/{pedts}"
    return _get(endpoint)
