from typing import List

from fastapi import APIRouter, Depends
from .service import NWPSService
from .schemas import GaugeParams, GaugeData, GaugeForecast

router = APIRouter(tags=["NWPS"])

@router.get("/gauges/{identifier}", response_model=GaugeData)
async def get_gauge_data(identifier: str):
    return await NWPSService.get_gauge_data(identifier)

@router.get("/gauges/{identifier}/forecast", response_model=GaugeForecast)
async def get_gauge_forecast(identifier: str):
    return await NWPSService.get_gauge_forecast(identifier)

@router.get("/gauges", response_model=List[GaugeData])
async def get_gauges(params: GaugeParams = Depends()):
    return await NWPSService.get_gauges(params)